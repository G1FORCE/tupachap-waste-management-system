<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;

// Landing Page
Route::get('/', function () {
    return view('landing');
})->name('landing');

Route::view('/terms', 'legal.terms')->name('terms');
Route::view('/privacy', 'legal.privacy')->name('privacy');

// Authentication Routes
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.submit');
Route::get('/logout', [AuthController::class, 'logout'])->name('logout');

Route::get('/delete-account', function (Request $request) {
    $role = strtolower((string) $request->query('role', 'customer'));

    if (! in_array($role, ['customer', 'waste-picker'], true)) {
        abort(404);
    }

    return view('account.delete', [
        'selectedRole' => $role,
    ]);
})->name('delete-account.demo');

Route::post('/delete-account', function (Request $request) {
    $validated = $request->validate([
        'role' => ['required', 'in:customer,waste-picker'],
        'full_name' => ['required', 'string', 'max:120'],
        'phone_number' => ['required', 'string', 'max:20'],
        'reason' => ['required', 'string', 'max:500'],
        'confirmation' => ['required', 'accepted'],
    ]);

    return redirect()
        ->route('delete-account.demo', ['role' => $validated['role']])
        ->with('status', 'Demo request saved. No account was deleted.');
})->name('delete-account.submit');

// Admin Dashboard (Protected)
Route::middleware(['web'])->group(function () {
    Route::get('/admin', function () {
        return view('admin.dashboard');
    })->name('admin.dashboard');

    // Collector Dashboard (Protected)
    Route::get('/collector', function () {
        return view('collector.dashboard');
    })->name('collector.dashboard');
});

