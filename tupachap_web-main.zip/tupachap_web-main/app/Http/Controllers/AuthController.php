<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AuthController extends Controller
{
    /**
     * Show login form
     */
    public function showLogin()
    {
        if (session('access_token')) {
            $role = session('user_role');
            if ($role === 'SYS_ADMIN') {
                return redirect('/admin');
            } elseif ($role === 'COLLECTOR_ADMIN') {
                return redirect('/collector');
            }
        }
        return view('auth.login');
    }

    /**
     * Handle login (web form submission)
     */
    public function login(Request $request)
    {
        // This is typically handled by your API
        // For now, we'll just return the login page
        return view('auth.login');
    }

    /**
     * Logout
     */
    public function logout(Request $request)
    {
        $request->session()->forget(['access_token', 'refresh_token', 'user_role']);
        return redirect('/login');
    }
}
