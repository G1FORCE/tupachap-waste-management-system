<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckJwtToken
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next, ...$roles): Response
    {
        $token = session('access_token');

        if (!$token) {
            return redirect('/login')->with('error', 'Please login first');
        }

        // If roles are specified, check them
        if (count($roles) > 0) {
            $role = session('user_role');
            if (!in_array($role, $roles)) {
                return abort(403, 'Unauthorized access');
            }
        }

        return $next($request);
    }
}
