<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>TupaChap • Admin Dashboard</title>
    @fonts
    @if (file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot')))
        @vite(['resources/css/app.css','resources/js/app.js'])
    @endif
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0"></script>
    <script src="https://cdn.jsdelivr.net/npm/leaflet@1.9.4"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.min.css" />
    @vite(['resources/js/dashboards/admin.js'])
</head>
<body class="min-h-screen bg-slate-50 text-neutral-900 font-sans">
    <header class="sticky top-0 z-40 border-b bg-white shadow-sm">
        <div class="mx-auto max-w-7xl px-4 py-4 flex items-center justify-between">
            <a href="{{ route('landing') }}" class="flex items-center gap-2">
                <img src="{{ asset('logo_2.png') }}" alt="TupaChap Logo" class="h-8 rounded">
                <span class="ml-2 text-xs text-primary-dark font-medium">SYS_ADMIN</span>
            </a>
            <nav class="flex items-center gap-6 text-sm">
                <a href="{{ route('admin.dashboard') }}" class="text-primary font-medium hover:text-primary-dark">Dashboard</a>
                <a href="#" class="text-neutral-600 hover:text-neutral-800">Fleet Directory</a>
                <a href="#" class="text-neutral-600 hover:text-neutral-800">Settings</a>
                <a href="#" onclick="window.logout(event)" class="text-neutral-600 hover:text-neutral-800">Logout</a>
            </nav>
        </div>
    </header>

    <main class="mx-auto max-w-7xl px-4 py-8 space-y-8">
        <!-- Page Title -->
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-neutral-900">Platform Administration</h1>
            <p class="text-neutral-600 mt-2">Monitor platform activities, verify collectors, and view analytics</p>
        </div>

        <!-- Overview Stats -->
        <section class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div class="rounded-lg border bg-white p-4 shadow-sm">
                <div class="text-sm text-neutral-600">Pending Verifications</div>
                <div id="pending-count" class="mt-2 text-3xl font-bold text-blue-600">—</div>
                <div class="mt-2 text-xs text-neutral-500">Awaiting review</div>
            </div>
            <div class="rounded-lg border bg-white p-4 shadow-sm">
                <div class="text-sm text-neutral-600">Verified Collectors</div>
                <div id="verified-count" class="mt-2 text-3xl font-bold text-green-600">—</div>
                <div class="mt-2 text-xs text-neutral-500">Active on platform</div>
            </div>
            <div class="rounded-lg border bg-white p-4 shadow-sm">
                <div class="text-sm text-neutral-600">Active Vehicles</div>
                <div id="active-vehicles" class="mt-2 text-3xl font-bold text-amber-600">—</div>
                <div class="mt-2 text-xs text-neutral-500">Currently online</div>
            </div>
            <div class="rounded-lg border bg-white p-4 shadow-sm">
                <div class="text-sm text-neutral-600">Total Trips Today</div>
                <div id="trips-today" class="mt-2 text-3xl font-bold text-purple-600">—</div>
                <div class="mt-2 text-xs text-neutral-500">Completed</div>
            </div>
        </section>

        <!-- Collector Verification Module -->
        <section class="rounded-lg border bg-white p-6 shadow-sm">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-xl font-semibold">Collector Verification</h2>
                <button id="refresh-pending" class="px-3 py-1 text-sm rounded bg-blue-100 text-primary hover:bg-blue-200">Refresh</button>
            </div>
            <p class="text-sm text-neutral-600 mb-4">Review and approve or reject pending collector registrations</p>

            <div id="pending-list" class="space-y-3">
                <div class="flex items-center justify-center h-24 text-neutral-400">Loading pending collectors...</div>
            </div>
        </section>

        <!-- Analytics Section -->
        <section class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <!-- Ward Activity -->
            <div class="rounded-lg border bg-white p-6 shadow-sm">
                <h3 class="text-lg font-semibold mb-4">Ward Activity</h3>
                <p class="text-sm text-neutral-600 mb-4">Trip volume by municipal ward</p>
                <div class="h-80 rounded border bg-slate-50 flex items-center justify-center">
                    <canvas id="ward-chart"></canvas>
                </div>
            </div>

            <!-- Waste Heatmap -->
            <div class="rounded-lg border bg-white p-6 shadow-sm">
                <h3 class="text-lg font-semibold mb-4">Waste Pickup Heatmap</h3>
                <p class="text-sm text-neutral-600 mb-4">Pickup density visualization across the city</p>
                <div id="heatmap" class="h-80 rounded border bg-slate-50 overflow-hidden"></div>
            </div>
        </section>

        <!-- Live Monitoring -->
        <section class="rounded-lg border bg-white p-6 shadow-sm">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-xl font-semibold">Live Platform Monitoring</h2>
                <div class="flex gap-2">
                    <button id="toggle-vehicles" class="px-4 py-2 rounded bg-primary text-white text-sm hover:bg-accent">Monitor Vehicles</button>
                    <button id="disconnect-all" class="px-4 py-2 rounded bg-neutral-200 text-neutral-700 text-sm hover:bg-neutral-300" style="display: none;">Disconnect</button>
                </div>
            </div>

            <div id="live-feed" class="space-y-2 max-h-96 overflow-y-auto">
                <div class="text-center text-neutral-400 py-8">Click "Monitor Vehicles" to connect to live updates</div>
            </div>

            <div class="mt-4 pt-4 border-t text-xs text-neutral-500">
                <strong>WebSocket Endpoints:</strong>
                <div class="mt-2 font-mono text-xs">
                    <div>🚗 Fleet: wss://api.tupachap.com/api/ws/vehicles?token=JWT</div>
                    <div>📍 Trip: wss://api.tupachap.com/api/ws/customer/{trip_id}?token=JWT</div>
                </div>
            </div>
        </section>

        <!-- Fleet Directory -->
        <section class="rounded-lg border bg-white p-6 shadow-sm">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-xl font-semibold">Verified Fleet Directory</h2>
                <button id="refresh-directory" class="px-3 py-1 text-sm rounded bg-blue-100 text-primary hover:bg-green-200">Refresh</button>
            </div>

            <div id="directory-list" class="space-y-4">
                <div class="flex items-center justify-center h-24 text-neutral-400">Loading fleet directory...</div>
            </div>
        </section>
    </main>

    <footer class="border-t bg-white mt-12">
        <div class="mx-auto max-w-7xl px-4 py-6 text-xs text-neutral-500">© {{ date('Y') }} TupaChap • Admin Dashboard</div>
    </footer>

    <!-- Verification Modal -->
    <div id="verification-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div class="bg-white rounded-lg max-w-md w-full p-6">
            <h3 id="modal-title" class="text-lg font-semibold mb-4"></h3>
            <div id="modal-content" class="space-y-3 mb-6 text-sm text-neutral-600"></div>
            <div class="flex gap-3">
                <button id="modal-reject" class="flex-1 px-4 py-2 rounded border border-red-200 text-red-600 hover:bg-red-50">Reject</button>
                <button id="modal-approve" class="flex-1 px-4 py-2 rounded bg-green-600 text-white hover:bg-green-700">Approve</button>
            </div>
        </div>
    </div>
</body>
</html>
