<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login • TupaChap</title>
    @fonts
    @if (file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot')))
        @vite(['resources/css/app.css','resources/js/app.js'])
    @endif
    <script>
        // Global config for API access
        window.__TUPACHAP_CONFIG__ = {
            API_URL: "{{ env('VITE_API_URL', 'https://tupachap-engine.onrender.com') }}",
            WS_URL: "{{ env('VITE_WS_URL', 'wss://tupachap-engine.onrender.com') }}"
        };
    </script>
</head>
<body class="min-h-screen bg-gradient-to-br from-blue-50 to-slate-100 flex items-center justify-center px-4">
    <div class="w-full max-w-md">
        <div class="bg-white rounded-lg shadow-lg p-8">
            <!-- Logo -->
            <div class="text-center mb-8">
                <div class="inline-flex  items-center justify-center"><img src="{{ asset('logo_2.png') }}" alt="TupaChap Logo" class="h-8 rounded"></div>
                <p class="text-sm text-neutral-600 mt-2">Waste Management Platform</p>
            </div>

            <!-- Alert Messages -->
            @if ($errors->any())
                <div class="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                    <p class="text-red-700 text-sm font-medium">Login failed</p>
                    @foreach ($errors->all() as $error)
                        <p class="text-red-600 text-sm">{{ $error }}</p>
                    @endforeach
                </div>
            @endif

            @if (session('error'))
                <div class="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                    <p class="text-red-700 text-sm">{{ session('error') }}</p>
                </div>
            @endif

            <!-- Login Form -->
            <form id="login-form" class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-neutral-700 mb-2">
                        Phone Number
                    </label>
                    <input
                        type="tel"
                        name="username"
                        id="username"
                        required
                        class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent focus:outline-none transition"
                        placeholder="255712345678"
                        autocomplete="tel"
                    >
                    <p class="text-xs text-neutral-500 mt-1">Enter your phone number (include country code)</p>
                </div>

                <div>
                    <label class="block text-sm font-medium text-neutral-700 mb-2">
                        Password
                    </label>
                    <input
                        type="password"
                        name="password"
                        id="password"
                        required
                        class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent focus:outline-none transition"
                        placeholder="Your password"
                        autocomplete="current-password"
                    >
                </div>

                <button
                    type="submit"
                    class="w-full px-4 py-2 bg-primary text-white rounded-lg font-medium hover:bg-primary-dark transition flex items-center justify-center"
                    id="login-btn"
                >
                    <span id="login-text">Sign In</span>
                    <span id="login-spinner" class="hidden ml-2">
                        <svg class="animate-spin h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                    </span>
                </button>
            </form>

            <div class="mt-4 flex items-center justify-between gap-4 text-sm">
                <p class="text-neutral-500">Need to register a collector company?</p>
                <button id="open-register-modal" type="button" class="px-3 py-2 rounded border border-primary text-primary hover:bg-primary/10">
                    Register company
                </button>
            </div>

            <div class="mt-3 text-center text-sm text-neutral-500">
                <a href="{{ route('delete-account.demo') }}" class="text-primary hover:text-primary-dark">Customer or waste picker delete-account demo</a>
            </div>

            <!-- Info Box -->
            <div class="mt-6 pt-6 border-t border-neutral-200">
                <h3 class="font-semibold text-neutral-900 mb-3 text-sm">Demo Credentials</h3>
                <div class="space-y-2 text-sm text-neutral-600">
                    <div>
                        <strong class="text-neutral-700">System Admin:</strong>
                        <div class="font-mono text-xs bg-slate-50 p-2 rounded mt-1">
                            <div>📞 255712345678</div>
                            <div>🔑 admin_password</div>
                        </div>
                    </div>
                    <div class="mt-3">
                        <strong class="text-neutral-700">Collector Admin:</strong>
                        <div class="font-mono text-xs bg-slate-50 p-2 rounded mt-1">
                            <div>📞 255787654321</div>
                            <div>🔑 collector_password</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Footer -->
            <div class="mt-6 pt-6 border-t border-neutral-200 text-center text-xs text-neutral-500">
                <p>© {{ date('Y') }} TupaChap. All rights reserved.</p>
                <p class="mt-2"><a href="{{ route('landing') }}" class="text-primary hover:text-primary-dark">Back to home</a></p>
            </div>
        </div>
    </div>


    <div id="collector-register-modal" class="hidden fixed inset-0 z-50 bg-black/50 px-4 py-6 flex items-center justify-center">
        <div class="w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl">
            <div class="flex items-start justify-between gap-4 mb-5">
                <div>
                    <h2 class="text-xl font-semibold text-neutral-900">Register Collector Company</h2>
                    <p class="text-sm text-neutral-600 mt-1">Create a new waste management company account.</p>
                </div>
                <button id="close-register-modal" type="button" class="text-neutral-400 hover:text-neutral-700">✕</button>
            </div>

            <div id="register-status" class="mb-4 text-sm"></div>

            <form id="collector-register-form" class="grid gap-4">
                <div>
                    <label class="block text-sm font-medium text-neutral-700 mb-2">Company Name</label>
                    <input type="text" name="company_name" required class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent focus:outline-none transition" placeholder="TupaChap Collections Ltd">
                </div>
                <div>
                    <label class="block text-sm font-medium text-neutral-700 mb-2">Phone Number</label>
                    <input type="tel" name="phone_number" required class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent focus:outline-none transition" placeholder="255712345678">
                </div>
                <div>
                    <label class="block text-sm font-medium text-neutral-700 mb-2">TIN Number</label>
                    <input type="text" name="tin_number" class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent focus:outline-none transition" placeholder="123-456-789">
                </div>
                <div>
                    <label class="block text-sm font-medium text-neutral-700 mb-2">Password</label>
                    <input type="password" name="password" required class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent focus:outline-none transition" placeholder="Choose a secure password">
                </div>
                <div class="flex gap-3 pt-2">
                    <button type="button" class="flex-1 px-4 py-2 rounded-lg border border-neutral-200 text-neutral-700 hover:bg-neutral-50">Cancel</button>
                    <button type="submit" class="flex-1 px-4 py-2 rounded-lg bg-primary text-white hover:bg-primary-dark">Submit registration</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
