<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Delete Account Demo • TupaChap</title>
    @fonts
    @if (file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot')))
        @vite(['resources/css/app.css','resources/js/app.js'])
    @endif
</head>
<body class="min-h-screen bg-[radial-gradient(circle_at_top,_rgba(59,130,246,0.18),_transparent_45%),linear-gradient(180deg,_#f8fafc_0%,_#eef2ff_100%)] text-neutral-900">
    <main class="mx-auto flex min-h-screen w-full max-w-6xl items-center px-4 py-10">
        <div class="grid w-full gap-6 lg:grid-cols-[1.1fr_0.9fr]">
            <section class="overflow-hidden rounded-3xl border border-white/70 bg-slate-950 text-white shadow-2xl shadow-slate-950/10">
                <div class="relative p-8 sm:p-10">
                    <div class="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_rgba(34,197,94,0.22),_transparent_35%),radial-gradient(circle_at_bottom_left,_rgba(59,130,246,0.22),_transparent_30%)]"></div>
                    <div class="relative">
                        <a href="{{ route('landing') }}" class="inline-flex items-center gap-3 rounded-full border border-white/10 bg-white/5 px-3 py-2 text-sm text-white/90 hover:bg-white/10">
                            <img src="{{ asset('logo_2.png') }}" alt="TupaChap Logo" class="h-7 rounded">
                            <span>Demo account control</span>
                        </a>

                        <div class="mt-10 max-w-xl">
                            <span class="inline-flex items-center rounded-full border border-emerald-400/30 bg-emerald-400/10 px-3 py-1 text-xs font-medium text-emerald-200">Customers and waste pickers only</span>
                            <h1 class="mt-5 text-4xl font-semibold tracking-tight sm:text-5xl">Delete account demo</h1>
                            <p class="mt-4 text-base leading-7 text-slate-300 sm:text-lg">
                                This page demonstrates the account deletion flow for customers and waste pickers. It is intentionally limited to those two user types and does not remove any records.
                            </p>
                        </div>

                        <div class="mt-10 grid gap-4 sm:grid-cols-2">
                            <div class="rounded-2xl border border-white/10 bg-white/5 p-4">
                                <div class="text-sm font-medium text-slate-200">Customer</div>
                                <p class="mt-2 text-sm text-slate-400">For household and business customers who want to close their TupaChap account.</p>
                            </div>
                            <div class="rounded-2xl border border-white/10 bg-white/5 p-4">
                                <div class="text-sm font-medium text-slate-200">Waste Picker</div>
                                <p class="mt-2 text-sm text-slate-400">For drivers and waste pickers who want to exit the platform.</p>
                            </div>
                        </div>

                        <div class="mt-10 rounded-2xl border border-amber-400/20 bg-amber-400/10 p-4 text-sm text-amber-100">
                            Demo only: the submit button flashes a confirmation message and preserves the account.
                        </div>
                    </div>
                </div>
            </section>

            <section class="rounded-3xl border border-white/70 bg-white p-6 shadow-xl shadow-slate-900/5 sm:p-8">
                <div class="flex items-start justify-between gap-4">
                    <div>
                        <p class="text-sm font-medium text-blue-600">Account deletion request</p>
                        <h2 class="mt-2 text-2xl font-semibold text-neutral-900">Start the demo flow</h2>
                    </div>
                    <span class="rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-600">Preview</span>
                </div>

                @if (session('status'))
                    <div class="mt-6 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
                        {{ session('status') }}
                    </div>
                @endif

                @if ($errors->any())
                    <div class="mt-6 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                        <p class="font-medium">Please correct the highlighted fields.</p>
                        <ul class="mt-2 space-y-1">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <form action="{{ route('delete-account.submit') }}" method="POST" class="mt-6 space-y-5">
                    @csrf

                    <fieldset class="space-y-3">
                        <legend class="text-sm font-medium text-neutral-700">Account type</legend>
                        <div class="grid gap-3 sm:grid-cols-2">
                            <label class="cursor-pointer rounded-2xl border px-4 py-4 transition {{ old('role', $selectedRole) === 'customer' ? 'border-blue-500 bg-blue-50 ring-2 ring-blue-100' : 'border-neutral-200 bg-white hover:bg-slate-50' }}">
                                <input type="radio" name="role" value="customer" class="sr-only" {{ old('role', $selectedRole) === 'customer' ? 'checked' : '' }}>
                                <div class="text-sm font-semibold text-neutral-900">Customer</div>
                                <p class="mt-1 text-sm text-neutral-500">Household or business account</p>
                            </label>
                            <label class="cursor-pointer rounded-2xl border px-4 py-4 transition {{ old('role', $selectedRole) === 'waste-picker' ? 'border-blue-500 bg-blue-50 ring-2 ring-blue-100' : 'border-neutral-200 bg-white hover:bg-slate-50' }}">
                                <input type="radio" name="role" value="waste-picker" class="sr-only" {{ old('role', $selectedRole) === 'waste-picker' ? 'checked' : '' }}>
                                <div class="text-sm font-semibold text-neutral-900">Waste Picker</div>
                                <p class="mt-1 text-sm text-neutral-500">Driver or collection worker</p>
                            </label>
                        </div>
                        @error('role')
                            <p class="text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </fieldset>

                    <div class="grid gap-4 sm:grid-cols-2">
                        <div>
                            <label class="block text-sm font-medium text-neutral-700 mb-2" for="full_name">Full name</label>
                            <input id="full_name" name="full_name" type="text" value="{{ old('full_name') }}" required class="w-full rounded-2xl border border-neutral-200 px-4 py-3 outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100" placeholder="Enter your full name">
                            @error('full_name')
                                <p class="mt-2 text-sm text-red-600">{{ $message }}</p>
                            @enderror
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-neutral-700 mb-2" for="phone_number">Phone number</label>
                            <input id="phone_number" name="phone_number" type="tel" value="{{ old('phone_number') }}" required class="w-full rounded-2xl border border-neutral-200 px-4 py-3 outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100" placeholder="255712345678">
                            @error('phone_number')
                                <p class="mt-2 text-sm text-red-600">{{ $message }}</p>
                            @enderror
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-neutral-700 mb-2" for="reason">Reason for leaving</label>
                        <textarea id="reason" name="reason" rows="4" required class="w-full rounded-2xl border border-neutral-200 px-4 py-3 outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100" placeholder="Tell us why you want to close the account">{{ old('reason') }}</textarea>
                        @error('reason')
                            <p class="mt-2 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <label class="flex items-start gap-3 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-4 text-sm text-amber-900">
                        <input name="confirmation" type="checkbox" value="1" class="mt-1 h-4 w-4 rounded border-amber-300 text-amber-600 focus:ring-amber-500" {{ old('confirmation') ? 'checked' : '' }}>
                        <span>I understand this is a demo and the account will not actually be deleted.</span>
                    </label>
                    @error('confirmation')
                        <p class="text-sm text-red-600">{{ $message }}</p>
                    @enderror

                    <div class="flex flex-col gap-3 sm:flex-row">
                        <button type="submit" class="inline-flex items-center justify-center rounded-2xl bg-slate-950 px-5 py-3 text-sm font-semibold text-white transition hover:bg-slate-800">
                            Submit demo request
                        </button>
                        <a href="{{ route('login') }}" class="inline-flex items-center justify-center rounded-2xl border border-neutral-200 px-5 py-3 text-sm font-semibold text-neutral-700 transition hover:bg-slate-50">
                            Back to login
                        </a>
                    </div>
                </form>
            </section>
        </div>
    </main>
</body>
</html>
