@extends('legal.layout', ['title' => 'Privacy Policy'])

@section('content')
    <div class="max-w-3xl">
        <p class="text-sm font-medium uppercase tracking-[0.2em] text-primary">Legal</p>
        <h1 class="mt-3 text-3xl sm:text-4xl font-bold">Privacy Policy</h1>
        <p class="mt-4 text-neutral-700">Effective date: {{ now()->format('F j, Y') }}</p>

        <div class="mt-8 space-y-8 text-sm leading-7 text-neutral-700">
            <section>
                <h2 class="text-xl font-semibold text-neutral-900">1. Overview</h2>
                <p class="mt-3">This Privacy Policy explains how TupaChap collects, uses, stores, shares, and protects personal data when you use our website, mobile applications, dashboards, APIs, and related services. We process personal data in accordance with applicable Tanzanian law, including data protection and electronic communications requirements where they apply.</p>
            </section>

            <section>
                <h2 class="text-xl font-semibold text-neutral-900">2. Information we collect</h2>
                <p class="mt-3">We may collect the following categories of information:</p>
                <ul class="mt-3 list-disc list-inside space-y-2">
                    <li>Identity and contact details, such as name, phone number, email address, and business name.</li>
                    <li>Account data, such as login credentials, profile information, roles, and preferences.</li>
                    <li>Service data, such as pickup addresses, waste category, transaction details, service history, and proof of service.</li>
                    <li>Location data, such as approximate or precise location when enabled for tracking, dispatch, or route optimization.</li>
                    <li>Device and technical data, such as IP address, browser type, device identifiers, logs, and usage analytics.</li>
                    <li>Communication data, such as support requests, feedback, call records, and messages with our team or service partners.</li>
                </ul>
            </section>

            <section>
                <h2 class="text-xl font-semibold text-neutral-900">3. How we use personal data</h2>
                <p class="mt-3">We use personal data to provide and improve the platform, create and manage accounts, dispatch collectors, process payments, verify service completion, respond to support requests, detect fraud, enforce our terms, comply with legal obligations, and send service-related notices.</p>
            </section>

            <section>
                <h2 class="text-xl font-semibold text-neutral-900">4. Legal grounds</h2>
                <p class="mt-3">Where required, we rely on one or more legal grounds for processing, including your consent, performance of a contract, compliance with legal obligations, protection of legitimate business interests, and protection of users or property.</p>
            </section>

            <section>
                <h2 class="text-xl font-semibold text-neutral-900">5. Sharing and disclosure</h2>
                <p class="mt-3">We may share personal data with fleet operators, drivers, payment providers, hosting providers, analytics providers, customer support tools, and professional advisers who help us operate the service. We may also disclose data where required by law, court order, or lawful request from a competent authority in Tanzania or elsewhere.</p>
                <p class="mt-3">We do not sell your personal data.</p>
            </section>

            <section>
                <h2 class="text-xl font-semibold text-neutral-900">6. Cross-border transfers</h2>
                <p class="mt-3">Some service providers may process data outside Tanzania. When that happens, we take reasonable steps to use appropriate safeguards and to ensure that the transfer is handled lawfully.</p>
            </section>

            <section>
                <h2 class="text-xl font-semibold text-neutral-900">7. Data retention</h2>
                <p class="mt-3">We retain personal data for as long as needed to provide the service, satisfy legal, tax, accounting, operational, dispute-resolution, or security requirements, and then delete or anonymize it when it is no longer required.</p>
            </section>

            <section>
                <h2 class="text-xl font-semibold text-neutral-900">8. Security</h2>
                <p class="mt-3">We use administrative, technical, and organizational safeguards designed to protect personal data against unauthorized access, loss, misuse, or disclosure. No online system is completely secure, so we cannot guarantee absolute security.</p>
            </section>

            <section>
                <h2 class="text-xl font-semibold text-neutral-900">9. Your rights</h2>
                <p class="mt-3">Subject to applicable law, you may request access to, correction of, deletion of, or restriction on certain personal data we hold about you. You may also object to certain processing activities or withdraw consent where processing is based on consent. We may need to verify your identity before responding.</p>
            </section>

            <section>
                <h2 class="text-xl font-semibold text-neutral-900">10. Cookies and analytics</h2>
                <p class="mt-3">We may use cookies, local storage, and similar technologies to keep you signed in, remember preferences, understand usage, and improve performance. You can control cookies through your browser settings, though some features may not function properly if cookies are disabled.</p>
            </section>

            <section>
                <h2 class="text-xl font-semibold text-neutral-900">11. Children</h2>
                <p class="mt-3">Our service is not directed to children under the age required by applicable law to provide valid consent on their own. If we learn that we have collected personal data from a child in breach of applicable law, we will take appropriate steps to delete it.</p>
            </section>

            <section>
                <h2 class="text-xl font-semibold text-neutral-900">12. Third-party links and services</h2>
                <p class="mt-3">The service may contain links to third-party websites or integrate third-party services. Their privacy practices are governed by their own policies, not this Privacy Policy.</p>
            </section>

            <section>
                <h2 class="text-xl font-semibold text-neutral-900">13. Updates to this policy</h2>
                <p class="mt-3">We may update this Privacy Policy from time to time. Any changes will be posted on this page with a revised effective date. Continued use of the service after an update means you accept the revised policy.</p>
            </section>

            <section>
                <h2 class="text-xl font-semibold text-neutral-900">14. Contact</h2>
                <p class="mt-3">For privacy questions or requests, contact us at privacy@tupachap.co.tz.</p>
            </section>
        </div>
    </div>
@endsection