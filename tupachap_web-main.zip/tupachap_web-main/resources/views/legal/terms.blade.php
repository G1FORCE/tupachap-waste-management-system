@extends('legal.layout', ['title' => 'Terms of Service'])

@section('content')
    <div class="max-w-3xl">
        <p class="text-sm font-medium uppercase tracking-[0.2em] text-primary">Legal</p>
        <h1 class="mt-3 text-3xl sm:text-4xl font-bold">Terms of Service</h1>
        <p class="mt-4 text-neutral-700">Effective date: {{ now()->format('F j, Y') }}</p>

        <div class="mt-8 space-y-8 text-sm leading-7 text-neutral-700">
            <section>
                <h2 class="text-xl font-semibold text-neutral-900">1. Acceptance of the terms</h2>
                <p class="mt-3">These Terms of Service govern your access to and use of TupaChap, including our website, mobile applications, dashboards, APIs, SMS, and related services. By creating an account, accessing the platform, or using any part of the service, you agree to these terms.</p>
                <p class="mt-3">If you use TupaChap on behalf of a business, company, or other organization, you confirm that you have authority to bind that entity to these terms.</p>
            </section>

            <section>
                <h2 class="text-xl font-semibold text-neutral-900">2. Service description</h2>
                <p class="mt-3">TupaChap connects customers with waste collection providers for scheduling, dispatch, tracking, proof of service, billing, and related logistics. Service availability may vary by location, waste category, vehicle type, regulatory requirements, and operational capacity.</p>
            </section>

            <section>
                <h2 class="text-xl font-semibold text-neutral-900">3. Eligibility and account security</h2>
                <p class="mt-3">You must provide accurate, current, and complete information when registering. You are responsible for maintaining the confidentiality of your login credentials and for all activity under your account.</p>
                <p class="mt-3">You must promptly notify us of any unauthorized access, loss of credentials, or suspected misuse of your account.</p>
            </section>

            <section>
                <h2 class="text-xl font-semibold text-neutral-900">4. Acceptable use</h2>
                <p class="mt-3">You agree not to misuse the platform, interfere with its operation, attempt unauthorized access, upload malicious code, falsify service records, or use the service for unlawful activity. You must comply with all applicable laws and regulations in Tanzania and any other jurisdiction that applies to your use of the service.</p>
            </section>

            <section>
                <h2 class="text-xl font-semibold text-neutral-900">5. Waste acceptance and safety rules</h2>
                <p class="mt-3">You are responsible for ensuring that waste handed over for collection is properly sorted, packaged, and disclosed. You must not present prohibited, hazardous, explosive, toxic, or otherwise restricted materials unless we have expressly agreed in writing and the collection is legally permitted.</p>
                <p class="mt-3">If a collection cannot proceed safely or lawfully, we may refuse, suspend, or reschedule the service. Additional charges may apply where extra handling, waiting time, or special disposal procedures are required.</p>
            </section>

            <section>
                <h2 class="text-xl font-semibold text-neutral-900">6. Payments and billing</h2>
                <p class="mt-3">Fees, estimates, subscriptions, commissions, and taxes are shown before confirmation where applicable. You authorize us and our payment partners to collect all applicable amounts through supported payment methods, including mobile money, card, bank transfer, or wallet payments.</p>
                <p class="mt-3">Unless we state otherwise, fees are non-refundable once a service has been completed, dispatched, or otherwise delivered in substantial part, except where a refund is required by law or approved by us in writing.</p>
            </section>

            <section>
                <h2 class="text-xl font-semibold text-neutral-900">7. Service availability and third parties</h2>
                <p class="mt-3">We may rely on third-party service providers, including drivers, fleet operators, payment processors, mapping services, and cloud infrastructure providers. We do not guarantee uninterrupted availability, and we may modify, suspend, or discontinue features when necessary for safety, maintenance, legal compliance, or business reasons.</p>
            </section>

            <section>
                <h2 class="text-xl font-semibold text-neutral-900">8. Intellectual property</h2>
                <p class="mt-3">All platform content, branding, software, designs, databases, and related intellectual property belong to TupaChap or our licensors. You may not copy, modify, distribute, reverse engineer, or exploit any part of the platform except as allowed by law or with our written permission.</p>
            </section>

            <section>
                <h2 class="text-xl font-semibold text-neutral-900">9. Suspension and termination</h2>
                <p class="mt-3">We may suspend or terminate your access if we reasonably believe you have breached these terms, created a risk to users or the platform, used the service unlawfully, or if required by law. You may stop using the service at any time, but certain obligations, including payment obligations and dispute provisions, will continue after termination where they are meant to survive.</p>
            </section>

            <section>
                <h2 class="text-xl font-semibold text-neutral-900">10. Disclaimer and limitation of liability</h2>
                <p class="mt-3">To the maximum extent permitted by law, the service is provided on an "as is" and "as available" basis. We do not guarantee that the platform will be error-free, uninterrupted, or suitable for every purpose. To the maximum extent allowed by Tanzanian law, we are not liable for indirect, incidental, special, or consequential losses arising from your use of the service.</p>
            </section>

            <section>
                <h2 class="text-xl font-semibold text-neutral-900">11. Governing law and disputes</h2>
                <p class="mt-3">These terms are governed by the laws of the United Republic of Tanzania. Any dispute that cannot be resolved informally should be brought before the competent courts or dispute-resolution body in Tanzania, unless mandatory law requires a different process.</p>
            </section>

            <section>
                <h2 class="text-xl font-semibold text-neutral-900">12. Changes to these terms</h2>
                <p class="mt-3">We may update these terms from time to time. The updated version will be posted on this page with a revised effective date. Continued use of the service after an update means you accept the revised terms.</p>
            </section>

            <section>
                <h2 class="text-xl font-semibold text-neutral-900">13. Contact</h2>
                <p class="mt-3">If you have questions about these terms, contact us at support@tupachap.co.tz.</p>
            </section>
        </div>
    </div>
@endsection