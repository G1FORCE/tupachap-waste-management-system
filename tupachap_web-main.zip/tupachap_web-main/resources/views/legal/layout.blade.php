<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, follow">
    <title>{{ $title }} • TupaChap</title>
    @fonts
    @if (file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot')))
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    @endif
</head>
<body class="min-h-screen bg-surface text-neutral-900 font-sans">
    <header class="border-b bg-white/90 backdrop-blur sticky top-0 z-40">
        <div class="mx-auto max-w-5xl px-4 py-4 flex items-center justify-between gap-4">
            <a href="{{ route('landing') }}" class="flex items-center gap-3">
                <img src="{{ asset('logo_2.png') }}" alt="TupaChap Logo" class="h-8 rounded">
                <span class="font-semibold">TupaChap</span>
            </a>
            <nav class="flex items-center gap-4 text-sm">
                <a href="{{ route('terms') }}" class="text-neutral-700 hover:text-neutral-900">Terms</a>
                <a href="{{ route('privacy') }}" class="text-neutral-700 hover:text-neutral-900">Privacy</a>
            </nav>
        </div>
    </header>

    <main class="mx-auto max-w-5xl px-4 py-12 sm:py-16">
        @yield('content')
    </main>

    <footer class="border-t bg-white">
        <div class="mx-auto max-w-5xl px-4 py-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-sm text-neutral-600">
            <p>© {{ date('Y') }} TupaChap</p>
            <div class="flex gap-4">
                <a href="{{ route('terms') }}" class="hover:text-neutral-900">Terms of Service</a>
                <a href="{{ route('privacy') }}" class="hover:text-neutral-900">Privacy Policy</a>
            </div>
        </div>
    </footer>
</body>
</html>