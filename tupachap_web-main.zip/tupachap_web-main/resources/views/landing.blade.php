<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>TupaChap • On‑Demand Waste Collection</title>
    @fonts
    @if (file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot')))
            @vite(['resources/css/app.css','resources/js/app.js'])
        @endif
</head>
<body class="min-h-screen bg-surface text-neutral-900 font-sans">
    <!-- Header -->
    <header class="sticky top-0 z-40 bg-white/80 backdrop-blur border-b">
        <div class="mx-auto max-w-7xl px-4 py-4 flex items-center justify-between">
            <a href="{{ route('landing') }}" class="flex items-center gap-2">
                <img src="{{ asset('logo_2.png') }}" alt="TupaChap Logo" class="h-8 rounded">
            </a>
            <nav class="hidden sm:flex items-center gap-6 text-sm">
                <a href="#problem" class="text-neutral-700 hover:text-neutral-900">Problem</a>
                <a href="#services" class="text-neutral-700 hover:text-neutral-900">Services</a>
                <a href="#collectors" class="text-neutral-700 hover:text-neutral-900">For Collectors</a>
                <a href="#pricing" class="text-neutral-700 hover:text-neutral-900">Pricing</a>
            </nav>
            <div class="flex items-center gap-2">
                <a href="{{ route('collector.dashboard') }}" class="px-4 py-2 rounded border border-primary text-primary hover:bg-primary/10">Collector Portal</a>
                <a href="#apps" class="px-4 py-2 rounded bg-primary text-white hover:bg-primary-dark">Get the App</a>
            </div>
        </div>
    </header>

    <!-- Hero -->
    <section class="relative overflow-hidden">
        <div class="mx-auto max-w-7xl px-4 py-16 sm:py-24 grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
            <div>
                <p class="inline-flex items-center gap-2 text-xs font-medium px-2.5 py-1 rounded-full border border-accent bg-accent/20 text-neutral-900">Fast • Accountable • Green</p>
                <h1 class="mt-4 text-4xl sm:text-5xl font-bold leading-tight">
                    On‑demand waste collection for Dar es Salaam
                </h1>
                <p class="mt-4 text-neutral-600 text-lg">
                    Request a pickup when you need it, track your collector live, and pay securely with mobile money.
                </p>
                <div class="mt-6 flex flex-wrap gap-3">
                    <a href="#apps" class="px-5 py-3 rounded bg-primary text-white hover:bg-primary-dark">Download App</a>
                    <a href="{{ route('collector.dashboard') }}" class="px-5 py-3 rounded bg-accent text-black hover:brightness-95">Join as Collector</a>
                </div>
                <p class="mt-4 text-xs text-neutral-500">Cashless • Categorized handling • Transparent pricing</p>
            </div>
            <div class="relative">
                <div class="aspect-video rounded-xl bg-transparent flex items-center justify-center text-neutral-400">
                    <img src="{{ asset('hero.png') }}" alt="Hero Image" class="w-full h-full object-contain scale-150">
                </div>
            </div>
        </div>
    </section>

    <!-- Problem / Solution -->
    <section id="problem" class="bg-white border-t">
        <div class="mx-auto max-w-7xl px-4 py-16 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="rounded-lg border p-6">
                <h3 class="font-semibold">Inefficient Routing</h3>
                <p class="mt-2 text-sm text-neutral-600">Collectors waste fuel on unoptimized routes. TupaChap dispatches the nearest equipped vehicle.</p>
            </div>
            <div class="rounded-lg border p-6">
                <h3 class="font-semibold">Unreliable Service</h3>
                <p class="mt-2 text-sm text-neutral-600">Missed pickups become a thing of the past with live tracking and verified handovers.</p>
            </div>
            <div class="rounded-lg border p-6">
                <h3 class="font-semibold">Revenue Leakage</h3>
                <p class="mt-2 text-sm text-neutral-600">Cashless, mobile‑money transactions guarantee payment on completed jobs.</p>
            </div>
        </div>
    </section>

    <!-- Services -->
    <section id="services" class="bg-surface">
        <div class="mx-auto max-w-7xl px-4 py-16 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="rounded-lg border bg-white p-6">
                <h3 class="font-semibold">Households (B2C)</h3>
                <ul class="mt-3 list-disc list-inside text-sm text-neutral-700 space-y-1">
                    <li>Immediate or Scheduled Pickups</li>
                    <li>Transparent, ward‑based pricing</li>
                    <li>Live ETA and driver tracking</li>
                </ul>
            </div>
            <div class="rounded-lg border bg-white p-6">
                <h3 class="font-semibold">Institutions & Corporates (B2B)</h3>
                <ul class="mt-3 list-disc list-inside text-sm text-neutral-700 space-y-1">
                    <li>Recurring scheduled pickups</li>
                    <li>Certified handling (incl. medical waste)</li>
                    <li>Pre‑paid subscription contracts</li>
                </ul>
            </div>
        </div>
    </section>

    <!-- For Collectors -->
    <section id="collectors" class="bg-white border-t">
        <div class="mx-auto max-w-7xl px-4 py-16 grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
            <div class="lg:col-span-2">
                <h2 class="text-2xl font-semibold">For Waste Management Companies</h2>
                <ul class="mt-4 grid sm:grid-cols-2 gap-4 text-sm text-neutral-700">
                    <li class="flex items-start gap-2"><span class="mt-1 h-2 w-2 rounded-full bg-primary"></span><span>Reduced operational costs via location‑based matching</span></li>
                    <li class="flex items-start gap-2"><span class="mt-1 h-2 w-2 rounded-full bg-primary"></span><span>Guaranteed revenue with integrated mobile money</span></li>
                    <li class="flex items-start gap-2"><span class="mt-1 h-2 w-2 rounded-full bg-primary"></span><span>Full fleet oversight with live map tracking</span></li>
                    <li class="flex items-start gap-2"><span class="mt-1 h-2 w-2 rounded-full bg-primary"></span><span>Driver lifecycle and vehicle type management</span></li>
                </ul>
                <div class="mt-6 flex gap-3">
                    <a href="{{ route('collector.dashboard') }}" class="px-5 py-3 rounded bg-primary text-white hover:bg-primary-dark">Open Collector Portal</a>
                    <a href="{{ route('admin.dashboard') }}" class="px-5 py-3 rounded border border-primary text-primary hover:bg-primary/10">System Admin</a>
                </div>
            </div>
            <div class="rounded-lg border bg-white p-6">
                <h3 class="font-semibold">3‑Step Proof of Service</h3>
                <ol class="mt-3 list-decimal list-inside text-sm text-neutral-700 space-y-1">
                    <li>Location QR handover at pickup</li>
                    <li>Collection photo before transit</li>
                    <li>Disposal photo at authorized dumpsite</li>
                </ol>
            </div>
        </div>
    </section>

    <!-- Pricing Overview -->
    <section id="pricing" class="bg-surface border-t">
        <div class="mx-auto max-w-7xl px-4 py-16">
            <h2 class="text-2xl font-semibold">Pricing Overview</h2>
            <p class="mt-3 text-neutral-700 max-w-3xl">General ward‑based pricing with transparent estimates before confirmation. Cashless payments via M‑Pesa, Tigo Pesa, and more.</p>
            <div class="mt-6 flex flex-wrap gap-3">
                <a href="#apps" class="px-5 py-3 rounded bg-accent text-black hover:brightness-95">See Plans</a>
                <a href="#contact" class="px-5 py-3 rounded border border-primary text-primary hover:bg-primary/10">Contact Sales</a>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-white border-t">
        <div class="mx-auto max-w-7xl px-4 py-10 grid grid-cols-1 sm:grid-cols-3 gap-6 text-sm">
            <div>
                <div class="flex items-center gap-2 font-semibold"><img src="{{ asset('logo_2.png') }}" alt="TupaChap Logo" class="h-8 rounded"></div>
                <p class="mt-2 text-neutral-600">Modernizing urban waste management.</p>
            </div>
            <div>
                <div class="font-semibold">Legal</div>
                <ul class="mt-2 space-y-1 text-neutral-600">
                    <li><a href="{{ route('terms') }}" class="hover:text-neutral-900">Terms of Service</a></li>
                    <li><a href="{{ route('privacy') }}" class="hover:text-neutral-900">Privacy Policy</a></li>
                </ul>
            </div>
            <div>
                <div class="font-semibold">Apps</div>
                <ul class="mt-2 space-y-1 text-neutral-600" id="apps">
                    <li><a href="#" class="hover:text-neutral-900">App Store</a></li>
                    <li><a href="#" class="hover:text-neutral-900">Google Play</a></li>
                </ul>
            </div>
        </div>
        <div class="border-t text-xs text-neutral-500">
            <div class="mx-auto max-w-7xl px-4 py-4">© {{ date('Y') }} TupaChap</div>
        </div>
    </footer>
</body>
</html>
