<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>TupaChap • Collector Dashboard</title>
    @fonts
    @if (file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot')))
        @vite(['resources/css/app.css','resources/js/app.js'])
    @endif
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0"></script>
    <script src="https://cdn.jsdelivr.net/npm/leaflet@1.9.4"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.min.css" />
    @vite(['resources/js/dashboards/collector.js'])
</head>
<body class="min-h-screen bg-slate-50 text-neutral-900 font-sans">
    <header class="sticky top-0 z-40 border-b bg-white shadow-sm">
        <div class="mx-auto max-w-7xl px-4 py-4 flex items-center justify-between">
            <a href="{{ route('landing') }}" class="flex items-center gap-2">
                <img src="{{ asset('logo_2.png') }}" alt="TupaChap Logo" class="h-8 rounded">
                <span class="ml-2 text-xs text-green-600 font-medium">COLLECTOR_ADMIN</span>
            </a>
            <nav class="flex items-center gap-6 text-sm">
                <a href="{{ route('collector.dashboard') }}" class="text-green-600 font-medium hover:text-green-700">Dashboard</a>
                <button id="company-profile-btn" type="button" class="text-neutral-600 hover:text-neutral-800">Company</button>
                <a href="#" class="text-neutral-600 hover:text-neutral-800">Reports</a>
                <a href="#" onclick="window.logout(event)" class="text-neutral-600 hover:text-neutral-800">Logout</a>
            </nav>
        </div>
    </header>

    <main class="mx-auto max-w-7xl px-4 py-8 space-y-8">
        <!-- Page Title -->
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-neutral-900">Fleet Management Dashboard</h1>
            <p class="text-neutral-600 mt-2">Monitor your drivers, manage operations, and track revenue</p>
        </div>

        <!-- Overview KPIs -->
        <section class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div class="rounded-lg border bg-white p-4 shadow-sm">
                <div class="text-sm text-neutral-600">Total Revenue</div>
                <div id="total-revenue" class="mt-2 text-2xl font-bold text-green-600">—</div>
                <div class="mt-2 text-xs text-neutral-500">Accumulated</div>
            </div>
            <div class="rounded-lg border bg-white p-4 shadow-sm">
                <div class="text-sm text-neutral-600">Active Drivers</div>
                <div id="active-drivers" class="mt-2 text-2xl font-bold text-blue-600">—</div>
                <div class="mt-2 text-xs text-neutral-500">Online now</div>
            </div>
            <div class="rounded-lg border bg-white p-4 shadow-sm">
                <div class="text-sm text-neutral-600">Pending Trips</div>
                <div id="pending-trips" class="mt-2 text-2xl font-bold text-amber-600">—</div>
                <div class="mt-2 text-xs text-neutral-500">In progress</div>
            </div>
            <div class="rounded-lg border bg-white p-4 shadow-sm">
                <div class="text-sm text-neutral-600">Completed This Month</div>
                <div id="completed-trips" class="mt-2 text-2xl font-bold text-purple-600">—</div>
                <div class="mt-2 text-xs text-neutral-500">This month</div>
            </div>
        </section>

        <!-- Revenue & Performance Chart -->
        <section class="rounded-lg border bg-white p-6 shadow-sm">
            <h2 class="text-lg font-semibold mb-4">Performance Overview</h2>
            <div class="h-80 rounded border bg-slate-50">
                <canvas id="performance-chart"></canvas>
            </div>
        </section>

        <!-- Fleet Management -->
        <section class="rounded-lg border bg-white p-6 shadow-sm">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-xl font-semibold">Fleet Management</h2>
                <button id="add-driver-btn" class="px-4 py-2 rounded bg-green-600 text-white text-sm hover:bg-green-700">+ Add Driver</button>
            </div>

            <div id="drivers-list" class="space-y-3">
                <div class="flex items-center justify-center h-32 text-neutral-400">Loading drivers...</div>
            </div>
        </section>

        <!-- Live Operations -->
        <section class="rounded-lg border bg-white p-6 shadow-sm">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-xl font-semibold">Live Fleet Tracking</h2>
                <div class="flex gap-2">
                    <button id="toggle-tracking" class="px-4 py-2 rounded bg-green-600 text-white text-sm hover:bg-green-700">Start Tracking</button>
                    <button id="stop-tracking" class="px-4 py-2 rounded bg-neutral-200 text-neutral-700 text-sm hover:bg-neutral-300" style="display: none;">Stop</button>
                </div>
            </div>

            <div id="map-container" class="h-96 rounded border bg-slate-50 overflow-hidden flex items-center justify-center text-neutral-400">
                <div id="map"></div>
                <div id="map-message">Click "Start Tracking" to view live vehicle locations</div>
            </div>

            <div class="mt-4 pt-4 border-t">
                <div id="live-updates" class="space-y-2 max-h-48 overflow-y-auto">
                    <div class="text-center text-neutral-400 text-sm py-4">No live updates yet</div>
                </div>
            </div>

            <div class="mt-4 pt-4 border-t text-xs text-neutral-500">
                <strong>WebSocket Endpoints:</strong>
                <div class="mt-2 font-mono text-xs">
                    <div>🚗 Fleet: wss://api.tupachap.com/api/ws/vehicles?token=JWT</div>
                    <div>📍 Trip: wss://api.tupachap.com/api/ws/customer/{trip_id}?token=JWT</div>
                </div>
            </div>
        </section>

        <!-- Fleet Directory -->
        <section class="rounded-lg border bg-white p-6 shadow-sm">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-xl font-semibold">Directory</h2>
                <button id="refresh-directory" class="px-3 py-1 text-sm rounded bg-blue-100 text-blue-700 hover:bg-blue-200">Refresh</button>
            </div>

            <div id="directory-section" class="space-y-4">
                <div class="flex items-center justify-center h-32 text-neutral-400">Loading directory...</div>
            </div>
        </section>
    </main>

    <footer class="border-t bg-white mt-12">
        <div class="mx-auto max-w-7xl px-4 py-6 text-xs text-neutral-500">© {{ date('Y') }} TupaChap • Fleet Management</div>
    </footer>

    <!-- Add Driver Modal -->
    <div id="driver-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div class="bg-white rounded-lg max-w-md w-full p-6">
            <h3 class="text-lg font-semibold mb-4">Add Driver</h3>
            <form id="driver-form" class="space-y-4 mb-6">
                <div>
                    <label class="block text-sm font-medium text-neutral-700 mb-1">Phone Number</label>
                    <input type="tel" name="phone_number" required class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-green-600 focus:border-transparent" placeholder="255712345678">
                </div>
                <div>
                    <label class="block text-sm font-medium text-neutral-700 mb-1">Password</label>
                    <input type="password" name="password" required class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-green-600 focus:border-transparent" placeholder="Strong password">
                </div>
                <div>
                    <label class="block text-sm font-medium text-neutral-700 mb-1">Vehicle Type</label>
                    <select name="vehicle_type" required class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-green-600 focus:border-transparent">
                        <option value="">Select vehicle type</option>
                        <option value="TRUCK">Truck</option>
                        <option value="TRICYCLE">Tricycle</option>
                        <option value="MOTORCYCLE">Motorcycle</option>
                        <option value="HANDCART">Hand Cart</option>
                    </select>
                </div>
            </form>
            <div class="flex gap-3">
                <button onclick="window.closeDriverModal()" class="flex-1 px-4 py-2 rounded border border-neutral-200 text-neutral-700 hover:bg-neutral-50">Cancel</button>
                <button onclick="window.submitDriverForm()" class="flex-1 px-4 py-2 rounded bg-green-600 text-white hover:bg-green-700">Add</button>
            </div>
        </div>
    </div>

    <!-- Driver Details Modal -->
    <div id="driver-details-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div class="bg-white rounded-lg max-w-md w-full p-6">
            <h3 id="driver-details-title" class="text-lg font-semibold mb-4"></h3>
            <div id="driver-details-content" class="space-y-3 mb-6 text-sm text-neutral-600"></div>
            <div class="flex gap-3">
                <button onclick="window.closeDriverDetailsModal()" class="flex-1 px-4 py-2 rounded border border-neutral-200 text-neutral-700 hover:bg-neutral-50">Close</button>
                <button id="driver-remove-btn" class="flex-1 px-4 py-2 rounded border border-red-200 text-red-600 hover:bg-red-50">Remove</button>
            </div>
        </div>
    </div>

    <div id="company-profile-modal" class="hidden fixed inset-0 z-50 bg-black/50 px-4 py-6 flex items-center justify-center">
        <div class="w-full max-w-lg rounded-lg bg-white p-6 shadow-2xl">
            <div class="flex items-start justify-between gap-4 mb-5">
                <div>
                    <h3 class="text-lg font-semibold text-neutral-900">Company Profile</h3>
                    <p class="text-sm text-neutral-600 mt-1">Update your collector account details.</p>
                </div>
                <button type="button" onclick="window.closeCompanyProfileModal()" class="text-neutral-400 hover:text-neutral-700">✕</button>
            </div>

            <div id="company-profile-status" class="mb-4 text-sm"></div>

            <form id="company-profile-form" class="grid gap-4" onsubmit="window.submitCompanyProfileForm(event)">
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-neutral-700 mb-1">First Name</label>
                        <input type="text" name="first_name" class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-green-600 focus:border-transparent" placeholder="Optional">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-neutral-700 mb-1">Last Name</label>
                        <input type="text" name="last_name" class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-green-600 focus:border-transparent" placeholder="Optional">
                    </div>
                </div>
                <div>
                    <label class="block text-sm font-medium text-neutral-700 mb-1">Phone Number</label>
                    <input type="tel" name="phone_number" class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-green-600 focus:border-transparent" placeholder="255712345678">
                </div>
                <div>
                    <label class="block text-sm font-medium text-neutral-700 mb-1">Company Name</label>
                    <input type="text" name="company_name" class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-green-600 focus:border-transparent" placeholder="Collector company name">
                </div>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-neutral-700 mb-1">TIN Number</label>
                        <input type="text" name="tin_number" class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-green-600 focus:border-transparent" placeholder="Optional">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-neutral-700 mb-1">Ward ID</label>
                        <input type="text" name="ward_id" class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-green-600 focus:border-transparent" placeholder="Optional">
                    </div>
                </div>
                <div class="flex gap-3 pt-2">
                    <button type="button" onclick="window.closeCompanyProfileModal()" class="flex-1 px-4 py-2 rounded border border-neutral-200 text-neutral-700 hover:bg-neutral-50">Cancel</button>
                    <button type="submit" class="flex-1 px-4 py-2 rounded bg-green-600 text-white hover:bg-green-700">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
