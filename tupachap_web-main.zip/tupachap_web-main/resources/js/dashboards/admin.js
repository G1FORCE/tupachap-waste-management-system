import { adminApi } from '../api/admin.js';
import WebSocketManager from '../utils/websocket.js';
import { authUtils } from '../utils/auth.js';
import { formatters } from '../utils/formatting.js';

let wsManager = null;
let wardChart = null;
let currentCollectorId = null;

// Check authentication
if (!authUtils.isAuthenticated()) {
    authUtils.redirectToLogin();
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadPendingCollectors();
    loadWardActivity();
    loadHeatmapData();
    loadFleetDirectory();
    setupEventListeners();
});

// Load Pending Collectors
async function loadPendingCollectors() {
    try {
        const response = await adminApi.getPendingCollectors();
        const collectors = response.data.data || [];
        
        const listEl = document.getElementById('pending-list');
        document.getElementById('pending-count').textContent = collectors.length;

        if (collectors.length === 0) {
            listEl.innerHTML = '<div class="text-center py-8 text-neutral-400">No pending collectors</div>';
            return;
        }

        listEl.innerHTML = collectors.map(collector => `
            <div class="flex items-start justify-between p-4 border rounded-lg bg-slate-50 hover:bg-slate-100 transition">
                <div>
                    <h4 class="font-semibold text-neutral-900">${collector.company_name}</h4>
                    <div class="text-sm text-neutral-600 mt-1">
                        <div>📞 ${formatters.phoneNumber(collector.phone_number)}</div>
                        <div>🏢 TIN: ${collector.tin_number}</div>
                        <div class="text-xs text-neutral-500 mt-1">Registered: ${formatters.date(collector.created_at)}</div>
                    </div>
                </div>
                <button onclick="window.viewCollectorDetails('${collector.id}', '${collector.company_name}')" class="px-3 py-1 rounded bg-blue-600 text-white text-sm hover:bg-blue-700">Review</button>
            </div>
        `).join('');
    } catch (error) {
        console.error('Failed to load pending collectors', error);
        document.getElementById('pending-list').innerHTML = '<div class="text-center py-8 text-red-500">Failed to load pending collectors</div>';
    }
}

// Load Ward Activity
async function loadWardActivity() {
    try {
        // Wait for Chart.js to be available
        while (!window.Chart) {
            await new Promise(r => setTimeout(r, 100));
        }

        const response = await adminApi.getWardActivity();
        const wards = response.data.data || [];

        const ctx = document.getElementById('ward-chart').getContext('2d');
        
        if (wardChart) wardChart.destroy();

        wardChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: wards.map(w => w.ward || w.ward_name),
                datasets: [{
                    label: 'Trip Volume',
                    data: wards.map(w => w.total_trips || w.trip_count),
                    backgroundColor: '#2563eb',
                    borderRadius: 8,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
    } catch (error) {
        console.error('Failed to load ward activity', error);
    }
}

// Load Heatmap Data
async function loadHeatmapData() {
    try {
        // Wait for Leaflet to be available
        while (!window.L) {
            await new Promise(r => setTimeout(r, 100));
        }

        const response = await adminApi.getHeatmapData();
        const data = response.data.data || [];

        const map = L.map('heatmap').setView([-6.7924, 39.2083], 11);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(map);

        // Color map for waste types
        const wasteTypeColors = {
            'SOLID_GENERAL': '#ef4444',
            'SOLID_RECYCLABLE': '#3b82f6',
            'ORGANIC': '#22c55e',
            'HAZARDOUS': '#a855f7',
            'LIQUID': '#f59e0b',
            'BULK': '#06b6d4'
        };

        // Add heatmap points with waste type coloring
        data.forEach(point => {
            const wasteType = (point.type && point.type[0]) || 'SOLID_GENERAL';
            const color = wasteTypeColors[wasteType] || '#6b7280';
            
            L.circleMarker([point.lat, point.lon], {
                radius: Math.max(4, point.weight * 3),
                fillColor: color,
                color: color,
                weight: 1,
                opacity: 0.8,
                fillOpacity: 0.6,
                title: `${wasteType} (weight: ${point.weight})`
            }).bindPopup(`<strong>${wasteType}</strong><br>Weight: ${point.weight}`).addTo(map);
        });

        // Add legend
        const legend = L.control({ position: 'bottomright' });
        legend.onAdd = function(map) {
            const div = L.DomUtil.create('div', 'bg-white p-2 rounded border shadow-lg text-xs');
            div.innerHTML = `
                <div class="mb-1 font-semibold">Waste Types</div>
                <div class="space-y-1">
                    <div><span class="inline-block w-3 h-3 rounded-full mr-1" style="background: ${wasteTypeColors['SOLID_GENERAL']}"></span>General</div>
                    <div><span class="inline-block w-3 h-3 rounded-full mr-1" style="background: ${wasteTypeColors['SOLID_RECYCLABLE']}"></span>Recyclable</div>
                    <div><span class="inline-block w-3 h-3 rounded-full mr-1" style="background: ${wasteTypeColors['ORGANIC']}"></span>Organic</div>
                </div>
            `;
            return div;
        };
        legend.addTo(map);
    } catch (error) {
        console.error('Failed to load heatmap', error);
    }
}

// Load Fleet Directory
async function loadFleetDirectory() {
    try {
        const response = await adminApi.getVerifiedDirectory();
        const fleets = response.data.data || [];

        document.getElementById('verified-count').textContent = fleets.length;
        
        const listEl = document.getElementById('directory-list');
        if (fleets.length === 0) {
            listEl.innerHTML = '<div class="text-center py-8 text-neutral-400">No verified fleets</div>';
            return;
        }

        listEl.innerHTML = fleets.map(fleet => `
            <div class="border rounded-lg p-4 bg-slate-50">
                <div class="flex items-start justify-between mb-3">
                    <div>
                        <h4 class="font-semibold text-neutral-900">${fleet.company_name}</h4>
                        <div class="text-sm text-neutral-600 mt-1">
                            <div>📞 ${formatters.phoneNumber(fleet.phone_number)}</div>
                            <div>🏢 TIN: ${fleet.tin_number}</div>
                        </div>
                    </div>
                    <span class="px-3 py-1 rounded bg-green-100 text-green-700 text-xs font-medium">Verified</span>
                </div>
                <div class="text-sm text-neutral-600">
                    <strong>Active Drivers:</strong> ${fleet.drivers?.length || 0}
                </div>
                ${fleet.drivers && fleet.drivers.length > 0 ? `
                    <div class="mt-3 pt-3 border-t text-xs space-y-1">
                        ${fleet.drivers.slice(0, 3).map(d => `<div class="text-neutral-600">• ${d.driver_name} (${d.vehicle_type})</div>`).join('')}
                        ${fleet.drivers.length > 3 ? `<div class="text-neutral-500">+ ${fleet.drivers.length - 3} more</div>` : ''}
                    </div>
                ` : ''}
            </div>
        `).join('');
    } catch (error) {
        console.error('Failed to load directory', error);
    }
}

// WebSocket Monitoring
function setupEventListeners() {
    document.getElementById('refresh-pending').addEventListener('click', loadPendingCollectors);
    document.getElementById('refresh-directory').addEventListener('click', loadFleetDirectory);
    
    document.getElementById('toggle-vehicles').addEventListener('click', () => {
        if (!wsManager) {
            wsManager = new WebSocketManager();
            wsManager.connect('/api/ws/vehicles', {
                onMessage: handleVehicleUpdate,
                onClose: () => {
                    document.getElementById('toggle-vehicles').textContent = 'Monitor Vehicles';
                    document.getElementById('disconnect-all').style.display = 'none';
                }
            });
            document.getElementById('toggle-vehicles').textContent = 'Connected ✓';
            document.getElementById('disconnect-all').style.display = 'inline-block';
        } else {
            wsManager.disconnectAll();
            wsManager = null;
        }
    });

    document.getElementById('disconnect-all').addEventListener('click', () => {
        if (wsManager) {
            wsManager.disconnectAll();
            wsManager = null;
            document.getElementById('toggle-vehicles').textContent = 'Monitor Vehicles';
            document.getElementById('disconnect-all').style.display = 'none';
            document.getElementById('live-feed').innerHTML = '<div class="text-center text-neutral-400 py-8">Disconnected</div>';
        }
    });

    // Modal handlers
    document.getElementById('modal-approve').addEventListener('click', () => verifyCollector(true));
    document.getElementById('modal-reject').addEventListener('click', () => verifyCollector(false));
}

function handleVehicleUpdate(data) {
    const feed = document.getElementById('live-feed');
    if (feed.querySelector('.text-center')) feed.innerHTML = '';

    const entry = document.createElement('div');
    entry.className = 'p-3 border rounded bg-slate-50 text-sm';
    entry.innerHTML = `
        <strong>${data.driver_id}</strong>
        <div class="text-neutral-600">📍 ${data.lat.toFixed(4)}, ${data.lon.toFixed(4)}</div>
        <div class="text-neutral-600">🧭 Heading: ${data.heading}° | Speed: ${data.speed}km/h</div>
        <div class="text-xs text-neutral-500">${new Date().toLocaleTimeString()}</div>
    `;
    feed.prepend(entry);
    if (feed.children.length > 20) feed.removeChild(feed.lastChild);
}

window.viewCollectorDetails = (id, name) => {
    currentCollectorId = id;
    document.getElementById('modal-title').textContent = `Verify "${name}"?`;
    document.getElementById('modal-content').innerHTML = `
        <p>Review the application details and approve or reject.</p>
        <div class="text-xs text-neutral-500 font-mono">ID: ${id}</div>
    `;
    document.getElementById('verification-modal').classList.remove('hidden');
};

async function verifyCollector(approve) {
    if (!currentCollectorId) return;
    try {
        await adminApi.verifyCollector(currentCollectorId, approve);
        document.getElementById('verification-modal').classList.add('hidden');
        loadPendingCollectors();
    } catch (error) {
        alert('Failed to verify collector: ' + error.message);
    }
}

window.logout = (e) => {
    e.preventDefault();
    authUtils.clearTokens();
    window.location.href = '/login';
};
