import { collectorApi } from '../api/collector.js';
import WebSocketManager from '../utils/websocket.js';
import { authUtils } from '../utils/auth.js';
import { formatters } from '../utils/formatting.js';

let wsManager = null;
let performanceChart = null;
let map = null;
let currentDriverId = null;
let vehicleMarkers = new Map();

// Check authentication
if (!authUtils.isAuthenticated()) {
    authUtils.redirectToLogin();
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadDashboardOverview();
    loadDriversList();
    loadFleetDirectory();
    setupEventListeners();
});

// Load Dashboard Overview
async function loadDashboardOverview() {
    try {
        const response = await collectorApi.getDashboardOverview();
        const data = response.data || {};

        document.getElementById('total-revenue').textContent = formatters.currency(data.total_fleet_revenue_tzs);
        document.getElementById('active-drivers').textContent = data.active_drivers || 0;
        document.getElementById('pending-trips').textContent = data.pending_trips || 0;
        document.getElementById('completed-trips').textContent = data.total_fleet_trips || 0;

        // Create performance chart
        createPerformanceChart(data);
    } catch (error) {
        console.error('Failed to load dashboard overview', error);
    }
}

function createPerformanceChart(data) {
    const ctx = document.getElementById('performance-chart').getContext('2d');

    if (performanceChart) performanceChart.destroy();

    performanceChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
            datasets: [{
                label: 'Revenue (TZS)',
                data: [150000, 180000, 165000, 220000],
                borderColor: '#16a34a',
                backgroundColor: 'rgba(22, 163, 74, 0.1)',
                tension: 0.4,
                fill: true,
            }, {
                label: 'Trips Completed',
                data: [45, 52, 48, 65],
                borderColor: '#2563eb',
                backgroundColor: 'rgba(37, 99, 235, 0.1)',
                tension: 0.4,
                fill: true,
                yAxisID: 'y1',
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: true }
            },
            scales: {
                y: { beginAtZero: true, title: { display: true, text: 'Revenue' } },
                y1: { type: 'linear', position: 'right', beginAtZero: true, title: { display: true, text: 'Trips' } }
            }
        }
    });
}

// Load Drivers List
async function loadDriversList() {
    try {
        const response = await collectorApi.getFleetDrivers();
        const drivers = response.data.data || [];

        const listEl = document.getElementById('drivers-list');
        if (drivers.length === 0) {
            listEl.innerHTML = '<div class="text-center py-8 text-neutral-400">No drivers yet. Add one to get started.</div>';
            return;
        }

        listEl.innerHTML = drivers.map(driver => `
            <div class="flex items-start justify-between p-4 border rounded-lg bg-slate-50 hover:bg-slate-100 transition">
                <div>
                    <h4 class="font-semibold text-neutral-900">${driver.driver_name}</h4>
                    <div class="text-sm text-neutral-600 mt-1">
                        <div>📞 ${formatters.phoneNumber(driver.phone_number)}</div>
                        <div>🚗 ${driver.vehicle_type}</div>
                        <div class="flex gap-4 mt-2">
                            <span class="text-xs ${driver.is_active ? 'text-green-600 font-medium' : 'text-neutral-500'}">
                                ${driver.is_active ? '🟢 Online' : '⚫ Offline'}
                            </span>
                            <span class="text-xs text-neutral-500">Trips: ${driver.completed_trips || 0}</span>
                        </div>
                    </div>
                </div>
                <button onclick="window.viewDriverDetails('${driver.wastepicker_id}', '${driver.driver_name}')" class="px-3 py-1 rounded bg-blue-100 text-blue-700 text-sm hover:bg-blue-200">Details</button>
            </div>
        `).join('');
    } catch (error) {
        console.error('Failed to load drivers', error);
    }
}

// Load Fleet Directory
async function loadFleetDirectory() {
    try {
        const response = await collectorApi.getVerifiedDirectory();
        const fleets = response.data.data || [];

        const sectionEl = document.getElementById('directory-section');
        if (fleets.length === 0) {
            sectionEl.innerHTML = '<div class="text-center py-8 text-neutral-400">No other verified fleets at this time</div>';
            return;
        }

        sectionEl.innerHTML = fleets.map(fleet => `
            <div class="border rounded-lg p-4 bg-slate-50">
                <div class="flex items-start justify-between">
                    <div>
                        <h4 class="font-semibold text-neutral-900">${fleet.company_name}</h4>
                        <div class="text-sm text-neutral-600 mt-1">
                            <div>📞 ${formatters.phoneNumber(fleet.phone_number)}</div>
                            <div>🚗 Active Drivers: ${fleet.drivers?.length || 0}</div>
                        </div>
                    </div>
                    <span class="px-3 py-1 rounded bg-green-100 text-green-700 text-xs font-medium">Verified</span>
                </div>
            </div>
        `).join('');
    } catch (error) {
        console.error('Failed to load directory', error);
    }
}

// Event Listeners
function setupEventListeners() {
    document.getElementById('company-profile-btn')?.addEventListener('click', openCompanyProfileModal);
    document.getElementById('add-driver-btn').addEventListener('click', () => {
        document.getElementById('driver-modal').classList.remove('hidden');
    });

    document.getElementById('refresh-directory').addEventListener('click', loadFleetDirectory);

    document.getElementById('toggle-tracking').addEventListener('click', () => {
        if (!wsManager) {
            wsManager = new WebSocketManager();
            wsManager.connect('/api/ws/vehicles', {
                onMessage: handleVehicleUpdate,
                onClose: () => {
                    document.getElementById('toggle-tracking').textContent = 'Start Tracking';
                    document.getElementById('stop-tracking').style.display = 'none';
                    if (map) {
                        map.remove();
                        map = null;
                    }
                }
            });

            // Initialize map
            const mapContainer = document.getElementById('map');
            mapContainer.innerHTML = '';
            mapContainer.style.width = '100%';
            mapContainer.style.height = '100%';
            map = L.map(mapContainer).setView([-6.7924, 39.2083], 12);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

            document.getElementById('toggle-tracking').textContent = 'Tracking ✓';
            document.getElementById('stop-tracking').style.display = 'inline-block';
        } else {
            wsManager.disconnectAll();
            wsManager = null;
        }
    });

    document.getElementById('stop-tracking').addEventListener('click', () => {
        if (wsManager) {
            wsManager.disconnectAll();
            wsManager = null;
            document.getElementById('toggle-tracking').textContent = 'Start Tracking';
            document.getElementById('stop-tracking').style.display = 'none';
            if (map) {
                map.remove();
                map = null;
            }
            vehicleMarkers.clear();
        }
    });
}

function openCompanyProfileModal() {
    const modal = document.getElementById('company-profile-modal');
    const status = document.getElementById('company-profile-status');

    if (!modal || !status) {
        return;
    }

    status.textContent = '';
    status.className = 'mb-4 text-sm';
    modal.classList.remove('hidden');
}

function closeCompanyProfileModal() {
    const modal = document.getElementById('company-profile-modal');
    const form = document.getElementById('company-profile-form');
    const status = document.getElementById('company-profile-status');

    if (modal) {
        modal.classList.add('hidden');
    }

    if (form) {
        form.reset();
    }

    if (status) {
        status.textContent = '';
        status.className = 'mb-4 text-sm';
    }
}

async function submitCompanyProfileForm(event) {
    event.preventDefault();

    const form = document.getElementById('company-profile-form');
    const status = document.getElementById('company-profile-status');

    if (!form || !status) {
        return;
    }

    const formData = new FormData(form);
    const payload = {};

    ['first_name', 'last_name', 'phone_number', 'company_name', 'tin_number', 'ward_id'].forEach((field) => {
        const value = String(formData.get(field) || '').trim();
        if (value) {
            payload[field] = value;
        }
    });

    if (Object.keys(payload).length === 0) {
        status.textContent = 'Add at least one field to update.';
        status.className = 'mb-4 text-sm text-red-600';
        return;
    }

    status.textContent = 'Saving company profile...';
    status.className = 'mb-4 text-sm text-neutral-600';

    try {
        await collectorApi.updateProfile(payload);
        status.textContent = 'Company profile updated successfully.';
        status.className = 'mb-4 text-sm text-green-600';
        setTimeout(closeCompanyProfileModal, 700);
    } catch (error) {
        status.textContent = `Update failed: ${error.response?.data?.detail || error.message}`;
        status.className = 'mb-4 text-sm text-red-600';
    }
}

function handleVehicleUpdate(data) {
    // Update live updates feed
    const feed = document.getElementById('live-updates');
    if (feed.querySelector('.text-center')) feed.innerHTML = '';

    const entry = document.createElement('div');
    entry.className = 'p-2 border rounded bg-slate-50 text-xs';
    entry.innerHTML = `
        <strong>${data.driver_id}</strong>
        <div class="text-neutral-600">📍 ${data.lat.toFixed(4)}, ${data.lon.toFixed(4)}</div>
        <div class="text-neutral-600">🧭 ${data.heading}° | 📊 ${data.speed}km/h</div>
    `;
    feed.prepend(entry);
    if (feed.children.length > 15) feed.removeChild(feed.lastChild);

    // Update map marker
    if (map && data.lat && data.lon) {
        if (!vehicleMarkers.has(data.driver_id)) {
            const marker = L.marker([data.lat, data.lon]).addTo(map);
            marker.bindPopup(`<strong>${data.driver_id}</strong><br>Speed: ${data.speed}km/h`);
            vehicleMarkers.set(data.driver_id, marker);
        } else {
            vehicleMarkers.get(data.driver_id).setLatLng([data.lat, data.lon]);
        }
    }
}

window.viewDriverDetails = (id, name) => {
    currentDriverId = id;
    document.getElementById('driver-details-title').textContent = name;
    document.getElementById('driver-details-content').innerHTML = `
        <p>Driver ID: <code class="text-xs bg-slate-100 px-1 rounded">${id}</code></p>
        <p>Status: Active</p>
        <p>Total Trips: 127</p>
        <p>Average Rating: ⭐ 4.8</p>
    `;
    document.getElementById('driver-remove-btn').onclick = () => removeDriver(id);
    document.getElementById('driver-details-modal').classList.remove('hidden');
};

window.closeDriverModal = () => {
    document.getElementById('driver-modal').classList.add('hidden');
    document.getElementById('driver-form').reset();
};

window.closeCompanyProfileModal = closeCompanyProfileModal;

window.closeDriverDetailsModal = () => {
    document.getElementById('driver-details-modal').classList.add('hidden');
};

async function removeDriver(id) {
    if (!confirm('Remove this driver?')) return;
    try {
        await collectorApi.removeDriver(id);
        window.closeDriverDetailsModal();
        loadDriversList();
    } catch (error) {
        alert('Failed to remove driver: ' + error.message);
    }
}

async function submitDriverForm() {
    const form = document.getElementById('driver-form');
    const formData = new FormData(form);

    try {
        await collectorApi.addDriver({
            phone_number: formData.get('phone_number'),
            password: formData.get('password'),
            vehicle_type: formData.get('vehicle_type'),
        });
        window.closeDriverModal();
        loadDriversList();
        loadDashboardOverview();
    } catch (error) {
        alert('Failed to add driver: ' + error.message);
    }
}

window.submitDriverForm = submitDriverForm;
window.submitCompanyProfileForm = submitCompanyProfileForm;
window.logout = (e) => {
    e.preventDefault();
    authUtils.clearTokens();
    window.location.href = '/login';
};
