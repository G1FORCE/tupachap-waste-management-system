import { collectorApi } from './api/collector.js';
import { authUtils } from './utils/auth.js';

const apiBaseUrl = window.__TUPACHAP_CONFIG__?.API_URL || import.meta.env.VITE_API_URL || 'https://tupachap-engine.onrender.com';

document.addEventListener('DOMContentLoaded', () => {
	setupLoginForm();
	setupCollectorRegistration();
});

function setupLoginForm() {
	const form = document.getElementById('login-form');
	if (!form) {
		return;
	}

	const button = document.getElementById('login-btn');
	const spinner = document.getElementById('login-spinner');
	const text = document.getElementById('login-text');

	form.addEventListener('submit', async (event) => {
		event.preventDefault();

		const username = document.getElementById('username').value;
		const password = document.getElementById('password').value;

		button.disabled = true;
		spinner.classList.remove('hidden');
		text.textContent = 'Signing In';

		try {
			const response = await fetch(`${apiBaseUrl}/api/auth/login`, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded',
				},
				body: new URLSearchParams({
					username,
					password,
				}),
			});

			const data = await response.json();

			if (!response.ok) {
				throw new Error(data.detail || data.message || 'Login failed');
			}

			authUtils.setToken(data.access_token, data.refresh_token);

			const payload = decodeJwtPayload(data.access_token);
			const role = payload.role || payload?.sub?.role;

			if (role === 'SYS_ADMIN') {
				window.location.href = '/admin';
				return;
			}

			if (role === 'COLLECTOR_ADMIN') {
				window.location.href = '/collector';
				return;
			}

			throw new Error(`Unknown role: ${role}`);
		} catch (error) {
			console.error('Login error:', error);
			alert(`Login failed: ${getErrorMessage(error)}`);
		} finally {
			spinner.classList.add('hidden');
			text.textContent = 'Sign In';
			button.disabled = false;
		}
	});
}

function setupCollectorRegistration() {
	const openButton = document.getElementById('open-register-modal');
	const modal = document.getElementById('collector-register-modal');
	const closeButton = document.getElementById('close-register-modal');
	const form = document.getElementById('collector-register-form');
	const status = document.getElementById('register-status');

	if (!openButton || !modal || !closeButton || !form || !status) {
		return;
	}

	const closeModal = () => {
		modal.classList.add('hidden');
		form.reset();
		status.textContent = '';
		status.className = 'mb-4 text-sm';
	};

	openButton.addEventListener('click', () => {
		status.textContent = '';
		status.className = 'mb-4 text-sm';
		modal.classList.remove('hidden');
	});

	closeButton.addEventListener('click', closeModal);
	modal.addEventListener('click', (event) => {
		if (event.target === modal) {
			closeModal();
		}
	});

	form.addEventListener('submit', async (event) => {
		event.preventDefault();

		const formData = new FormData(form);
		const payload = {
			phone_number: String(formData.get('phone_number') || '').trim(),
			password: String(formData.get('password') || '').trim(),
			company_name: String(formData.get('company_name') || '').trim(),
		};

		const tinNumber = String(formData.get('tin_number') || '').trim();
		if (tinNumber) {
			payload.tin_number = tinNumber;
		}

		status.textContent = 'Submitting registration...';
		status.className = 'mb-4 text-sm text-neutral-600';

		try {
			await collectorApi.registerCompany(payload);
			status.textContent = 'Registration submitted successfully. Wait for verification before logging in.';
			status.className = 'mb-4 text-sm text-green-600';
			form.reset();
		} catch (error) {
			status.textContent = `Registration failed: ${getErrorMessage(error)}`;
			status.className = 'mb-4 text-sm text-red-600';
		}
	});
}

function decodeJwtPayload(token) {
	const payloadPart = token.split('.')[1];

	if (!payloadPart) {
		return {};
	}

	const normalized = payloadPart.replace(/-/g, '+').replace(/_/g, '/');
	const padded = normalized + '='.repeat((4 - (normalized.length % 4)) % 4);

	return JSON.parse(atob(padded));
}

function getErrorMessage(error) {
	return error?.response?.data?.detail || error?.response?.data?.message || error.message || 'Request failed';
}
