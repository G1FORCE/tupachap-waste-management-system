import client from './client.js';

export const adminApi = {
    // Collector Verification
    getPendingCollectors() {
        return client.get('/api/admin/collectors/pending');
    },

    verifyCollector(collectorId, approve) {
        return client.patch(`/api/admin/collectors/${collectorId}/verify`, {
            approve,
        });
    },

    // Analytics
    getWardActivity() {
        return client.get('/api/analytics/admin/wards');
    },

    getHeatmapData() {
        return client.get('/api/analytics/admin/heatmap');
    },

    // Fleet Directory
    getVerifiedDirectory() {
        return client.get('/api/admin/fleet/verified-directory');
    },
};
