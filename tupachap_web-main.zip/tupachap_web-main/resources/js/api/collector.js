import client from './client.js';

export const collectorApi = {
    // Registration and profile
    registerCompany(companyData) {
        return client.post('/api/fleet/register-company', companyData);
    },

    updateProfile(profileData) {
        return client.patch('/api/fleet/profile', profileData);
    },

    // Dashboard Overview
    getDashboardOverview() {
        return client.get('/api/analytics/collector/dashboard');
    },

    // Fleet Management
    addDriver(driverData) {
        return client.post('/api/fleet/add-driver', driverData);
    },

    getFleetDrivers() {
        return client.get('/api/fleet/drivers');
    },

    updateDriver(driverId, driverData) {
        return client.patch(`/api/fleet/drivers/${driverId}`, driverData);
    },

    removeDriver(driverId) {
        return client.delete(`/api/fleet/drivers/${driverId}`);
    },

    // Directory
    getVerifiedDirectory() {
        return client.get('/api/admin/fleet/verified-directory');
    },
};
