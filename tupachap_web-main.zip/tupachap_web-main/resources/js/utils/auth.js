export const authUtils = {
    getToken() {
        return localStorage.getItem('access_token');
    },

    setToken(accessToken, refreshToken) {
        localStorage.setItem('access_token', accessToken);
        if (refreshToken) {
            localStorage.setItem('refresh_token', refreshToken);
        }
    },

    getRefreshToken() {
        return localStorage.getItem('refresh_token');
    },

    clearTokens() {
        localStorage.removeItem('access_token');
        localStorage.removeItem('refresh_token');
    },

    isAuthenticated() {
        return !!this.getToken();
    },

    redirectToLogin() {
        this.clearTokens();
        window.location.href = '/login';
    },
};
