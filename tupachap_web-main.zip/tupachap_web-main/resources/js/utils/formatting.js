export const formatters = {
    currency(value, currency = 'TZS') {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency,
            minimumFractionDigits: 0,
        }).format(value);
    },

    number(value) {
        return new Intl.NumberFormat('en-US').format(value);
    },

    date(dateString) {
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
        });
    },

    datetime(dateString) {
        return new Date(dateString).toLocaleString('en-US');
    },

    phoneNumber(phone) {
        // Format as +255 XXX XXX XXX
        if (!phone) return '';
        const cleaned = phone.replace(/\D/g, '');
        if (cleaned.startsWith('255')) {
            return `+${cleaned.slice(0, 3)} ${cleaned.slice(3, 6)} ${cleaned.slice(6)}`;
        }
        return phone;
    },
};
