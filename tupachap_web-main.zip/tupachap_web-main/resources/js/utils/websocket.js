export class WebSocketManager {
    constructor(baseUrl = null) {
        this.baseUrl = baseUrl || (window.__TUPACHAP_CONFIG__?.WS_URL || import.meta.env.VITE_WS_URL || 'wss://tupachap-engine.onrender.com');
        this.connections = new Map();
        this.reconnectAttempts = new Map();
        this.maxReconnectAttempts = 5;
        this.reconnectDelay = 3000;
    }

    connect(path, handlers = {}) {
        const token = localStorage.getItem('access_token');
        if (!token) {
            console.error('No authentication token available');
            return null;
        }

        const url = `${this.baseUrl}${path}?token=${token}`;
        
        try {
            const ws = new WebSocket(url);
            
            ws.onopen = () => {
                console.log(`WebSocket connected to ${path}`);
                this.reconnectAttempts.delete(path);
                // Start ping to keep connection alive
                this.startPing(ws);
                if (handlers.onOpen) handlers.onOpen();
            };

            ws.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    if (handlers.onMessage) handlers.onMessage(data);
                } catch (e) {
                    console.error('Failed to parse WebSocket message', e);
                }
            };

            ws.onerror = (event) => {
                console.error(`WebSocket error on ${path}`, event);
                if (handlers.onError) handlers.onError(event);
            };

            ws.onclose = () => {
                console.log(`WebSocket closed for ${path}`);
                this.connections.delete(path);
                if (handlers.onClose) handlers.onClose();
                // Attempt to reconnect
                this.reconnect(path, handlers);
            };

            this.connections.set(path, ws);
            return ws;
        } catch (error) {
            console.error(`Failed to connect WebSocket to ${path}`, error);
            return null;
        }
    }

    reconnect(path, handlers) {
        const attempts = (this.reconnectAttempts.get(path) || 0) + 1;
        
        if (attempts > this.maxReconnectAttempts) {
            console.warn(`Max reconnection attempts reached for ${path}`);
            return;
        }

        this.reconnectAttempts.set(path, attempts);
        console.log(`Reconnecting to ${path} (attempt ${attempts}/${this.maxReconnectAttempts})`);
        
        setTimeout(() => {
            this.connect(path, handlers);
        }, this.reconnectDelay * attempts);
    }

    startPing(ws) {
        const pingInterval = setInterval(() => {
            if (ws.readyState === WebSocket.OPEN) {
                ws.send(JSON.stringify({ type: 'ping' }));
            } else {
                clearInterval(pingInterval);
            }
        }, 30000); // Ping every 30 seconds
    }

    send(path, data) {
        const ws = this.connections.get(path);
        if (ws && ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify(data));
        } else {
            console.warn(`WebSocket not connected to ${path}`);
        }
    }

    disconnect(path) {
        const ws = this.connections.get(path);
        if (ws) {
            ws.close();
            this.connections.delete(path);
        }
    }

    disconnectAll() {
        this.connections.forEach((ws) => ws.close());
        this.connections.clear();
    }
}

export default WebSocketManager;
