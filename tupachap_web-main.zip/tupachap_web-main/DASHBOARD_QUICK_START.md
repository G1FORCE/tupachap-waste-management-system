# Dashboard Quick Start Guide

## Installation

### 1. Install Dependencies
```bash
npm install
```

This will install Axios which is required for API calls.

### 2. Configuration

Create a `.env` file in the project root (copy from `.env.example`):

```env
VITE_API_URL=https://api.tupachap.com
VITE_WS_URL=wss://api.tupachap.com
```

### 3. Development Server

```bash
npm run dev
```

### 4. Build for Production

```bash
npm run build
```

## Accessing the Dashboards

### Admin Dashboard
- **URL**: `http://localhost/admin`
- **Login**: Phone `255712345678` / Password `admin_password`
- **Role**: SYS_ADMIN
- **Features**:
  - Verify collector applications
  - View ward activity analytics
  - Monitor waste heatmap
  - Track live vehicles
  - View fleet directory

### Collector Dashboard
- **URL**: `http://localhost/collector`
- **Login**: Phone `255787654321` / Password `collector_password`
- **Role**: COLLECTOR_ADMIN
- **Features**:
  - View revenue and performance metrics
  - Manage drivers
  - Track live fleet locations
  - Monitor pending trips
  - View directory of other companies

## File Structure Overview

### Views (Blade Templates)
- `resources/views/admin/dashboard.blade.php` - Admin dashboard UI
- `resources/views/collector/dashboard.blade.php` - Collector dashboard UI
- `resources/views/auth/login.blade.php` - Login page

### JavaScript Modules
- `resources/js/api/client.js` - Axios HTTP client with interceptors
- `resources/js/api/admin.js` - Admin API methods
- `resources/js/api/collector.js` - Collector API methods
- `resources/js/utils/websocket.js` - WebSocket manager class
- `resources/js/utils/auth.js` - Authentication utilities
- `resources/js/utils/formatting.js` - Data formatting utilities

### Backend
- `app/Http/Controllers/AuthController.php` - Authentication controller
- `app/Http/Middleware/CheckJwtToken.php` - JWT validation middleware
- `routes/web.php` - Web routes

## How It Works

### Authentication Flow
1. User navigates to `/login`
2. Enters phone number and password
3. Form submits to `POST /api/auth/login`
4. API returns JWT tokens
5. Tokens stored in browser localStorage
6. User redirected to appropriate dashboard based on role

### API Integration
- All API calls use Axios client from `resources/js/api/client.js`
- Authorization header automatically added to all requests
- Failed requests (401) auto-redirect to login
- Proper error handling with user feedback

### Real-time Updates
- WebSocket connections managed by `WebSocketManager` class
- Auto-reconnection with exponential backoff
- Ping/Pong heartbeat to keep connection alive
- Message handling with JSON parsing
- Graceful disconnection

### Data Visualization
- **Charts**: Chart.js for analytics (Ward Activity, Performance)
- **Maps**: Leaflet with OpenStreetMap for heatmap and tracking
- **Tables**: HTML tables with dynamic data rendering

## API Endpoints

### Authentication
- `POST /api/auth/login` - User login

### Admin Endpoints
- `GET /api/admin/collectors/pending` - List pending collectors
- `PATCH /api/admin/collectors/{id}/verify` - Verify collector
- `GET /api/analytics/admin/wards` - Ward activity data
- `GET /api/analytics/admin/heatmap` - Heatmap coordinates
- `GET /api/admin/fleet/verified-directory` - Fleet directory

### Collector Endpoints
- `GET /api/analytics/collector/dashboard` - Dashboard overview
- `POST /api/fleet/add-driver` - Add driver
- `GET /api/fleet/drivers` - List drivers
- `DELETE /api/fleet/drivers/{id}` - Remove driver
- `GET /api/admin/fleet/verified-directory` - Directory

### WebSocket
- `WS /api/ws/vehicles?token=JWT` - Live vehicle updates
- `WS /api/ws/customer/{trip_id}?token=JWT` - Trip tracking

## Key Features

### Admin Dashboard
✅ Pending Collector Verification with modal dialog
✅ One-click approve/reject functionality
✅ Real-time ward activity visualization
✅ Waste pickup heatmap with map pins
✅ Live vehicle monitoring via WebSocket
✅ Fleet directory with driver details
✅ Auto-refresh buttons
✅ Responsive grid layout

### Collector Dashboard
✅ Real-time KPI metrics (Revenue, Drivers, Trips)
✅ Performance trend chart
✅ Driver management (Add/Remove)
✅ Live fleet tracking on map
✅ Real-time vehicle location updates
✅ Active/Offline driver status
✅ Live updates feed
✅ Fleet directory

## Troubleshooting

### Login Issues
- Check phone number format (include country code: 255...)
- Verify credentials are correct
- Check browser console for API errors
- Ensure API URL in `.env` is correct

### API Connection Errors
- Verify `.env` has correct API URL
- Check CORS headers from API
- Ensure API server is running
- Test API endpoint in Postman

### WebSocket Connection Issues
- Check WSS URL in `.env`
- Ensure valid JWT token in localStorage
- Check browser console for connection errors
- Try refreshing the page

### Map Not Loading
- Verify Leaflet CDN is accessible
- Check browser console for JS errors
- Ensure proper permissions for geolocation

### Charts Not Rendering
- Check Chart.js CDN is accessible
- Verify API data returns correct format
- Check browser console for errors

## Browser Support

- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- Mobile browsers (iOS Safari, Chrome Android)

Requires:
- ES6+ JavaScript support
- localStorage API
- WebSocket API
- Fetch API

## Performance Tips

1. **Reduce WebSocket Traffic**: Disconnect when not viewing
2. **Optimize Images**: Use CDN for images
3. **Lazy Load Maps**: Only load when tracking is enabled
4. **Chart.js Limit**: Don't render too many charts simultaneously
5. **Local Storage**: Clear old data periodically

## Security Notes

⚠️ **Important for Production**:
- Move JWT tokens to httpOnly cookies
- Implement token refresh mechanism
- Add CSRF protection
- Implement rate limiting
- Use HTTPS/WSS only
- Sanitize all user inputs
- Implement CSP headers
- Validate all data server-side

## Next Steps

1. ✅ Install dependencies: `npm install`
2. ✅ Configure environment: Create `.env` file
3. ✅ Start dev server: `npm run dev`
4. ✅ Navigate to login page
5. ✅ Test with demo credentials
6. ✅ Explore dashboard features
7. ✅ Build for production: `npm run build`

## Support Resources

- **OpenAPI Spec**: `docs/openapi (1).json`
- **API Documentation**: 
  - `docs/admin_dashboard.md` - Admin endpoints
  - `docs/collector_dashboard.md` - Collector endpoints
  - `docs/general.md` - Common integration guide
- **Implementation Guide**: `DASHBOARD_IMPLEMENTATION.md`
- **Project Docs**: `docs/web_platform_plan.md`

## License

© 2024 TupaChap. All rights reserved.
