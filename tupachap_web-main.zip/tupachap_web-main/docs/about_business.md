# TupaChap: Modernizing Urban Waste Management

## Executive Summary
**TupaChap** is an on-demand, location-based dispatch platform for waste collection operating in Dar es Salaam, Tanzania. Often described as the "Bolt or Uber for waste disposal," TupaChap bridges the gap between urban residents who need immediate trash removal and the fragmented network of waste collectors. By applying a gig-economy model to municipal logistics, TupaChap ensures rapid, accountable, and transparent waste management.

The name is a portmanteau derived from Swahili: **"Tupa"** (to throw, dump, or dispose) and **"Chap"** (quickly, instantly), perfectly encapsulating the brand's promise of rapid disposal.

---

## The Problem
Dar es Salaam faces significant logistical challenges in urban waste management:
* **Inefficient Routing:** Waste collection vehicles often drive unoptimized routes, leading to high fuel consumption and missed neighborhoods.
* **Unreliable Service:** Households, especially in unplanned settlements, suffer from missed scheduled pickups and struggle to find reliable, formalized waste disposal.
* **Revenue Leakage:** Formal waste companies face challenges with unpaid residential collections and unaccounted cash transactions handled by drivers.
* **Illegal Dumping:** Without strict accountability, there is a risk of waste being disposed of in unauthorized areas rather than official municipal dumpsites.

---

## The TupaChap Solution
TupaChap solves these issues by digitizing the connection between waste generators (customers) and waste collectors (service providers) through a centralized platform.

### Core Capabilities
* **Smart Dispatching:** Customers are instantly matched with the nearest available and properly equipped waste collector based on their exact physical location.
* **Transparent Pricing:** Fares are determined either by municipal ward policies or via automated volume estimation, ensuring fair pricing before a trip is confirmed.
* **Cashless Economy:** All transactions are processed through integrated mobile money (M-Pesa, Tigo Pesa, etc.), guaranteeing payment for companies and eliminating cash handling risks.
* **Categorized Handling:** The platform intelligently categorizes waste (Solid, Recyclable, Organic, Liquid, Biohazard) to ensure the right vehicle is dispatched for the right job.

---

## Target Market & Customer Segments

TupaChap serves two distinct market segments with tailored operational flows:

### 1. Households (B2C)
* **Needs:** Convenience, flexibility, and affordability.
* **Service:** On-demand "Immediate Pickups" or fixed "Scheduled Pickups."
* **Pricing:** Pay-per-trip model based on volume or localized district/street fees.

### 2. Institutions & Corporates (B2B)
* **Target:** Hospitals, Schools, Corporate Offices, and Industrial Facilities.
* **Needs:** Compliance, specialized handling (e.g., medical waste), and reliable routines.
* **Service:** Recurring scheduled pickups handled by certified collection companies.
* **Pricing:** Pre-paid annual or semi-annual subscription contracts.

---

## Value Proposition

### For Customers (Waste Generators)
1. **Instant Relief:** No more waiting days for a missed truck; request a pickup exactly when needed.
2. **Reliability:** Live tracking provides exact arrival times.
3. **Safety & Health:** Prompt removal of sanitary, general, and biohazard waste.

### For Service Providers (Waste Management Companies & Operators)
1. **Reduced Operational Costs:** Location-based matching dramatically cuts down on fuel waste caused by blind roaming.
2. **Client Acquisition:** Instant access to a new pool of residential and corporate clients who request services through the platform.
3. **Guaranteed Revenue:** Mandatory mobile money integration means 100% collection rates on completed jobs.
4. **Fleet Management:** Complete oversight over vehicle locations and driver efficiency.

---

## Operational Accountability: The 3-Step Proof of Service
To guarantee trust and prevent fraud or illegal dumping, TupaChap enforces a strict 3-step verification process for every single collection:

1. **Location Verification (The Handover):** Upon arrival, the collector must scan a unique digital QR code presented by the customer, proving they are at the correct location.
2. **Collection Verification:** The collector must capture a photographic record of the loaded waste before transit begins.
3. **Disposal Verification (The Dumpsite):** The collector can only complete the job and trigger payment once they are physically present at an authorized municipal dumpsite (e.g., Pugu) and capture a final photographic record of the disposed waste.

---

## Brand Identity
TupaChap represents a modern, clean, and forward-thinking approach to sanitation.
* **Primary Color (Vibrant Green):** Represents the environment, sustainability, and trust.
* **Accent Color (Lime/Neon Green):** Represents energy, speed ("Chap"), and high visibility.
* **The Logo:** Features a stylized letter "U" designed to resemble a modern waste bin, seamlessly integrating the core service into the visual identity of the name.
