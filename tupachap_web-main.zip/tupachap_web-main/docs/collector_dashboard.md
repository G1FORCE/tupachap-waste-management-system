# Collector Dashboard Integration Guide

This document outlines the API endpoints and integration flow for the **Tupachap Collector Dashboard**, designed for waste management company owners (Collector Admins).

## 1. Authentication

Collector Admins use the standard login endpoint but must have the `COLLECTOR_ADMIN` role.

### Login
*   **Endpoint:** `POST /api/auth/login`
*   **Method:** `POST`
*   **Body (Form Data):**
    *   `username`: Phone number (e.g., `255712345678`)
    *   `password`: User's password
*   **Response:**
    ```json
    {
      "access_token": "JWT_TOKEN",
      "refresh_token": "REFRESH_TOKEN",
      "token_type": "bearer"
    }
    ```

### Register Collector Company
Open endpoint for new companies to join the platform.
*   **Endpoint:** `POST /api/fleet/register-company`
*   **Body:**
    ```json
    {
      "phone_number": "2557...",
      "password": "strongpassword",
      "company_name": "EcoWaste Ltd",
      "tin_number": "123-456-789"
    }
    ```

---

## 2. Fleet Management

Collector Admins can manage their drivers (Waste Pickers) and vehicles.

### Add Driver to Fleet
*   **Endpoint:** `POST /api/fleet/add-driver`
*   **Headers:** `Authorization: Bearer <JWT_TOKEN>`
*   **Body:**
    ```json
    {
      "phone_number": "2557...",
      "password": "driverpassword",
      "vehicle_type": "TRUCK" 
    }
    ```
    *Note: `vehicle_type` can be `TRUCK`, `TRICYCLE`, `MOTORCYCLE`, or `HANDCART`.*

---

## 3. Analytics & Reporting

### Dashboard Overview
Provides fleet-wide statistics including total revenue and active contracts.
*   **Endpoint:** `GET /api/analytics/collector/dashboard`
*   **Headers:** `Authorization: Bearer <JWT_TOKEN>`
*   **Response Snippet:**
    ```json
    {
      "total_revenue": 1500000,
      "active_drivers": 12,
      "pending_trips": 5,
      "completed_trips_this_month": 450
    }
    ```

---

## 4. Live Monitoring (WebSockets)

Collectors can monitor the live location of all vehicles in their fleet or track specific trips.

### Monitor All Fleet Vehicles
Connect to this WebSocket to receive live location updates for all active drivers.
*   **Path:** `ws://<base_url>/api/ws/vehicles?token=<JWT_TOKEN>`
*   **Message Format Received:**
    ```json
    {
      "type": "LOCATION_UPDATE",
      "driver_id": "uuid",
      "lat": -6.7924,
      "lon": 39.2083,
      "heading": 90,
      "speed": 15
    }
    ```

### Track Specific Trip
*   **Path:** `ws://<base_url>/api/ws/customer/<trip_id>?token=<JWT_TOKEN>`
*   **Note:** Although labeled `customer`, this endpoint allows any authorized user to listen to updates for a specific `trip_id`.

---

## 5. Directory

### Verified Fleet Directory
Shows all verified companies and their active drivers.
*   **Endpoint:** `GET /api/admin/fleet/verified-directory`
*   **Headers:** `Authorization: Bearer <JWT_TOKEN>`
