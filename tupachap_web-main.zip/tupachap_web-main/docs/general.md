# General Web Integration Guide

This document provides shared technical details for integrating with the Tupachap Backend via Web Dashboards (React, Vue, etc.).

## Base URL
- **Staging/Development**: `https://api.tupachap.com`
- **Websocket Base**: `wss://api.tupachap.com`

## Authentication

All web dashboards use JWT (JSON Web Tokens) for authentication.

### Login Flow
1. Send a `POST` request to `/api/auth/login` with `username` (phone number) and `password` as **Form Data** (`application/x-www-form-urlencoded`).
2. The API returns an `access_token` and `refresh_token`.
3. Include the `access_token` in the `Authorization` header for all protected endpoints:
   `Authorization: Bearer <your_access_token>`

## Common Response Wrapper

Most dashboard-specific endpoints return a standard wrapper:
```json
{
  "status": "success",
  "message": "Optional descriptive message",
  "data": { ... }
}
```

## Real-time Updates (WebSockets)

Dashboards should use the WebSocket API for live maps and status updates.

### Connection
- **Endpoint:** `wss://<base_url>/api/ws/<path>?token=<JWT_TOKEN>`
- **Security:** Tokens must be passed as a query parameter because standard browser WebSocket APIs do not support custom headers.

### Ping/Pong
To prevent connection timeouts (especially on Heroku/Render), dashboards should send a "ping" or receive a message every 30-60 seconds to keep the socket alive.

## Error Codes
- `400`: Validation error (check `detail` field).
- `401`: Token expired or invalid.
- `403`: Insufficient permissions (e.g., trying to access Admin routes with a Collector token).
- `500`: Server error.
