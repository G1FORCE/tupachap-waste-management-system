# TupaChap Web Platform Implementation Plan

This document outlines a technology-agnostic plan for building the TupaChap Landing Page and Dashboards (Admin & Collector).

## 1. Landing Page

### Core Objectives
*   Brand awareness and value proposition.
*   Lead generation for Collectors.
*   User acquisition for Customers (links to app stores).
*   Public-facing information about services and pricing.

### Information Architecture
*   **Hero Section:** High-impact visual + Clear Call to Action (CTA) for both Customers and Collectors.
*   **Problem/Solution:** Highlighting the challenges of waste management in Dar es Salaam and how TupaChap solves them.
*   **Service Tiers:** Overview of Household vs. Institutional (Hospital, School, etc.) services.
*   **For Collectors:** Benefits for waste management companies (Fleet management, digital verification).
*   **Pricing Overview:** General information on ward-based pricing.
*   **Footer:** Links to App Stores, Terms of Service, Privacy Policy, and Contact info.

---

## 2. System Admin Dashboard (SYS_ADMIN)

### Core Objectives
*   Platform governance and quality control.
*   High-level analytics and urban planning insights.
*   Collector lifecycle management.

### Key Functional Requirements
*   **Collector Verification Module:**
    *   List pending collector registrations.
    *   Review company details (TIN, contact info).
    *   Approve/Reject applications.
*   **Fleet Directory:**
    *   View all verified companies and their active drivers.
    *   Monitor fleet sizes and vehicle distributions.
*   **Platform Analytics (Spatial focus):**
    *   **Ward Activity Map:** Visualization of trip volume per municipal ward.
    *   **Waste Heatmap:** Point-based visualization of pickup density across the city.
*   **System Monitoring:**
    *   Live view of all active vehicles on a map (via WebSockets).
    *   Trip status tracking.

---

## 3. Collector Admin Dashboard (COLLECTOR_ADMIN)

### Core Objectives
*   Business operation management.
*   Fleet optimization and driver oversight.
*   Revenue tracking.

### Key Functional Requirements
*   **Fleet Management:**
    *   Register/Add new drivers (Wastepickers) to the fleet.
    *   Assign/Update vehicle types for drivers.
    *   Monitor driver online/offline status.
*   **Operational Analytics:**
    *   Total revenue tracking.
    *   Completed vs. Pending trips metrics.
    *   Active contract monitoring (for institutional clients).
*   **Live Operations:**
    *   Real-time map tracking of all fleet vehicles.
    *   Deep-dive into specific trip progress.
*   **Profile Management:**
    *   Update company details, TIN number, and ward association.

---

## 4. Technical Requirements (Technology-Agnostic)

### Integration Layer
*   **REST API:** All CRUD operations (Users, Trips, Analytics) must be performed via the existing Python FastAPI backend.
*   **WebSockets:** Real-time tracking modules must implement the `ws://` protocol for live location and trip updates.
*   **Authentication:** All dashboard sessions must be managed via JWT (JSON Web Tokens) stored securely.

### UI/UX Design Principles
*   **Responsive Design:** Dashboards should be usable on desktop and tablet.
*   **Map-Centric Interface:** Strong emphasis on GIS/Map components (Heatmaps, real-time marker updates).
*   **Data Visualization:** Use of charts and graphs for analytics (Revenue, Trip trends).

### Security
*   **Role-Based Access Control (RBAC):** Strict enforcement of `SYS_ADMIN` and `COLLECTOR_ADMIN` roles at the UI level (redirects) and API level (token validation).
*   **Data Isolation:** Collector admins must only see data related to their own fleet.

## 5. Implementation Roadmap
1.  **Wireframing:** Low-fidelity sketches of dashboard layouts.
2.  **API Mapping:** Finalizing the list of endpoints needed (most are already implemented).
3.  **UI Component Library Selection:** Choosing a kit that supports complex data tables and maps.
4.  **Landing Page Development:** Focus on SEO and mobile responsiveness.
5.  **Collector Dashboard Development:** Core fleet management features first.
6.  **Admin Dashboard Development:** Verification and Global Analytics.
