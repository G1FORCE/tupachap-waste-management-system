# System Admin Dashboard Integration Guide

This document outlines the API endpoints and integration flow for the **Tupachap System Admin Dashboard**, designed for platform administrators (SYS_ADMIN).

## 1. Authentication

System Admins must have the `SYS_ADMIN` role to access these endpoints.

### Login
*   **Endpoint:** `POST /api/auth/login`
*   **Method:** `POST`
*   **Body (Form Data):**
    *   `username`: Phone number
    *   `password`: Admin password
*   **Response:**
    ```json
    {
      "access_token": "JWT_TOKEN",
      "refresh_token": "REFRESH_TOKEN",
      "token_type": "bearer"
    }
    ```

---

## 2. Collector Verification Workflow

New collector companies must be manually verified by a System Admin before they can operate.

### List Pending Collectors
Fetch all collector companies awaiting verification.
*   **Endpoint:** `GET /api/admin/collectors/pending`
*   **Headers:** `Authorization: Bearer <JWT_TOKEN>`

### Verify/Approve Collector
Approve or reject a collector's application.
*   **Endpoint:** `PATCH /api/admin/collectors/{collector_id}/verify`
*   **Method:** `PATCH`
*   **Body:**
    ```json
    {
      "approve": true
    }
    ```
    *Set `approve: false` to reject and remove the application.*

---

## 3. Platform Analytics

### Ward Activity History
Shows which municipal wards are generating the most trip volume.
*   **Endpoint:** `GET /api/analytics/admin/wards`
*   **Headers:** `Authorization: Bearer <JWT_TOKEN>`

### Waste Heatmap Data
Returns raw coordinates of all completed pickups for visualization on a heatmap.
*   **Endpoint:** `GET /api/analytics/admin/heatmap`
*   **Headers:** `Authorization: Bearer <JWT_TOKEN>`
*   **Response:**
    ```json
    {
      "status": "success",
      "total_points": 1250,
      "data": [
        {"lat": -6.79, "lon": 39.20, "weight": 1},
        ...
      ]
    }
    ```

---

## 4. Platform Monitoring (WebSockets)

Admins can monitor the entire platform's live state.

### Global Vehicle Monitoring
Listen to all active vehicles across all fleets.
*   **Path:** `ws://<base_url>/api/ws/vehicles?token=<JWT_TOKEN>`

### Global Trip Monitoring
Admins can connect to any specific trip room to monitor progress.
*   **Path:** `ws://<base_url>/api/ws/customer/<trip_id>?token=<JWT_TOKEN>`

---

## 5. Global Fleet Directory

List all verified companies and their drivers.
*   **Endpoint:** `GET /api/admin/fleet/verified-directory`
*   **Headers:** `Authorization: Bearer <JWT_TOKEN>`
