# TupaChap Dashboard Implementation Guide

## Overview

This document outlines the complete implementation of the Admin and Collector dashboards for the TupaChap waste management platform.

## Features Implemented

### Admin Dashboard (SYS_ADMIN)

**Key Features:**
- ✅ Pending Collector Verification Module
- ✅ Collector Verification Modal (Approve/Reject)
- ✅ Ward Activity Analytics (Bar Chart)
- ✅ Waste Heatmap Visualization (Leaflet Map)
- ✅ Live Platform Monitoring (WebSocket)
- ✅ Verified Fleet Directory with Driver Information
- ✅ Real-time Statistics (Pending, Verified, Active Vehicles, Trips Today)

**API Endpoints Used:**
- `GET /api/admin/collectors/pending` - List pending collectors
- `PATCH /api/admin/collectors/{id}/verify` - Verify/Reject collectors
- `GET /api/analytics/admin/wards` - Ward activity data
- `GET /api/analytics/admin/heatmap` - Waste heatmap coordinates
- `GET /api/admin/fleet/verified-directory` - Verified fleets
- `WS /api/ws/vehicles` - Live vehicle tracking

### Collector Dashboard (COLLECTOR_ADMIN)

**Key Features:**
- ✅ Dashboard Overview with KPIs (Revenue, Drivers, Trips, Completion)
- ✅ Performance Analytics Chart (Revenue & Trips Trend)
- ✅ Fleet Management (Add/Remove Drivers)
- ✅ Driver Details Modal
- ✅ Live Fleet Tracking with Interactive Map
- ✅ Real-time Vehicle Location Updates
- ✅ Verified Fleet Directory
- ✅ Driver Modal Form with Validation

**API Endpoints Used:**
- `GET /api/analytics/collector/dashboard` - Dashboard overview
- `POST /api/fleet/add-driver` - Add new driver
- `GET /api/fleet/drivers` - List drivers
- `DELETE /api/fleet/drivers/{id}` - Remove driver
- `GET /api/admin/fleet/verified-directory` - Fleet directory
- `WS /api/ws/vehicles` - Live vehicle updates

## Authentication

### Login Flow

1. User navigates to `/login`
2. Form submits `POST /api/auth/login` with phone number and password
3. API returns `access_token` and `refresh_token`
4. Tokens stored in `localStorage`
5. User redirected based on role:
   - `SYS_ADMIN` → `/admin`
   - `COLLECTOR_ADMIN` → `/collector`

### Token Management

- Access token stored in `localStorage.access_token`
- Refresh token stored in `localStorage.refresh_token`
- Axios interceptor adds token to all requests
- Auto-logout on 401 Unauthorized

## Technical Stack

### Frontend
- **HTML5** - Semantic markup
- **CSS/Tailwind** - Responsive styling
- **JavaScript (ES6+)** - Client logic
- **Axios** - HTTP client
- **Chart.js** - Data visualization
- **Leaflet** - Map visualization
- **WebSocket API** - Real-time updates

### Backend Integration
- **REST API** - JSON communication
- **JWT Authentication** - Token-based auth
- **WebSocket** - Live data streaming

## File Structure

```
resources/
├── js/
│   ├── api/
│   │   ├── client.js          # Axios instance with interceptors
│   │   ├── admin.js           # Admin API methods
│   │   └── collector.js       # Collector API methods
│   └── utils/
│       ├── websocket.js       # WebSocket manager
│       ├── auth.js            # Auth utilities
│       └── formatting.js      # Formatter utilities
└── views/
    ├── admin/
    │   └── dashboard.blade.php # Admin dashboard
    ├── collector/
    │   └── dashboard.blade.php # Collector dashboard
    └── auth/
        └── login.blade.php     # Login page
```

## WebSocket Implementation

### Vehicle Monitoring

**Connection:** `wss://api.tupachap.com/api/ws/vehicles?token=JWT`

**Message Format:**
```json
{
  "type": "LOCATION_UPDATE",
  "driver_id": "uuid",
  "lat": -6.7924,
  "lon": 39.2083,
  "heading": 90,
  "speed": 15
}
```

### Features
- Auto-reconnection on connection loss
- Ping/Pong heartbeat every 30 seconds
- Max 5 reconnection attempts
- 3-second reconnect delay between attempts

## Configuration

### Environment Variables

Create a `.env` file with:

```env
VITE_API_URL=https://api.tupachap.com
VITE_WS_URL=wss://api.tupachap.com
```

These variables are available in JavaScript via `import.meta.env`:

```javascript
const API_BASE_URL = import.meta.env.VITE_API_URL || 'https://api.tupachap.com';
const WS_BASE_URL = import.meta.env.VITE_WS_URL || 'wss://api.tupachap.com';
```

## Styling

- **Tailwind CSS** for responsive design
- **Color scheme:**
  - Blue (`#2563eb`) - Primary
  - Green (`#16a34a`) - Success/Collector
  - Amber (`#f59e0b`) - Warning
  - Red (`#ef4444`) - Danger
  - Slate (`#64748b`) - Neutral

## Error Handling

### API Errors
- 401: Auto-redirect to login
- 403: Access denied
- 422: Validation errors
- 500: Server error

### WebSocket Errors
- Auto-reconnection with exponential backoff
- Max 5 attempts before giving up
- User notification on connection loss

## Features Breakdown

### Admin Dashboard Modules

#### 1. Collector Verification
- Lists pending collectors with company name, phone, TIN
- Modal dialog for review
- One-click approve/reject
- Real-time list refresh

#### 2. Ward Activity Chart
- Bar chart showing trip volume per ward
- Using Chart.js with responsive sizing
- Auto-update on data refresh

#### 3. Waste Heatmap
- Leaflet map with OpenStreetMap tiles
- Red circle markers for pickup locations
- Center on Dar es Salaam (-6.7924, 39.2083)
- Zoom level 11

#### 4. Live Monitoring
- Real-time WebSocket connection
- Incoming vehicle updates displayed
- Keeps last 20 updates
- Connect/Disconnect controls

#### 5. Fleet Directory
- Shows all verified collector companies
- Displays driver count per fleet
- Shows 3 driver previews per fleet
- Verified badge

### Collector Dashboard Modules

#### 1. KPI Cards
- Total Revenue (currency formatted)
- Active Drivers (count)
- Pending Trips (count)
- Completed This Month (count)

#### 2. Performance Chart
- Dual-axis line chart
- Revenue trend (TZS)
- Trip completion count
- 4-week historical data

#### 3. Fleet Management
- Table of drivers
- Driver status (Online/Offline)
- Quick details button
- Add driver modal
- Remove driver confirmation

#### 4. Driver Modal
- Form for adding new driver
- Phone number input
- Password input
- Vehicle type selection
- Form validation

#### 5. Live Tracking
- Interactive Leaflet map
- Real-time marker updates
- Speed and heading display
- Live updates feed (last 15)
- Connect/Stop controls

#### 6. Directory
- Other verified collector companies
- Active driver count per company
- Verified badge

## Security Considerations

1. **Token Storage**: JWT tokens stored in localStorage (vulnerable to XSS)
   - Consider moving to httpOnly cookies for production
   - Implement CSP headers
   - Sanitize user inputs

2. **WebSocket Security**: Tokens passed as query parameter (browser limitation)
   - Use WSS (secure WebSocket)
   - Implement token expiry checks

3. **API Calls**: All calls include JWT in Authorization header
   - Auto-logout on 401
   - Refresh token mechanism should be implemented

## Performance Optimizations

1. **Chart.js**: Destroy and recreate on data update (prevent memory leaks)
2. **Map**: Lazy-loaded on tracking activation
3. **Live Updates**: Max 20 items in feed (bounded memory)
4. **Request Batching**: Load all dashboard data on mount
5. **Throttled Renders**: WebSocket messages render once per batch

## Future Enhancements

1. **Real-time Notifications**
   - Push notifications for new requests
   - Toast alerts for status changes

2. **Advanced Analytics**
   - Date range filtering
   - Export to CSV/PDF
   - Custom report builder

3. **Performance Tuning**
   - Pagination for large lists
   - Virtual scrolling for feeds
   - Service workers for offline support

4. **Mobile Optimization**
   - Touch-friendly controls
   - Responsive map interactions
   - Mobile-specific layouts

5. **Accessibility**
   - ARIA labels
   - Keyboard navigation
   - Screen reader support

## Deployment

### Development
```bash
npm install
npm run dev
```

### Production Build
```bash
npm run build
```

### Docker Example
```dockerfile
FROM node:18-alpine as builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM php:8.2-fpm
# ... PHP configuration
COPY public/build /var/www/html/public/build
```

## Support & Documentation

- **API Docs**: See `/docs/openapi (1).json`
- **Admin Guide**: See `/docs/admin_dashboard.md`
- **Collector Guide**: See `/docs/collector_dashboard.md`
- **General Guide**: See `/docs/general.md`
