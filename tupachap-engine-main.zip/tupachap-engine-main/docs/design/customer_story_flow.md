## **1. Customer Flow: Household (Scheduled Pickup)**

1. **Request & Date Selection:** The user opens the app, selects "Scheduled Pickup," and chooses the required Waste Class (e.g., Solid - General Trash or Recyclables). They then select their preferred future date and time window for the collection.
2. **District Policy Fare:** Instead of asking for a photo of the trash, the app cross-references the user's pinned GPS location with the `ward_id` in the database. The system displays the **Fixed Fee** dictated by that specific district or street's collection policy.
3. **Confirmation & Pending QR:** The user agrees to the fixed fee and confirms the booking. The trip is logged in the database as `SCHEDULED`, and the app generates a pending, unique QR code saved in the user's "Upcoming Pickups" tab.
4. **Collection Day Alert:** On the scheduled day, the user receives a push notification when the assigned collector is en route, allowing them to prepare the waste for handover.
5. **Handover & QR Verification:** The collector arrives at the household. The user opens the TupaChap app and displays the QR code. The collector scans this code with their device to authenticate the pickup and takes a photo of the loaded trash to update the status to `IN_TRANSIT`.
6. **Mobile Payment:** Once the collector completes the dumpsite verification, the Trip & Dispatch Service pings the Billing & Payment Service. A Mobile Money (M-Pesa/Tigo Pesa/Airtel Money) USSD prompt is automatically pushed to the household user's phone for the exact fixed fee agreed upon during scheduling.

## **2. Customer Flow: Household (Immediate Pickup)**

1. **Request:** User selects "Immediate Pickup" and chooses the Waste Class (e.g., Solid - General).
2. **Photo Estimation:** The app prompts the user to open their camera and take a picture of the trash.
3. **Fare Quote:** The system analyzes the photo (either via an AI volume-estimation model or standard sizing rules) and returns an estimated fare. User taps "Confirm."
4. **QR Generation:** A unique QR code appears on the user's screen.
5. **Handover:** The collector arrives. The collector scans the QR code on the user's phone to authenticate the correct pickup.
6. **Payment:** Upon dumpsite completion, a Mobile Money USSD prompt is pushed to the user's phone.


## **3. Customer Flow: Institution / Corporate (New Customer Scheduled Pickup)**

1. **Registration & Profiling:** The facility administrator downloads the app, creates an account, and selects their specific institutional category (e.g., Hospital, Industry). They input their facility's physical address and accurately pin the GPS location on the map.
2. **Contract Setup & Waste Classification:** The user specifies the classes of waste their facility generates. A hospital, for example, might select both *Biohazard* and *Solid - General Trash*. They then choose their preferred contract billing cycle: **Annually** or **Semi-Annually**.
3. **Contract Activation (Mobile Payment):** The system calculates the contract total based on the facility size, waste classes, and district policies. A Mobile Money USSD prompt (M-Pesa, Tigo Pesa, etc.) is pushed to the administrator's phone to process the upfront contract fee. Upon successful transaction, their contract status becomes `ACTIVE` in the database.
4. **Recurring Scheduling:** With an active contract, the user unlocks the scheduling dashboard. They configure their recurring collection timetable, assigning specific days for specific waste classes (e.g., Biohazard every Monday and Thursday, General Trash on Wednesdays). The system generates a persistent or dynamically refreshing QR code for the facility.
5. **Collection Day & QR Handover:** On the scheduled day, a collector with the appropriately classified vehicle (e.g., a sealed truck for biohazards) arrives. The facility administrator presents their TupaChap QR code. The collector scans it with their driver app to authenticate the location and takes a photograph of the loaded waste to update the trip to `IN_TRANSIT`.
6. **Dumpsite Verification & Ledger Update:** The collector navigates to the authorized disposal site (e.g., an incinerator for medical waste or Pugu dumpsite for general waste) and captures the final Proof of Disposal photograph. Because the institution has already paid their annual/semi-annual fee, **no payment prompt is triggered**. The system simply logs the completed pickup against the facility's active contract ledger.
