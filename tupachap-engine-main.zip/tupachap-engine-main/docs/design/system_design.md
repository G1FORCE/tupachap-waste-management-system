### **System Architecture (Updated for TupaChap Modifications)**

To support complex billing (subscriptions vs. instant), diverse waste classes, and image-based fare estimation, the Layered Architecture (SOA) must be expanded.

```text
+-----------------------------------------------------------------------+
|                       CLIENT / PRESENTATION LAYER                     |
|  [ Customer App (Households/Institutions) ]      [ Collector App ]    |
|               (React Native)                      (React Native)      |
+-----------------------------------------------------------------------+
                                |
                                v (REST & WebSockets)
+-----------------------------------------------------------------------+
|                           API LAYER                                   |
+-----------------------------------------------------------------------+
      |                 |                 |                  |
      v                 v                 v                  v
+-----------+    +-------------+   +--------------+   +---------------+
| AUTH &    |    |  TRIP &     |   | MEDIA &      |   | BILLING &     |
| CONTRACT  |    |  DISPATCH   |   | VERIFICATION |   | PAYMENT       |
| SERVICE   |    |  SERVICE    |   | SERVICE      |   | SERVICE       |
| (Python)  |    | (PostGIS)   |   | (Python/CV)  |   | (Python)      |
+-----------+    +-------------+   +--------------+   +---------------+
      |                 |                 |                  |
      v                 v                 v                  v
+-----------------------------------------------------------------------+
|                       DATA & STORAGE LAYER                            |
| [ DB: Users ]  [ DB: Trips ]    [ NEON POSTGRES ]   [ DB: Finance ]   |
|                                  (Trash/Dump Pics)                    |
+-----------------------------------------------------------------------+

```

* **Profile & Contract Service:** Manages the 5 customer types and tracks active annual/semi-annual contracts for institutions.
* **Trip & Dispatch Service:** Routes the correct vehicle type based on waste class (e.g., dispatching a specialized biohazard truck for a hospital, instead of a standard *Guta*).
* **Media & Verification Service:** Handles the generation of the unique QR code for the customer, processes the initial trash photo for volume/fare estimation (potentially utilizing computer vision), and stores the dumpsite verification photos.
* **Billing & Payment Service:** Strictly processes Mobile Money API integrations and calculates fixed district fees versus dynamically estimated image fees.
* **Storage Layer:** Only links to images will be shared cause the mobile apps will firebase cloud storage to stora images.

---

### **Database Schema Redesign**

### **1. Core Identity & Roles**
#### **Table: `users**` (The Base Auth Table)

| Column Name | Data Type | Constraints / Description |
| --- | --- | --- |
| `id` | UUID | PRIMARY KEY, Default: `uuid_generate_v4()` |
| `phone_number` | VARCHAR(15) | UNIQUE, NOT NULL (Crucial for mobile auth) |
| `password_hash` | VARCHAR(255) | NOT NULL |
| `role` | VARCHAR(20) | ENUM ('CUSTOMER', 'COLLECTOR_ADMIN', 'WASTEPICKER', 'SYS_ADMIN') |
| `created_at` | TIMESTAMP | Default: `CURRENT_TIMESTAMP` |
| `updated_at` | TIMESTAMP | Automatically updated on modification |

---

### **2. User Profiles & Location Definitions**
#### **Table: `customers**` (Households & Institutions)

| Column Name | Data Type | Constraints / Description |
| --- | --- | --- |
| `id` | UUID | PRIMARY KEY |
| `user_id` | UUID | FOREIGN KEY references `users(id)`, UNIQUE |
| `customer_type` | VARCHAR(20) | ENUM ('HOUSEHOLD', 'HOSPITAL', 'SCHOOL', 'COMPANY', 'INDUSTRY') |
| `default_location` | **GEOMETRY(Point, 4326)** | **PostGIS Type:** The exact Long/Lat of their gate/trash area |

#### **Table: `collectors**` (The Waste Management Companies)

| Column Name | Data Type | Constraints / Description |
| --- | --- | --- |
| `id` | UUID | PRIMARY KEY |
| `user_id` | UUID | FOREIGN KEY references `users(id)`, UNIQUE (The company admin) |
| `company_name` | VARCHAR(100) | NOT NULL |
| `tin_number` | VARCHAR(20) | UNIQUE, Nullable (For tax/business verification) |
| `is_verified` | BOOLEAN | Default: `FALSE` |

#### **Table: `wastepickers**` (The Drivers / Operators)

| Column Name | Data Type | Constraints / Description |
| --- | --- | --- |
| `id` | UUID | PRIMARY KEY |
| `user_id` | UUID | FOREIGN KEY references `users(id)`, UNIQUE (Their login) |
| `collector_id` | UUID | FOREIGN KEY references `collectors(id)` (Who they work for) |
| `vehicle_type` | VARCHAR(30) | ENUM ('GUTA', 'BAJAJI', 'LIGHT_TRUCK', 'COMPACTOR') |
| `is_online` | BOOLEAN | Default: `FALSE` (Used for dispatch availability) |
| `last_known_location` | **GEOMETRY(Point, 4326)** | Updates periodically (though Redis is better for real-time tracking) |

---

### **3. Operations & Logistics**
#### **Table: `contracts**` (For Non-Households)

| Column Name | Data Type | Constraints / Description |
| --- | --- | --- |
| `id` | UUID | PRIMARY KEY |
| `customer_id` | UUID | FOREIGN KEY references `customers(id)` |
| `billing_cycle` | VARCHAR(20) | ENUM ('ANNUALLY', 'SEMI_ANNUALLY') |
| `start_date` | DATE | NOT NULL |
| `end_date` | DATE | NOT NULL |
| `contract_status` | VARCHAR(20) | ENUM ('ACTIVE', 'EXPIRED', 'PENDING_PAYMENT', 'SUSPENDED') |

#### **Table: `trips**` (The Core Dispatch Table)

| Column Name | Data Type | Constraints / Description |
| --- | --- | --- |
| `id` | UUID | PRIMARY KEY |
| `customer_id` | UUID | FOREIGN KEY references `customers(id)` |
| `wastepicker_id` | UUID | FOREIGN KEY references `wastepickers(id)`, Nullable initially |
| `pickup_method` | VARCHAR(20) | ENUM ('IMMEDIATE', 'SCHEDULED') |
| `waste_class` | VARCHAR(30) | ENUM ('SOLID_RECYCLABLE', 'SOLID_GENERAL', 'ORGANIC', 'LIQUID', 'BIOHAZARD') |
| `status` | VARCHAR(20) | ENUM ('REQUESTED', 'ACCEPTED', 'IN_TRANSIT', 'COMPLETED', 'CANCELED') |
| `pickup_location` | **GEOMETRY(Point, 4326)** | Where the trash is picked up |
| `dumpsite_location` | **GEOMETRY(Point, 4326)** | The authorized drop-off point |
| `qr_code_hash` | VARCHAR(255) | UNIQUE, NOT NULL |
| `base_fare_tzs` | DECIMAL(10,2) | NOT NULL, Default: 0.00 |
| `created_at` | TIMESTAMP | Default: `CURRENT_TIMESTAMP` |

#### **Table: `payments` (Transaction Ledger)**

| Column Name | Data Type | Constraints / Description |
| --- | --- | --- |
| `id` | UUID | PRIMARY KEY, Default: `uuid_generate_v4()` |
| `customer_id` | UUID | FOREIGN KEY references `customers(id)` |
| `trip_id` | UUID | FOREIGN KEY references `trips(id)`, **Nullable** (Used if paying for a single household pickup) |
| `contract_id` | UUID | FOREIGN KEY references `contracts(id)`, **Nullable** (Used if paying for an institutional subscription) |
| `amount_tzs` | DECIMAL(10,2) | NOT NULL. The exact amount billed and expected. |
| `provider` | VARCHAR(30) | ENUM ('M_PESA', 'TIGO_PESA', 'AIRTEL_MONEY', 'HALOPESA') |
| `phone_number` | VARCHAR(15) | NOT NULL. The specific mobile number that received the USSD push prompt. |
| `gateway_reference` | VARCHAR(100) | UNIQUE, Nullable. The transaction ID returned by the API (e.g., Snippe.sh receipt number) upon success. |
| `status` | VARCHAR(20) | ENUM ('PENDING', 'SUCCESS', 'FAILED', 'REFUNDED'). Default: `PENDING`. |
| `paid_at` | TIMESTAMP | Nullable. The exact time the payment gateway webhook confirmed the success. |
| `created_at` | TIMESTAMP | Default: `CURRENT_TIMESTAMP` |

#### **Table: `proof_of_service**`

*Added a Primary Key (required for ORMs like Prisma or Django) and separated the data clearly.*

| Column Name | Data Type | Constraints / Description |
| --- | --- | --- |
| `id` | UUID | PRIMARY KEY |
| `trip_id` | UUID | FOREIGN KEY references `trips(id)`, UNIQUE |
| `estimation_pic` | VARCHAR(255) | Nullable (S3 URL of the initial picture) |
| `qr_scanned_at` | TIMESTAMP | Nullable (When the collector scanned the phone) |
| `pickup_pic` | VARCHAR(255) | Nullable (S3 URL of the loaded trash) |
| `dumpsite_pic` | VARCHAR(255) | Nullable (S3 URL of the disposed trash) |


This is an excellent architectural foresight. To handle localized district pricing (like different fees for Kinondoni vs. Ilala) and to mathematically verify that a driver actually went to an official dump (like Pugu Kinyamwezi), you must introduce **Spatial Reference Tables** using PostGIS.

Here is how you design these tables to make the system fully autonomous and production-ready.

### **1. Municipal Pricing & Boundaries**
#### **Table: `wards` (Municipal Zones & Policies)**

| Column Name | Data Type | Constraints / Description |
| --- | --- | --- |
| `id` | UUID | PRIMARY KEY |
| `municipality` | VARCHAR(50) | e.g., 'Kinondoni', 'Ilala', 'Ubungo' |
| `ward_name` | VARCHAR(50) | e.g., 'Sinza', 'Manzese', 'Masaki' |
| `boundary` | **GEOMETRY(Polygon, 4326)** | **PostGIS Type:** A drawn map boundary of the ward. |
| `household_fee_tzs` | DECIMAL(10,2) | Fixed district fee for standard household pickups. |
| `commercial_fee_tzs` | DECIMAL(10,2) | Fixed district fee for standard commercial pickups. |
| `policy_active` | BOOLEAN | Default: `TRUE`. Allows admins to toggle pricing updates. |

**How the Code Works (The "CS" Defense):**
When a user requests a pickup, your backend runs a spatial query using `ST_Contains()`.
*Query Logic:* "Find the `household_fee_tzs` from the `wards` table where the polygon `boundary` contains the user's exact `pickup_location` point."

---

### **2. Dumpsite Verification & Geofencing**
#### **Table: `dumpsites` (Authorized Disposal Locations)**

| Column Name | Data Type | Constraints / Description |
| --- | --- | --- |
| `id` | UUID | PRIMARY KEY |
| `name` | VARCHAR(100) | e.g., 'Pugu Kinyamwezi Dumpsite', 'Tegeta Transfer Station' |
| `site_type` | VARCHAR(30) | ENUM ('LANDFILL', 'TRANSFER_STATION', 'INCINERATOR', 'RECYCLING_CENTER') |
| `accepted_waste` | VARCHAR[] | Array of accepted types (e.g., `['SOLID_GENERAL', 'ORGANIC']`). Prevents sending regular trash to a biohazard incinerator. |
| `location` | **GEOMETRY(Point, 4326)** | **PostGIS Type:** The exact GPS center of the dumpsite. |
| `geofence_radius_m` | INTEGER | Distance in meters (e.g., `200`). How close the driver must be to the center to upload the photo. |
| `is_active` | BOOLEAN | Default: `TRUE`. |







