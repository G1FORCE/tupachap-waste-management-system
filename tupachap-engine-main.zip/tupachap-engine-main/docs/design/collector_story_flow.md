## **Collector Flow (Execution & Proof)**

1. **Dispatch:** Collector receives a ping specifying the Waste Class (ensuring they have the proper equipment, especially for liquid/biohazard) and navigates to the GPS pin.
2. **Step 1 Verification (QR):** Collector arrives and uses their app to scan the Customer's QR code. This proves they are at the correct location.
3. **Step 2 Verification (Pickup):** Collector takes a photo of the waste loaded onto their vehicle. Status changes to `IN_TRANSIT`.
4. **Step 3 Verification (Dumpsite):** Collector navigates to the authorized dumpsite, unloads, and takes a final photo of the cleared waste.
5. **Completion:** The trip concludes, routing the mobile payment for households or logging the contract fulfillment for institutions.
