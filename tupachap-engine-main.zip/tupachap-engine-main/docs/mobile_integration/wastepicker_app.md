# Waste Picker App Integration Guide

## Authentication
Waste Pickers are added to the system by their **Collector Admin**. Once added, they can log in using the general login flow.

- **Login**: `POST /api/auth/login` (See [General Guide](./general.md))

## Live Location & Dispatch

To receive trip requests and provide live tracking to customers, the waste picker app must maintain a WebSocket connection.

### Live Tracking (WebSocket)
Connect to:
`ws://api.tupachap.com/api/ws/driver/{trip_id}?token={jwt_token}`

#### Sending Location Updates:
The app should push JSON updates every 5-10 seconds while on a trip:
```json
{
  "lat": -6.7924,
  "lon": 39.2083,
  "heading": 90,
  "speed": 15
}
```

### Trip Dispatch
When a new trip is requested near the driver, the backend currently assigns it to the nearest online driver.
*Note: The current implementation auto-assigns the driver. The app should poll or listen for status changes on trips assigned to the driver.*

## Fleet Management (For Collector Admins)

Collector Admins (Companies) use these endpoints to manage their drivers:

### Add Driver to Fleet
`POST /api/fleet/add-driver`
```json
{
  "phone_number": "+255...",
  "password": "secure_password",
  "vehicle_type": "GUTA"
}
```
*Valid Vehicle Types: `GUTA`, `BAJAJI`, `LIGHT_TRUCK`, `COMPACTOR`*

### View Fleet Directory
`GET /api/admin/fleet/verified-directory`
Returns all verified companies and their drivers.

## Trip Management

Once a trip is assigned, the waste picker uses the following endpoints to progress the trip:

### View Assigned Trips
Fetch trips currently assigned to the logged-in driver that are either `ACCEPTED` or `IN_TRANSIT`.

`GET /trips/my-assigned`

### View Available Trips
Fetch trips that are `REQUESTED` and have not yet been assigned to any driver.

`GET /trips/available`

### Scan Customer QR Code
When the driver arrives at the customer's location, they must scan the QR code displayed on the Customer's app. This verifies the pickup and starts the "In Transit" phase.

`POST /trips/{trip_id}/scan-qr`
```json
{
  "qr_hash": "raw_qr_content_from_camera"
}
```

### Upload Proof of Service Photos
At various stages (AI estimation, pickup, or arrival at dumpsite), the driver should upload photos.
*Note: The mobile app should upload the actual binary file to a storage service (S3/Cloudinary) first, and then send the resulting URL to this endpoint.*

`PATCH /trips/{trip_id}/pics`
```json
{
  "estimation_pics": ["https://storage.url/est1.jpg"],
  "pickup_pics": ["https://storage.url/pick1.jpg"],
  "dumpsite_pics": ["https://storage.url/dump1.jpg"]
}
```

### Complete Trip
Finalize the trip once the waste is successfully disposed of at the designated dumpsite.

`POST /trips/{trip_id}/complete`
(No request body required)

## Trip Lifecycle

Drivers should be aware of the following statuses (`TripStatusEnum`):
1. `REQUESTED`: Trip is looking for a driver.
2. `ACCEPTED`: Driver has been assigned/accepted.
3. `IN_TRANSIT`: Driver is moving towards pickup or dumpsite (Triggered by QR Scan).
4. `COMPLETED`: Trip finished (Triggered by Complete endpoint).
5. `CANCELED`: Trip canceled by customer or system.
