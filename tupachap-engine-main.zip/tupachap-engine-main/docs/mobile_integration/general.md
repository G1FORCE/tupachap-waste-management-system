# General Mobile Integration Guide

## Base URL
- **Staging/Development**: `https://api.tupachap.com` (Example)
- **Production**: `https://api-prod.tupachap.com`

## Authentication

Tupachap uses JWT (JSON Web Tokens) for authentication.

### Login Flow
1. Send a `POST` request to `/api/auth/login` with `username` (phone number) and `password` as form data.
2. The API returns an `access_token` and `token_type`.
3. Store the `access_token` securely (e.g., EncryptedSharedPreferences on Android, Keychain on iOS).

### Authenticated Requests
Include the token in the `Authorization` header for all protected endpoints:
`Authorization: Bearer <your_access_token>`

## Error Handling

The API returns standard HTTP status codes:
- `200 OK`: Request successful.
- `400 Bad Request`: Validation error or business logic failure.
- `401 Unauthorized`: Missing or invalid token.
- `403 Forbidden`: Authenticated but lacks permissions for the action.
- `404 Not Found`: Resource does not exist.
- `500 Internal Server Error`: Server-side error.

### Error Response Body
```json
{
  "detail": "Error message describing what went wrong"
}
```

## Common Enums

Refer to these values when sending requests:

### Waste Classes
- `SOLID_RECYCLABLE`
- `SOLID_GENERAL`
- `ORGANIC`
- `LIQUID`
- `BIOHAZARD`

### Customer Types
- `HOUSEHOLD`
- `HOSPITAL`
- `SCHOOL`
- `COMPANY`
- `INDUSTRY`

### Payment Providers
- `M_PESA`
- `TIGO_PESA`
- `AIRTEL_MONEY`
- `HALOPESA`
