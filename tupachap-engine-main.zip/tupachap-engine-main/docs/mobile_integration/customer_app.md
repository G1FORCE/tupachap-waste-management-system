# Customer App Integration Guide

## Onboarding

### 1. Registration
`POST /api/auth/register/customer`
```json
{
  "phone_number": "+255...",
  "password": "secure_password",
  "customer_type": "HOUSEHOLD",
  "lat": -6.7924,
  "lon": 39.2083
}
```

### 2. Profile Setup
`POST /contract/setup`
Used to set or update the default pickup location and customer type.
```json
{
  "customer_type": "HOUSEHOLD",
  "lat": -6.7924,
  "lon": 39.2083
}
```

## Immediate Pickups

### Flow
1. **AI Estimation**: (External API) The app should first call the Media/AI API with a photo of the waste to get an `image_estimated_price` and `estimation_image_url`.
2. **Request Trip**: `POST /trips/request-immediate`
```json
{
  "lat": -6.7924,
  "lon": 39.2083,
  "waste_class": ["ORGANIC", "SOLID_GENERAL"],
  "image_estimated_price": 5000.0,
  "estimation_image_url": "https://storage.tupachap.com/waste_123.jpg"
}
```
3. **Check Status**: `GET /trips/{trip_id}/status`
Poll this endpoint to see if a driver has been assigned (`status: "ACCEPTED"`).

## Subscription Contracts

### 1. Create Subscription
`POST /contract/subscribe`
```json
{
  "billing_cycle": "MONTHLY",
  "start_date": "2024-06-01",
  "end_date": "2024-12-01",
  "pickup_day": 1
}
```

### 2. View Current Contract
`GET /contract/contract`
Returns details of the active or pending subscription.

## Payments

### Initiate Payment for Trip
`POST /payments/initiate/trip`
Triggers a USSD push (STK Push) to the user's phone.
```json
{
  "trip_id": "uuid-here",
  "amount": 5000.0,
  "phone_number": "+255..."
}
```

## Live Tracking (WebSocket)

Connect to the following URL to receive live location updates from the driver:
`ws://api.tupachap.com/api/ws/customer/{trip_id}?token={jwt_token}`

### Messages Received:
- **Location Update**:
```json
{
  "type": "LOCATION_UPDATE",
  "lat": -6.7924,
  "lon": 39.2083,
  "heading": 90,
  "speed": 15
}
```
- **Status Update**:
```json
{
  "type": "STATUS_UPDATE",
  "status": "DRIVER_DISCONNECTED",
  "message": "Driver lost connection."
}
```

## Trip Management

### List Trips
`GET /customers/trips?limit=20&offset=0`

### Cancel Trip
`PATCH /customers/trips/{trip_id}/cancel`
Only possible before a driver accepts.
