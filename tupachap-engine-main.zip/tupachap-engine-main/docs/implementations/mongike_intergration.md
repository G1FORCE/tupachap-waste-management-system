> For clean Markdown of any page, append .md to the page URL.
> For a complete documentation index, see https://mongike.docs.buildwithfern.com/llms.txt.
> For full documentation content, see https://mongike.docs.buildwithfern.com/llms-full.txt.
> For AI client integration (Claude Code, Cursor, etc.), connect to the MCP server at https://mongike.docs.buildwithfern.com/_mcp/server.

# Initiate Mobile Money Payment

POST https://mongike.com/api/v1/payments/mobile-money/tanzania
Content-Type: application/json

Reference: https://mongike.docs.buildwithfern.com/mongike-payment-api/initiate-mobile-money-payment

## OpenAPI Specification

```yaml
openapi: 3.1.0
info:
  title: collection
  version: 1.0.0
paths:
  /payments/mobile-money/tanzania:
    post:
      operationId: initiate-mobile-money-payment
      summary: Initiate Mobile Money Payment
      tags:
        - ''
      parameters:
        - name: x-api-key
          in: header
          required: true
          schema:
            type: string
      responses:
        '201':
          description: Payment initiated
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/PaymentResponse'
        '400':
          description: Validation error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ErrorResponse'
      requestBody:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/PaymentRequest'
servers:
  - url: https://mongike.com/api/v1
components:
  schemas:
    PaymentRequestFeePayer:
      type: string
      enum:
        - MERCHANT
        - CUSTOMER
      title: PaymentRequestFeePayer
    PaymentRequestMetadata:
      type: object
      properties: {}
      title: PaymentRequestMetadata
    PaymentRequest:
      type: object
      properties:
        order_id:
          type: string
        amount:
          type: number
          format: double
        buyer_phone:
          type: string
          description: Phone number in international format (no +)
        buyer_name:
          type: string
        buyer_email:
          type: string
        fee_payer:
          $ref: '#/components/schemas/PaymentRequestFeePayer'
        metadata:
          $ref: '#/components/schemas/PaymentRequestMetadata'
      required:
        - order_id
        - amount
        - buyer_phone
        - fee_payer
      title: PaymentRequest
    PaymentResponseData:
      type: object
      properties:
        id:
          type: string
        order_id:
          type: string
        gateway_ref:
          type: string
        amount:
          type: number
          format: double
        status:
          type: string
        expires_at:
          type: string
          format: date-time
      title: PaymentResponseData
    PaymentResponse:
      type: object
      properties:
        status:
          type: string
        message:
          type: string
        data:
          $ref: '#/components/schemas/PaymentResponseData'
      title: PaymentResponse
    ErrorResponse:
      type: object
      properties:
        status:
          type: string
        message:
          type: string
        code:
          type: string
      title: ErrorResponse
  securitySchemes:
    ApiKeyAuth:
      type: apiKey
      in: header
      name: x-api-key

```

## SDK Code Examples

```python
import requests

url = "https://mongike.com/api/v1/payments/mobile-money/tanzania"

payload = {
    "order_id": "ORDER-123",
    "amount": 30000,
    "buyer_phone": "255712345678",
    "fee_payer": "MERCHANT"
}
headers = {
    "x-api-key": "<apiKey>",
    "Content-Type": "application/json"
}

response = requests.post(url, json=payload, headers=headers)

print(response.json())
```

```javascript
const url = 'https://mongike.com/api/v1/payments/mobile-money/tanzania';
const options = {
  method: 'POST',
  headers: {'x-api-key': '<apiKey>', 'Content-Type': 'application/json'},
  body: '{"order_id":"ORDER-123","amount":30000,"buyer_phone":"255712345678","fee_payer":"MERCHANT"}'
};

try {
  const response = await fetch(url, options);
  const data = await response.json();
  console.log(data);
} catch (error) {
  console.error(error);
}
```

```go
package main

import (
	"fmt"
	"strings"
	"net/http"
	"io"
)

func main() {

	url := "https://mongike.com/api/v1/payments/mobile-money/tanzania"

	payload := strings.NewReader("{\n  \"order_id\": \"ORDER-123\",\n  \"amount\": 30000,\n  \"buyer_phone\": \"255712345678\",\n  \"fee_payer\": \"MERCHANT\"\n}")

	req, _ := http.NewRequest("POST", url, payload)

	req.Header.Add("x-api-key", "<apiKey>")
	req.Header.Add("Content-Type", "application/json")

	res, _ := http.DefaultClient.Do(req)

	defer res.Body.Close()
	body, _ := io.ReadAll(res.Body)

	fmt.Println(res)
	fmt.Println(string(body))

}
```

```ruby
require 'uri'
require 'net/http'

url = URI("https://mongike.com/api/v1/payments/mobile-money/tanzania")

http = Net::HTTP.new(url.host, url.port)
http.use_ssl = true

request = Net::HTTP::Post.new(url)
request["x-api-key"] = '<apiKey>'
request["Content-Type"] = 'application/json'
request.body = "{\n  \"order_id\": \"ORDER-123\",\n  \"amount\": 30000,\n  \"buyer_phone\": \"255712345678\",\n  \"fee_payer\": \"MERCHANT\"\n}"

response = http.request(request)
puts response.read_body
```

```java
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;

HttpResponse<String> response = Unirest.post("https://mongike.com/api/v1/payments/mobile-money/tanzania")
  .header("x-api-key", "<apiKey>")
  .header("Content-Type", "application/json")
  .body("{\n  \"order_id\": \"ORDER-123\",\n  \"amount\": 30000,\n  \"buyer_phone\": \"255712345678\",\n  \"fee_payer\": \"MERCHANT\"\n}")
  .asString();
```

```php
<?php
require_once('vendor/autoload.php');

$client = new \GuzzleHttp\Client();

$response = $client->request('POST', 'https://mongike.com/api/v1/payments/mobile-money/tanzania', [
  'body' => '{
  "order_id": "ORDER-123",
  "amount": 30000,
  "buyer_phone": "255712345678",
  "fee_payer": "MERCHANT"
}',
  'headers' => [
    'Content-Type' => 'application/json',
    'x-api-key' => '<apiKey>',
  ],
]);

echo $response->getBody();
```

```csharp
using RestSharp;

var client = new RestClient("https://mongike.com/api/v1/payments/mobile-money/tanzania");
var request = new RestRequest(Method.POST);
request.AddHeader("x-api-key", "<apiKey>");
request.AddHeader("Content-Type", "application/json");
request.AddParameter("application/json", "{\n  \"order_id\": \"ORDER-123\",\n  \"amount\": 30000,\n  \"buyer_phone\": \"255712345678\",\n  \"fee_payer\": \"MERCHANT\"\n}", ParameterType.RequestBody);
IRestResponse response = client.Execute(request);
```

```swift
import Foundation

let headers = [
  "x-api-key": "<apiKey>",
  "Content-Type": "application/json"
]
let parameters = [
  "order_id": "ORDER-123",
  "amount": 30000,
  "buyer_phone": "255712345678",
  "fee_payer": "MERCHANT"
] as [String : Any]

let postData = JSONSerialization.data(withJSONObject: parameters, options: [])

let request = NSMutableURLRequest(url: NSURL(string: "https://mongike.com/api/v1/payments/mobile-money/tanzania")! as URL,
                                        cachePolicy: .useProtocolCachePolicy,
                                    timeoutInterval: 10.0)
request.httpMethod = "POST"
request.allHTTPHeaderFields = headers
request.httpBody = postData as Data

let session = URLSession.shared
let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
  if (error != nil) {
    print(error as Any)
  } else {
    let httpResponse = response as? HTTPURLResponse
    print(httpResponse)
  }
})

dataTask.resume()
```

> For clean Markdown of any page, append .md to the page URL.
> For a complete documentation index, see https://mongike.docs.buildwithfern.com/llms.txt.
> For full documentation content, see https://mongike.docs.buildwithfern.com/llms-full.txt.
> For AI client integration (Claude Code, Cursor, etc.), connect to the MCP server at https://mongike.docs.buildwithfern.com/_mcp/server.

# Webhooks

Receive real-time payment notifications

**Overview**

Get instant updates when payment status changes

Mongike can send automatic notifications to your server when payment status changes to COMPLETED. Webhooks enable you to automate order fulfillment, send customer notifications, and update your database in real-time.

## **Webhook Setup**

Include the webhook\_url parameter in your payment request to receive status updates:

```
{
  "order_id": "3rer407fe-3ee8-4525-456f-ccb95de38250",
  "buyer_email": "customer@gmail.com",
  "buyer_name": "John Doe",
  "buyer_phone": "0744963858",
  "amount": 1000,
  "webhook_url": "https://your-domain.com/payment-webhook"
}
```

Webhooks are only triggered when payment status changes to COMPLETED. Your webhook endpoint must be publicly accessible via HTTPS.

## **Webhook Authentication**

**Verify Webhook Requests**

Ensure webhook requests are legitimate

Mongike will send the x-api-key in the request header when calling your webhook URL. Verify this key to ensure the request is legitimate and comes from Mongike.

`x-api-key: YOUR_API_KEY`

## **Webhook Payload (Mobile Money)**

Example webhook payload for Mobile Money Tanzania payments:

```
{
  "order_id": "ORDER_1774085199651",
  "payment_status": "COMPLETED",
  "reference": "MONGIKE_REF_1774085199970",
  "amount": 5000,
  "metadata": {
    "product": "Production Test",
    "version": "1.1"
  }
}
```