from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import jwt
from sqlalchemy.orm import Session
from src.core.database import get_db
from src.core.security import SECRET_KEY, ALGORITHM
from src.models.user import User, RoleEnum

# This tells FastAPI where the client should send login credentials
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")


def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    """Decodes the JWT and fetches the user from the database."""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")
        if user_id is None:
            raise credentials_exception
    except jwt.PyJWTError:
        raise credentials_exception

    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise credentials_exception
    return user


# --- RBAC (Role-Based Access Control) Checkers ---

def get_current_active_customer(current_user: User = Depends(get_current_user)):
    if current_user.role != RoleEnum.CUSTOMER:
        raise HTTPException(status_code=403, detail="Not enough permissions. Customer role required.")
    return current_user


def get_current_wastepicker(current_user: User = Depends(get_current_user)):
    if current_user.role != RoleEnum.WASTEPICKER:
        raise HTTPException(status_code=403, detail="Not enough permissions. Wastepicker role required.")
    return current_user


def get_sys_admin(current_user: User = Depends(get_current_user)):
    if current_user.role != RoleEnum.SYS_ADMIN:
        raise HTTPException(status_code=403, detail="System Administrator access required.")
    return current_user