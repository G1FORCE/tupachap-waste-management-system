from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List, Dict

from src.models.operations import Trip, TripStatusEnum, Contract, ContractStatusEnum, Ward
from src.models.payment import Payment, PaymentStatusEnum
from src.models.user import Wastepicker, Collector


class AnalyticsService:

    # ==========================================
    # 1. WASTEPICKER ANALYTICS
    # ==========================================
    @staticmethod
    def get_wastepicker_stats(db: Session, picker_id: str) -> Dict:
        """Returns revenue, trip counts, and history for a specific wastepicker."""

        # 1. Trip Counts by Status
        completed_trips = db.query(func.count(Trip.id)).filter(
            Trip.wastepicker_id == picker_id,
            Trip.status == TripStatusEnum.COMPLETED
        ).scalar() or 0

        pending_trips = db.query(func.count(Trip.id)).filter(
            Trip.wastepicker_id == picker_id,
            Trip.status.in_([TripStatusEnum.ACCEPTED, TripStatusEnum.IN_TRANSIT])
        ).scalar() or 0

        # 2. Total Revenue Generated (Sum of successful payments for their trips)
        revenue = db.query(func.sum(Payment.amount_tzs)).join(
            Trip, Payment.trip_id == Trip.id
        ).filter(
            Trip.wastepicker_id == picker_id,
            Payment.status == PaymentStatusEnum.SUCCESS
        ).scalar() or 0.0

        # 3. Trip History (Last 10 trips)
        history = db.query(Trip).filter(
            Trip.wastepicker_id == picker_id
        ).order_by(Trip.created_at.desc()).limit(10).all()

        return {
            "wastepicker_id": picker_id,
            "revenue_tzs": float(revenue),
            "trips_completed": completed_trips,
            "trips_pending": pending_trips,
            "recent_history": [
                {"trip_id": str(t.id), "status": t.status.name, "date": t.created_at, "fare": float(t.base_fare_tzs)}
                for t in history
            ]
        }

    # ==========================================
    # 2. COLLECTOR / FLEET ANALYTICS
    # ==========================================
    @staticmethod
    def get_collector_dashboard(db: Session, collector_id: str) -> Dict:
        """Aggregates data for all drivers under a specific collector company."""

        # 1. Total Revenue from all their wastepickers
        revenue = db.query(func.sum(Payment.amount_tzs)).join(
            Trip, Payment.trip_id == Trip.id
        ).join(
            Wastepicker, Trip.wastepicker_id == Wastepicker.id
        ).filter(
            Wastepicker.collector_id == collector_id,
            Payment.status == PaymentStatusEnum.SUCCESS
        ).scalar() or 0.0

        # 2. Total Trips handled by their fleet
        total_trips = db.query(func.count(Trip.id)).join(
            Wastepicker, Trip.wastepicker_id == Wastepicker.id
        ).filter(
            Wastepicker.collector_id == collector_id
        ).scalar() or 0

        # 3. Active Contracts (Count of active contracts for customers serviced by this fleet)
        active_contracts = db.query(func.count(func.distinct(Contract.id))).join(
            Trip, Trip.customer_id == Contract.customer_id
        ).join(
            Wastepicker, Wastepicker.id == Trip.wastepicker_id
        ).filter(
            Wastepicker.collector_id == collector_id,
            Contract.contract_status == ContractStatusEnum.ACTIVE
        ).scalar() or 0

        return {
            "collector_id": collector_id,
            "total_fleet_revenue_tzs": float(revenue),
            "total_fleet_trips": total_trips,
            "active_serviced_contracts": active_contracts
        }

    # ==========================================
    # 3. SYSTEM & SPATIAL ANALYTICS (SYS ADMIN)
    # ==========================================
    @staticmethod
    def get_ward_trip_history(db: Session) -> List[Dict]:
        """PostGIS Spatial Join: Counts how many trips occurred inside each Ward boundary."""
        ward_stats = db.query(
            Ward.ward_name,
            func.count(Trip.id).label('trip_count')
        ).join(
            Trip, func.ST_Contains(Ward.boundary, Trip.pickup_location)
        ).group_by(Ward.ward_name).all()

        return [{"ward": stat.ward_name, "total_trips": stat.trip_count} for stat in ward_stats]

    @staticmethod
    def get_waste_heatmap_data(db: Session) -> List[Dict]:
        """Extracts exact coordinates using PostGIS functions for frontend Heatmap rendering."""
        # Note: ST_Y is Latitude, ST_X is Longitude in PostGIS
        heatmap_points = db.query(
            func.ST_Y(Trip.pickup_location).label('lat'),
            func.ST_X(Trip.pickup_location).label('lon'),
            Trip.waste_class
        ).filter(Trip.status == TripStatusEnum.COMPLETED).all()

        return [
            {"lat": float(pt.lat), "lon": float(pt.lon), "weight": 1, "type": [wc.name for wc in pt.waste_class]}
            for pt in heatmap_points
        ]