from sqlalchemy.orm import Session
from fastapi import HTTPException, APIRouter
from src.models.user import Collector


class AdminService:

    @staticmethod
    def get_pending_collectors(db: Session):
        """Fetches all collector profiles that are not yet verified."""
        return db.query(Collector).filter(Collector.is_verified == False).all()

    @staticmethod
    def verify_collector(db: Session, collector_id: str, approve: bool):
        """
        Updates the verification status of a Collector.
        If approve=True, they are verified.
        If approve=False, you might want to delete them or mark them as rejected.
        """
        collector = db.query(Collector).filter(Collector.id == collector_id).first()

        if not collector:
            raise ValueError(f"Collector with ID {collector_id} not found.")

        if approve:
            collector.is_verified = True
            db.commit()
            db.refresh(collector)
            return collector
        else:
            # Depending on business logic, you might delete the rejected profile
            # or just leave it unverified. Here, we'll just delete the profile for simplicity.
            db.delete(collector)
            db.commit()
            return None