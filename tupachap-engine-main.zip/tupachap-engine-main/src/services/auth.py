from sqlalchemy.orm import Session
from fastapi import HTTPException, status
from src.core.security import get_password_hash, verify_password, create_access_token
from src.models.user import User, RoleEnum, Customer, Collector, Wastepicker, CustomerTypeEnum, VehicleTypeEnum


class AuthService:

    @staticmethod
    def authenticate_user(db: Session, phone_number: str, password: str):
        """Verifies phone and password, returns the User object if successful."""
        user = db.query(User).filter(User.phone_number == phone_number).first()
        if not user:
            return None
        if not verify_password(password, user.password_hash):
            return None
        return user

    @staticmethod
    def login_and_create_token(db: Session, phone_number: str, password: str):
        """Authenticates and returns a JWT token."""
        user = AuthService.authenticate_user(db, phone_number, password)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect phone number or password",
                headers={"WWW-Authenticate": "Bearer"},
            )

        access_token = create_access_token(user=user, role=user.role.name)
        return {"access_token": access_token, "token_type": "bearer", "role": user.role.name}

    @staticmethod
    def register_customer(db: Session,  first_name: str, last_name: str, phone: str, password: str, customer_type: CustomerTypeEnum, lat: float,
                          lon: float):
        """Registers a new Customer and their spatial profile."""
        if db.query(User).filter(User.phone_number == phone).first():
            raise ValueError("Phone number already registered.")

        # 1. Create Base User
        user = User(
            first_name=first_name,
            last_name=last_name,
            phone_number=phone,
            password_hash=get_password_hash(password),
            role=RoleEnum.CUSTOMER
        )
        db.add(user)
        db.flush()  # Flush to get user.id

        # 2. Create Customer Profile
        point_geom = f"SRID=4326;POINT({lon} {lat})"
        customer = Customer(
            user_id=user.id,
            customer_type=customer_type,
            default_location=point_geom
        )
        db.add(customer)
        db.commit()
        return user

    @staticmethod
    def register_wastepicker(db: Session, first_name: str, last_name: str, phone: str, password: str, collector_id: str, vehicle_type: VehicleTypeEnum):
        """
        Registers a Wastepicker.
        Note: Usually, a Collector Admin calls this to add drivers to their fleet.
        """
        if db.query(User).filter(User.phone_number == phone).first():
            raise ValueError("Phone number already registered.")

        user = User(
            first_name=first_name,
            last_name=last_name,
            phone_number=phone,
            password_hash=get_password_hash(password),
            role=RoleEnum.WASTEPICKER
        )
        db.add(user)
        db.flush()

        wastepicker = Wastepicker(
            user_id=user.id,
            collector_id=collector_id,
            vehicle_type=vehicle_type
        )
        db.add(wastepicker)
        db.commit()
        return user