from sqlalchemy import func
from sqlalchemy.orm import Session
from geoalchemy2.shape import from_shape
from shapely.geometry import Point
from src.models.operations import Trip, TripStatusEnum
from src.models.user import User, Customer


class CustomerService:

    @staticmethod
    def get_my_trips(db: Session, customer_id: str, limit: int = 20, offset: int = 0):
        """Fetches the trip history for a specific customer, ordered by newest first."""
        return db.query(Trip).filter(
            Trip.customer_id == customer_id
        ).order_by(
            Trip.created_at.desc()
        ).offset(offset).limit(limit).all()

    @staticmethod
    def cancel_trip(db: Session, customer_id: str, trip_id: str):
        """
        Cancels a trip, but ONLY if it is still in the 'REQUESTED' state.
        Once a driver accepts it (ACCEPTED or IN_TRANSIT), cancellation is blocked.
        """
        # 1. Find the trip and ensure it belongs to this specific customer
        trip = db.query(Trip).filter(
            Trip.id == trip_id,
            Trip.customer_id == customer_id
        ).first()

        if not trip:
            raise ValueError("Trip not found or you do not have permission to view it.")

        # 2. Enforce the cancellation business rule
        if trip.status != TripStatusEnum.REQUESTED:
            raise ValueError(
                f"Cannot cancel trip. Current status is '{trip.status.name}'. "
                "You can only cancel a trip before a driver has accepted it."
            )

        # 3. Apply the cancellation
        trip.status = TripStatusEnum.CANCELED

        # (Optional: If the user already paid via mobile money, you would trigger
        # a refund via the PaymentService here)

        db.commit()
        db.refresh(trip)
        return trip

    @staticmethod
    def update_customer_profile(db: Session, user: User, **kwargs):
        """Updates both User and Customer profile details."""
        customer = db.query(Customer).filter(Customer.user_id == user.id).first()
        if not customer:
            raise ValueError("Customer profile not found.")

        # Update User fields
        if 'first_name' in kwargs and kwargs['first_name'] is not None and user.first_name != kwargs['first_name'] and kwargs['first_name'] != "":
            user.first_name = kwargs['first_name']
        if 'last_name' in kwargs and kwargs['last_name'] is not None and user.last_name != kwargs['last_name'] and kwargs['last_name'] != "":
            user.last_name = kwargs['last_name']
        if 'phone_number' in kwargs and kwargs['phone_number'] is not None and user.phone_number != kwargs['phone_number'] and kwargs['phone_number'] != "":
            # Check if the phone number is already taken by another user
            existing_user = db.query(User).filter(User.phone_number == kwargs['phone_number'], User.id != user.id).first()
            if existing_user:
                raise ValueError("Phone number already in use by another account.")
            user.phone_number = kwargs['phone_number']

        # Update Customer fields
        if 'customer_type' in kwargs and kwargs['customer_type'] is not None and customer.customer_type != kwargs['customer_type'] and kwargs['customer_type'] != "":
            customer.customer_type = kwargs['customer_type']
        
        if 'lat' in kwargs and 'lon' in kwargs and kwargs['lat'] is not None and kwargs['lon'] is not None and kwargs['lat'] != 0 and kwargs['lon'] != 0:
            customer.default_location = from_shape(Point(kwargs['lon'], kwargs['lat']), srid=4326)

        db.commit()
        db.refresh(user)
        db.refresh(customer)
        return user, customer