from sqlalchemy.orm import Session
from src.core.security import get_password_hash
from src.models.user import User, RoleEnum, Collector, Wastepicker, VehicleTypeEnum


class CollectorService:

    @staticmethod
    def register_collector(db: Session, phone: str, password: str, company_name: str, tin_number: str = None):
        """Registers a new Waste Management Company (Collector Admin)."""
        # 1. Check if phone is already registered
        if db.query(User).filter(User.phone_number == phone).first():
            raise ValueError("Phone number already registered.")

        # 2. Check if TIN number is already used (if provided)
        if tin_number and db.query(Collector).filter(Collector.tin_number == tin_number).first():
            raise ValueError("Company with this TIN number already exists.")

        try:
            # 3. Create the Base User account
            user = User(
                phone_number=phone,
                password_hash=get_password_hash(password),
                role=RoleEnum.COLLECTOR_ADMIN
            )
            db.add(user)
            db.flush()  # Flush to generate the user.id

            # 4. Create the Collector Profile
            collector = Collector(
                user_id=user.id,
                company_name=company_name,
                tin_number=tin_number,
                is_verified=False  # Requires physical verification by SysAdmin later
            )
            db.add(collector)
            db.commit()
            db.refresh(user)
            db.refresh(collector)

            return user, collector

        except Exception as e:
            db.rollback()
            raise Exception(f"Failed to register collector: {str(e)}")

    @staticmethod
    def register_wastepicker(db: Session, collector_id: str, phone: str, password: str, vehicle_type: VehicleTypeEnum):
        """
        Registers a new driver (Wastepicker) and assigns them to a specific Collector's fleet.
        """
        # 1. Verify the collector exists
        collector = db.query(Collector).filter(Collector.id == collector_id).first()
        if not collector:
            raise ValueError("Invalid Collector ID. Cannot assign wastepicker to a non-existent fleet.")

        # 2. Check if phone is already registered
        if db.query(User).filter(User.phone_number == phone).first():
            raise ValueError("Phone number already registered.")

        try:
            # 3. Create the Base User account
            user = User(
                phone_number=phone,
                password_hash=get_password_hash(password),
                role=RoleEnum.WASTEPICKER
            )
            db.add(user)
            db.flush()

            # 4. Create the Wastepicker Profile linked to the Collector
            wastepicker = Wastepicker(
                user_id=user.id,
                collector_id=collector.id,
                vehicle_type=vehicle_type,
                is_online=False
                # last_known_location will be null until they open the app and send GPS data
            )
            db.add(wastepicker)
            db.commit()
            db.refresh(user)
            db.refresh(wastepicker)

            return user, wastepicker

        except Exception as e:
            db.rollback()
            raise Exception(f"Failed to register wastepicker: {str(e)}")

    # Add this inside the CollectorService class in src/services/collector_service.py

    @staticmethod
    def get_verified_collectors_with_drivers(db: Session, collector_id: str = None):
        """Fetches verified companies and their respective drivers.

        If collector_id is provided, returns only that collector's fleet.
        """
        # 1. Get all verified collectors, or just the requested one
        collector_query = db.query(Collector).filter(Collector.is_verified == True)
        if collector_id is not None:
            collector_query = collector_query.filter(Collector.id == collector_id)

        verified_collectors = collector_query.all()

        result = []
        for collector in verified_collectors:
            # 2. For each collector, find their wastepickers AND join the User table
            # to get the driver's phone number
            drivers = db.query(Wastepicker, User).join(
                User, Wastepicker.user_id == User.id
            ).filter(
                Wastepicker.collector_id == collector.id
            ).all()

            # 3. Format the driver list
            driver_list = []
            for wp, user in drivers:
                driver_list.append({
                    "wastepicker_id": str(wp.id),
                    "driver_name": f"{user.first_name} {user.last_name}".strip(),
                    "phone_number": user.phone_number,
                    "vehicle_type": wp.vehicle_type.name,
                    "is_online": wp.is_online
                })

            # 4. Append to the final result
            result.append({
                "collector_id": str(collector.id),
                "company_name": collector.company_name,
                "tin_number": collector.tin_number,
                "driver_count": len(driver_list),
                "drivers": driver_list
            })

        return result

    @staticmethod
    def get_collector_drivers(db: Session, collector_id: str):
        """Fetches all drivers assigned to a specific collector fleet."""
        drivers = db.query(Wastepicker, User).join(
            User, Wastepicker.user_id == User.id
        ).filter(
            Wastepicker.collector_id == collector_id
        ).all()

        driver_list = []
        for wastepicker, user in drivers:
            driver_list.append({
                "wastepicker_id": str(wastepicker.id),
                "user_id": str(user.id),
                "driver_name": f"{user.first_name} {user.last_name}".strip(),
                "first_name": user.first_name,
                "last_name": user.last_name,
                "phone_number": user.phone_number,
                "vehicle_type": wastepicker.vehicle_type.name,
                "is_online": wastepicker.is_online
            })

        return driver_list

    @staticmethod
    def update_collector_profile(db: Session, user: User, **kwargs):
        """Updates both User and Collector profile details."""
        collector = db.query(Collector).filter(Collector.user_id == user.id).first()
        if not collector:
            raise ValueError("Collector profile not found.")

        # Update User fields
        if 'first_name' in kwargs and kwargs['first_name'] is not None:
            user.first_name = kwargs['first_name']
        if 'last_name' in kwargs and kwargs['last_name'] is not None:
            user.last_name = kwargs['last_name']
        if 'phone_number' in kwargs and kwargs['phone_number'] is not None:
            existing_user = db.query(User).filter(User.phone_number == kwargs['phone_number'], User.id != user.id).first()
            if existing_user:
                raise ValueError("Phone number already in use.")
            user.phone_number = kwargs['phone_number']

        # Update Collector fields
        if 'company_name' in kwargs and kwargs['company_name'] is not None:
            collector.company_name = kwargs['company_name']
        if 'tin_number' in kwargs and kwargs['tin_number'] is not None:
            existing_collector = db.query(Collector).filter(Collector.tin_number == kwargs['tin_number'], Collector.id != collector.id).first()
            if existing_collector:
                raise ValueError("TIN number already in use.")
            collector.tin_number = kwargs['tin_number']
        if 'ward_id' in kwargs and kwargs['ward_id'] is not None:
            # Add simple verification if ward exists if needed, but for now just update
            collector.ward_id = kwargs['ward_id']

        db.commit()
        db.refresh(user)
        db.refresh(collector)
        return user, collector

    @staticmethod
    def update_wastepicker_profile(db: Session, user: User, **kwargs):
        """Updates both User and Wastepicker profile details."""
        wastepicker = db.query(Wastepicker).filter(Wastepicker.user_id == user.id).first()
        if not wastepicker:
            raise ValueError("Wastepicker profile not found.")

        # Update User fields
        if 'first_name' in kwargs and kwargs['first_name'] is not None:
            user.first_name = kwargs['first_name']
        if 'last_name' in kwargs and kwargs['last_name'] is not None:
            user.last_name = kwargs['last_name']
        if 'phone_number' in kwargs and kwargs['phone_number'] is not None:
            existing_user = db.query(User).filter(User.phone_number == kwargs['phone_number'], User.id != user.id).first()
            if existing_user:
                raise ValueError("Phone number already in use.")
            user.phone_number = kwargs['phone_number']

        # Update Wastepicker fields
        if 'vehicle_type' in kwargs and kwargs['vehicle_type'] is not None:
            wastepicker.vehicle_type = kwargs['vehicle_type']
        if 'is_online' in kwargs and kwargs['is_online'] is not None:
            wastepicker.is_online = kwargs['is_online']

        db.commit()
        db.refresh(user)
        db.refresh(wastepicker)
        return user, wastepicker