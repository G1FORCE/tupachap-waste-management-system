import uuid
from datetime import date, datetime
from sqlalchemy.orm import Session
from sqlalchemy import func

from typing import List, Optional

from src.models import Collector
from src.models.operations import Trip, TripStatusEnum, PickupMethodEnum, WasteClassEnum, Contract, ContractStatusEnum, ProofOfService
from src.models.user import Customer, Wastepicker, CustomerTypeEnum
from src.models.operations import Ward, Dumpsite


class TripService:

    # ==========================================
    # HELPER METHODS (SPATIAL & PRICING LOGIC)
    # ==========================================

    @staticmethod
    def _get_ward_and_fare(db: Session, customer_type: CustomerTypeEnum, pickup_geom: str):
        """Uses PostGIS ST_Contains to find the Ward and calculate the municipal fare."""
        ward: Ward | None = db.query(Ward).filter(
            func.ST_Contains(Ward.boundary, func.ST_GeomFromEWKT(pickup_geom))
        ).first()

        if not ward:
            raise ValueError("Pickup location is outside of supported municipal zones.")

        # Fare is based on customer type and the specific ward's policies
        fare = ward.household_fee_tzs if customer_type == CustomerTypeEnum.HOUSEHOLD else ward.commercial_fee_tzs
        return ward, fare

    @staticmethod
    def _get_nearest_dumpsite(db: Session, pickup_geom: str, waste_classes: List[WasteClassEnum]):
        """Finds the nearest dumpsite that accepts ALL requested classes of waste."""

        # Convert Enum list to names for Postgres ARRAY comparison
        waste_class_names = [wc.name for wc in waste_classes]

        dumpsite = db.query(Dumpsite).filter(
            Dumpsite.is_active == True,
            Dumpsite.accepted_waste.contains(waste_class_names)  # Must contain all requested
        ).order_by(
            func.ST_Distance(Dumpsite.location, func.ST_GeomFromEWKT(pickup_geom))
        ).first()

        if not dumpsite:
            raise ValueError(f"No active dumpsite found that accepts all requested waste classes: {waste_class_names}")

        return dumpsite

    # ==========================================
    # 1. IMMEDIATE PICKUP FLOW (ON-DEMAND)
    # =======================================

    @staticmethod
    def request_immediate_pickup(
            db: Session,
            customer_id: str,
            waste_class: List[WasteClassEnum],
            lat: float,
            lon: float,
            image_estimated_price: float = 0.0,  # NEW: Price from the Media API
            estimation_image_url: List[str] = None  # NEW: URL to the image they took
    ):
        """Creates an instant trip using the image estimate for pricing."""
        customer = db.query(Customer).filter(Customer.user_id == customer_id).first()
        pickup_geom = f"SRID=4326;POINT({lon} {lat})"

        ward, ward_base_fare = TripService._get_ward_and_fare(db, customer.customer_type, pickup_geom)

        final_fare = max(float(ward_base_fare), image_estimated_price)

        dumpsite = TripService._get_nearest_dumpsite(db, pickup_geom, waste_class)

        trip = Trip(
            customer_id=customer.id,
            pickup_method=PickupMethodEnum.IMMEDIATE,
            waste_class=waste_class,
            status=TripStatusEnum.PENDING_PAYMENT,
            pickup_location=pickup_geom,
            dumpsite_location=dumpsite.location,
            qr_code_hash=uuid.uuid4().hex,
            base_fare_tzs=final_fare  # Use the computed final fare
        )
        db.add(trip)
        db.flush()  # Flush to get the trip.id before committing

        if estimation_image_url:
            proof = ProofOfService(
                trip_id=trip.id,
                estimation_pic=[estimation_image_url] if isinstance(estimation_image_url, str) else estimation_image_url
            )
            db.add(proof)

        db.commit()
        db.refresh(trip)

        return {
            "trip": trip,
            "ward_name": ward.ward_name,
            "final_fare_tzs": final_fare,
        }

    @staticmethod
    def dispatch_nearest_wastepicker(db: Session, trip_id: str):
        """Finds the nearest ONLINE wastepicker using PostGIS ST_Distance."""
        trip = db.query(Trip).filter(Trip.id == trip_id).first()

        nearest_picker = db.query(Wastepicker).filter(
            Wastepicker.is_online == True,

        ).order_by(
            func.ST_Distance(Wastepicker.last_known_location, trip.pickup_location)
        ).first()

        if nearest_picker:
            trip.wastepicker_id = nearest_picker.id
            trip.status = TripStatusEnum.ACCEPTED
            db.commit()
            db.refresh(trip)
            return nearest_picker

        return None  # No one online nearby. Stays in 'REQUESTED' state for polling.

    # ==========================================
    # 2. SCHEDULED SUBSCRIPTION FLOW (BATCH)
    # ==========================================

    @staticmethod
    def generate_weekly_monthly_scheduled_trips(db: Session):
        """
        Runs via a Cron Job (e.g., morning at 2 AM).
        Finds all active contracts and generates prepaid Trips for them.
        """
        # In a real app, you'd check if today is their designated pickup day.
        # For simplicity, we grab all ACTIVE contracts.
        active_contracts = db.query(Contract).filter(
            Contract.contract_status == ContractStatusEnum.ACTIVE,
            Contract.end_date >= date.today()
        ).all()

        generated_trips = []

        for contract in active_contracts:
            customer = db.query(Customer).filter(Customer.id == contract.customer_id).first()

            dumpsite = TripService._get_nearest_dumpsite(db, str(customer.default_location),
                                                         [WasteClassEnum.SOLID_GENERAL])

            trip = Trip(
                customer_id=customer.id,
                pickup_method=PickupMethodEnum.SCHEDULED,
                waste_class=[WasteClassEnum.SOLID_GENERAL],  # Usually general waste for subscriptions
                status=TripStatusEnum.REQUESTED,
                pickup_location=customer.default_location,
                dumpsite_location=dumpsite.location,
                qr_code_hash=uuid.uuid4().hex,
                base_fare_tzs=0.00  # Prepaid via contract subscription
            )
            db.add(trip)
            generated_trips.append(trip)

        db.commit()
        return len(generated_trips)

    @staticmethod
    def batch_assign_scheduled_trips(db: Session):
        """
        Runs at 6 AM. Assigns scheduled trips to wastepickers based on territory (Ward)
        rather than just nearest distance, optimizing for route density.
        """
        unassigned_scheduled_trips = db.query(Trip).filter(
            Trip.pickup_method == PickupMethodEnum.SCHEDULED,
            Trip.status == TripStatusEnum.REQUESTED
        ).all()

        assigned_count = 0

        for trip in unassigned_scheduled_trips:

            ward = db.query(Ward).filter(
                func.ST_Contains(Ward.boundary, trip.pickup_location)
            ).first()

            if not ward:
                continue

            local_collector = db.query(Collector).filter(
                Collector.ward_id == ward.id,
            ).limit(1).first()

            local_picker = db.query(Wastepicker).filter(
                Wastepicker.is_online == True,
                Wastepicker.collector_id == local_collector.id,
                func.ST_Contains(Ward.boundary, Wastepicker.last_known_location)
            ).first()

            if local_picker:
                trip.wastepicker_id = local_picker.id
                trip.status = TripStatusEnum.ACCEPTED
                assigned_count += 1

        db.commit()
        return assigned_count

    # ==========================================
    # 3. WASTEPICKER WORKFLOW ACTIONS
    # ==========================================

    @staticmethod
    def scan_trip_qr(db: Session, wastepicker_id: str, trip_id: str, qr_hash: str):
        """Verifies the QR code and transitions the trip to IN_TRANSIT."""
        trip = db.query(Trip).filter(Trip.id == trip_id).first()
        if not trip:
            raise ValueError("Trip not found.")

        if trip.wastepicker_id and str(trip.wastepicker_id) != wastepicker_id:
            raise ValueError("This trip is assigned to another driver.")

        if trip.qr_code_hash != qr_hash:
            raise ValueError("Invalid QR code hash.")

        if trip.status not in [TripStatusEnum.ACCEPTED, TripStatusEnum.REQUESTED]:
             # It might be in REQUESTED if they just scanned it without being pre-assigned (Uber-like take)
             pass

        # Update assignment if it was just 'REQUESTED'
        if not trip.wastepicker_id:
            trip.wastepicker_id = wastepicker_id

        trip.status = TripStatusEnum.IN_TRANSIT

        # Record scanning time in ProofOfService
        proof = db.query(ProofOfService).filter(ProofOfService.trip_id == trip.id).first()
        if not proof:
            proof = ProofOfService(trip_id=trip.id)
            db.add(proof)

        proof.qr_scanned_at = datetime.now()

        db.commit()
        db.refresh(trip)
        return trip

    @staticmethod
    def update_trip_pics(
            db: Session,
            wastepicker_id: str,
            trip_id: str,
            estimation_pics: Optional[List[str]] = None,
            pickup_pics: Optional[List[str]] = None,
            dumpsite_pics: Optional[List[str]] = None
    ):
        """Updates URLs for photos taken during various stages of the trip."""
        trip = db.query(Trip).filter(Trip.id == trip_id, Trip.wastepicker_id == wastepicker_id).first()
        if not trip:
            raise ValueError("Trip not found or not assigned to you.")

        proof = db.query(ProofOfService).filter(ProofOfService.trip_id == trip.id).first()
        if not proof:
            proof = ProofOfService(trip_id=trip.id)
            db.add(proof)

        if estimation_pics:
            proof.estimation_pic = (proof.estimation_pic or []) + estimation_pics
        if pickup_pics:
            proof.pickup_pic = (proof.pickup_pic or []) + pickup_pics
        if dumpsite_pics:
            proof.dumpsite_pic = (proof.dumpsite_pic or []) + dumpsite_pics

        db.commit()
        db.refresh(proof)
        return proof

    @staticmethod
    def complete_trip(db: Session, wastepicker_id: str, trip_id: str):
        """Finalizes the trip after verifying the driver is at the dumpsite."""
        trip = db.query(Trip).filter(Trip.id == trip_id, Trip.wastepicker_id == wastepicker_id).first()
        if not trip:
            raise ValueError("Trip not found or not assigned to you.")

        if trip.status != TripStatusEnum.IN_TRANSIT:
            raise ValueError(f"Cannot complete trip in status: {trip.status.name}")

        # In a real-world scenario, we would use ST_Distance here to ensure
        # the Wastepicker's current GPS is within X meters of trip.dumpsite_location.

        trip.status = TripStatusEnum.COMPLETED
        db.commit()
        db.refresh(trip)
        return trip

    @staticmethod
    def get_wastepicker_trips(db: Session, wastepicker_id: str, status_filter: Optional[str] = None):
        """
        Fetches trips for a specific wastepicker.
        - If status_filter is 'assigned', returns ACCEPTED and IN_TRANSIT trips.
        - If status_filter is 'available', returns REQUESTED trips that are not yet assigned.
        - Otherwise returns all trips assigned to this picker.
        """
        query = db.query(Trip)

        if status_filter == "assigned":
            return query.filter(
                Trip.wastepicker_id == wastepicker_id,
                Trip.status.in_([TripStatusEnum.ACCEPTED, TripStatusEnum.IN_TRANSIT])
            ).all()

        elif status_filter == "available":
            # For 'available', we look for REQUESTED trips.
            # Usually we filter by ward/location, but for now we return all REQUESTED and unassigned.
            return query.filter(
                Trip.status == TripStatusEnum.REQUESTED,
                Trip.wastepicker_id == None
            ).all()

        return query.filter(Trip.wastepicker_id == wastepicker_id).all()
