from sqlalchemy.orm import Session
from datetime import date
from src.models.user import User, Customer, RoleEnum, CustomerTypeEnum
from src.models.operations import Contract, ContractStatusEnum, BillingCycleEnum


class ProfileService:
    @staticmethod
    def create_customer_profile(db: Session, user_id: str, customer_type: CustomerTypeEnum, lat: float, lon: float):
        """Creates a customer profile with their default PostGIS location."""
        point_geom = f"SRID=4326;POINT({lon} {lat})"

        customer = Customer(
            user_id=user_id,
            customer_type=customer_type,
            default_location=point_geom
        )
        db.add(customer)
        db.commit()
        db.refresh(customer)
        return customer

    @staticmethod
    def create_subscription_contract(db: Session, customer_id: str, pickup_day: float, cycle: BillingCycleEnum, start: date, end: date):
        """Creates a recurring waste collection contract."""
        contract = Contract(
            customer_id=customer_id,
            billing_cycle=cycle,
            start_date=start,
            pickup_day=pickup_day,
            end_date=end,
            contract_status=ContractStatusEnum.PENDING_PAYMENT
        )
        db.add(contract)
        db.commit()
        db.refresh(contract)
        return contract

    # ==========================================
    # NEW METHOD: View Current Contract
    # ==========================================
    @staticmethod
    def get_current_contract(db: Session, customer_id: str):
        """
        Fetches the most relevant recent contract for a customer.
        Orders by end_date descending so the newest contract is always fetched first.
        """
        contract = db.query(Contract).filter(
            Contract.customer_id == customer_id
        ).order_by(
            Contract.end_date.desc()
        ).first()

        return contract