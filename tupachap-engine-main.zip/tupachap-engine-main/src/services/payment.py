from sqlalchemy import null
from sqlalchemy.orm import Session
from sqlalchemy.sql import func
from fastapi import HTTPException
import uuid

from src.models.constants import get_contract_price
# Import your DB Models
from src.models.payment import Payment, PaymentStatusEnum, ProviderEnum
from src.models.operations import Trip, TripStatusEnum, Contract, ContractStatusEnum

# Import the Mongike Client you provided
from src.core.mongike_client import MongikeClient, FeePayerEnum, WebhookPayload
from src.core.config import settings
from src.services.trip import TripService

# Initialize the external client using your environment variable
mongike_client = MongikeClient(api_key=settings.MONGIKE_API_KEY)

class PaymentService:

    @staticmethod
    def initiate_trip_payment(db: Session, customer_id: str, trip_id: str, amount: float, phone: str):
        """Creates a DB record and triggers the Mongike Mobile Money API."""
        
        # 1. Create the Pending Payment Record in the Database
        payment = Payment(
            id=uuid.uuid4(),
            customer_id=customer_id,
            trip_id=trip_id,
            amount_tzs=amount,
            provider=ProviderEnum.M_PESA, # Or determine dynamically
            phone_number=phone,
            status=PaymentStatusEnum.PENDING
        )
        db.add(payment)
        db.commit()
        db.refresh(payment)

        # 2. Call your Mongike API Client
        try:
            mongike_response = mongike_client.process_payment(
                order_id=str(payment.id), # Tie Mongike's order_id to our DB Payment ID
                amount=amount,
                buyer_phone=phone,
                fee_payer=FeePayerEnum.CUSTOMER,
                # In production, set this to your server's public URL
                webhook_url=f"{settings.SERVER_URL}/payments/webhook/mongike" 
            )
            
            # 3. Update DB with Gateway Reference if successful
            payment.gateway_reference = mongike_response.get("data", {}).get("id")
            db.commit()
            db.refresh(payment)
            
            return payment, mongike_response
            
        except Exception as e:
            # If API fails, mark as failed in DB
            payment.status = PaymentStatusEnum.FAILED
            db.commit()
            raise ValueError(f"Payment initiation failed: {str(e)}")

    @staticmethod
    def initiate_contract_payment(db: Session, customer_id: str, contract_id: str, amount: float, phone: str):
        """Creates a DB record and triggers the Mongike Mobile Money API for contract."""


        payment = Payment(
            id=uuid.uuid4(),
            customer_id=customer_id,
            contract_id=contract_id,
            amount_tzs=amount,
            provider=ProviderEnum.M_PESA,  # Or determine dynamically
            phone_number=phone,
            status=PaymentStatusEnum.PENDING
        )
        db.add(payment)

        contract_record: Contract | None = db.query(Contract).filter(Contract.id == contract_id).first()
        if not contract_record:
            raise ValueError(f"Contract record {contract_id} not found in database.")
        if contract_record.contract_status == "COMPLETED":
            payment.status = PaymentStatusEnum.SUCCESS
        else:
            amount = get_contract_price(contract_record)
            payment.amount_tzs = amount
        db.commit()
        db.refresh(payment)

        # 2. Call your Mongike API Client
        try:
            mongike_response = mongike_client.process_payment(
                order_id=str(payment.id),  # Tie Mongike's order_id to our DB Payment ID
                amount=amount,
                buyer_phone=phone,
                fee_payer=FeePayerEnum.CUSTOMER,
                # In production, set this to your server's public URL
                webhook_url=f"{settings.SERVER_URL}/payments/webhook/mongike"
            )

            # 3. Update DB with Gateway Reference if successful
            payment.gateway_reference = mongike_response.get("data", {}).get("id")
            db.commit()
            db.refresh(payment)

            return payment, mongike_response

        except Exception as e:
            # If API fails, mark as failed in DB
            payment.status = PaymentStatusEnum.FAILED
            db.commit()
            raise ValueError(f"Payment initiation failed: {str(e)}")

    @staticmethod
    def process_mongike_webhook(db: Session, payload: WebhookPayload, api_key: str):
        """Validates the webhook and updates the Database based on Mongike's callback."""
        
        # 1. Let your Mongike client validate the signature and parse the payload
        webhook_result = mongike_client.handle_payment_webhook(payload, api_key)
        
        # 2. Find the payment in our DB using the order_id
        payment = db.query(Payment).filter(Payment.id == payload.order_id).first()
        if not payment:
            raise ValueError(f"Payment record {payload.order_id} not found in database.")

        # 3. Update status based on webhook result
        if payload.payment_status == "COMPLETED":
            payment.status = PaymentStatusEnum.SUCCESS
            payment.paid_at = func.now()
            payment.gateway_reference = payload.reference


            if payment.trip_id:
                trip = db.query(Trip).filter(Trip.id == payment.trip_id).first()
                if trip and trip.status == TripStatusEnum.PENDING_PAYMENT:
                    trip.status = TripStatusEnum.REQUESTED # Now ready for dispatch!
                    # 6. Attempt Auto-Dispatch
                    TripService.dispatch_nearest_wastepicker(db, str(trip.id))

            elif payment.contract_id:
                contract = db.query(Contract).filter(Contract.id == payment.contract_id).first()
                if contract:
                    contract.contract_status = ContractStatusEnum.ACTIVE

        elif payload.payment_status in ["FAILED", "EXPIRED"]:
            payment.status = PaymentStatusEnum.FAILED
            trip = db.query(Trip).filter(Trip.id == payment.trip_id).first()
            db.delete(trip)

        db.commit()
        return webhook_result