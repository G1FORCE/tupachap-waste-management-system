import uuid
from sqlalchemy.orm import Session
from src.core.database import SessionLocal, engine
from src.core.security import get_password_hash
from src.models.user import User, Customer, Collector, Wastepicker
from src.models.operations import Ward, Dumpsite
from src.models.enums import RoleEnum, CustomerTypeEnum, VehicleTypeEnum, SiteTypeEnum
import random

def seed_wards(db: Session):
    print("Seeding Wards...")
    wards_data = [
        {
            "municipality": "Kinondoni",
            "ward_name": "Kijitonyama",
            "boundary": "SRID=4326;POLYGON((39.23 -6.77, 39.25 -6.77, 39.25 -6.79, 39.23 -6.79, 39.23 -6.77))",
            "household_fee_tzs": 5000,
            "commercial_fee_tzs": 15000
        },
        {
            "municipality": "Kinondoni",
            "ward_name": "Makumbusho",
            "boundary": "SRID=4326;POLYGON((39.21 -6.77, 39.23 -6.77, 39.23 -6.79, 39.21 -6.79, 39.21 -6.77))",
            "household_fee_tzs": 4000,
            "commercial_fee_tzs": 12000
        },
        {
            "municipality": "Ilala",
            "ward_name": "Upanga Mashariki",
            "boundary": "SRID=4326;POLYGON((39.27 -6.80, 39.29 -6.80, 39.29 -6.82, 39.27 -6.82, 39.27 -6.80))",
            "household_fee_tzs": 7000,
            "commercial_fee_tzs": 20000
        }
    ]
    
    ward_objs = []
    for data in wards_data:
        existing = db.query(Ward).filter(Ward.ward_name == data["ward_name"]).first()
        if not existing:
            ward = Ward(**data)
            db.add(ward)
            ward_objs.append(ward)
        else:
            ward_objs.append(existing)
    db.commit()
    for w in ward_objs:
        db.refresh(w)
    return ward_objs

def seed_users(db: Session, wards):
    print("Seeding Users, Customers, Collectors, and Wastepickers...")
    password = "password123"
    hashed_pwd = get_password_hash(password)

    # 1. Sys Admin
    if not db.query(User).filter(User.phone_number == "255700000000").first():
        admin = User(
            phone_number="255700000000",
            password_hash=hashed_pwd,
            role=RoleEnum.SYS_ADMIN,
            first_name="System",
            last_name="Admin"
        )
        db.add(admin)

    # 2. Customers
    customers_data = [
        {"first_name": "John", "last_name": "Doe", "phone": "255711111111", "type": CustomerTypeEnum.HOUSEHOLD},
        {"first_name": "Jane", "last_name": "Smith", "phone": "255722222222", "type": CustomerTypeEnum.COMPANY},
        {"first_name": "Alice", "last_name": "Johnson", "phone": "255733333333", "type": CustomerTypeEnum.HOUSEHOLD},
    ]

    for c_data in customers_data:
        if not db.query(User).filter(User.phone_number == c_data["phone"]).first():
            user = User(
                first_name=c_data["first_name"],
                last_name=c_data["last_name"],
                phone_number=c_data["phone"],
                password_hash=hashed_pwd,
                role=RoleEnum.CUSTOMER
            )
            db.add(user)
            db.flush()
            
            customer = Customer(
                user_id=user.id,
                customer_type=c_data["type"],
                default_location="SRID=4326;POINT(39.24 -6.78)"
            )
            db.add(customer)

    # 3. Collectors (WMSC)
    collectors_data = [
        {"company_name": "Green City Waste", "phone": "255744444444", "tin": "123-456-789"},
        {"company_name": "Pure Environment Ltd", "phone": "255755555555", "tin": "987-654-321"},
    ]
    
    collector_objs = []
    for col_data in collectors_data:
        user = db.query(User).filter(User.phone_number == col_data["phone"]).first()
        if not user:
            user = User(
                first_name="Manager",
                last_name=col_data["company_name"].split()[0],
                phone_number=col_data["phone"],
                password_hash=hashed_pwd,
                role=RoleEnum.COLLECTOR_ADMIN
            )
            db.add(user)
            db.flush()
            
            collector = Collector(
                user_id=user.id,
                company_name=col_data["company_name"],
                tin_number=col_data["tin"],
                is_verified=True,
                ward_id=random.choice(wards).id
            )
            db.add(collector)
            collector_objs.append(collector)
        else:
            c = db.query(Collector).filter(Collector.user_id == user.id).first()
            if c:
                collector_objs.append(c)

    db.flush()

    # 4. Wastepickers (Drivers)
    pickers_data = [
        {"first_name": "Hamisi", "last_name": "Bakari", "phone": "255766666666", "v_type": VehicleTypeEnum.GUTA},
        {"first_name": "Juma", "last_name": "Kassim", "phone": "255777777777", "v_type": VehicleTypeEnum.BAJAJI},
        {"first_name": "Said", "last_name": "Ally", "phone": "255788888888", "v_type": VehicleTypeEnum.LIGHT_TRUCK},
    ]

    for p_data in pickers_data:
        if not db.query(User).filter(User.phone_number == p_data["phone"]).first():
            user = User(
                first_name=p_data["first_name"],
                last_name=p_data["last_name"],
                phone_number=p_data["phone"],
                password_hash=hashed_pwd,
                role=RoleEnum.WASTEPICKER
            )
            db.add(user)
            db.flush()
            
            picker = Wastepicker(
                user_id=user.id,
                collector_id=random.choice(collector_objs).id,
                vehicle_type=p_data["v_type"],
                is_online=True,
                last_known_location="SRID=4326;POINT(39.24 -6.78)"
            )
            db.add(picker)

    db.commit()

def seed_dumpsites(db: Session):
    print("Seeding Dumpsites...")
    dumpsites_data = [
        {
            "name": "Pugu Kinyamwezi Landfill",
            "site_type": SiteTypeEnum.LANDFILL,
            "accepted_waste": ["SOLID_GENERAL", "ORGANIC", "SOLID_RECYCLABLE"],
            "location": "SRID=4326;POINT(39.15 -6.88)",
            "geofence_radius_m": 500,
            "is_active": True
        },
        {
            "name": "Kinondoni Recycling Point",
            "site_type": SiteTypeEnum.RECYCLING_CENTER,
            "accepted_waste": ["SOLID_RECYCLABLE"],
            "location": "SRID=4326;POINT(39.26 -6.78)",
            "geofence_radius_m": 200,
            "is_active": True
        }
    ]
    for d_data in dumpsites_data:
        if not db.query(Dumpsite).filter(Dumpsite.name == d_data["name"]).first():
            dumpsite = Dumpsite(**d_data)
            db.add(dumpsite)
    db.commit()

def run_seeder():
    db = SessionLocal()
    try:
        wards = seed_wards(db)
        seed_users(db, wards)
        seed_dumpsites(db)
        print("Seeding completed successfully!")
    except Exception as e:
        print(f"Error during seeding: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    run_seeder()
