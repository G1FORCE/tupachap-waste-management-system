from logging.config import fileConfig

from sqlalchemy import engine_from_config
from sqlalchemy import pool
from geoalchemy2 import alembic_helpers
from src.core.database import Base
from alembic import context
from src.core.config import settings
from sqlalchemy.sql import func



# this is the Alembic Config object, which provides
# access to the values within the .ini file in use.
config = context.config
config.set_main_option("sqlalchemy.url", str(settings.DATABASE_URL))
# Interpret the config file for Python logging.
# This line sets up loggers basically.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# add your model's MetaData object here
# for 'autogenerate' support

import src.models
target_metadata = Base.metadata




# other values from the config, defined by the needs of env.py,
# can be acquired:
# my_important_option = config.get_main_option("my_important_option")
# ... etc.


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode.

    This configures the context with just a URL
    and not an Engine, though an Engine is acceptable
    here as well.  By skipping the Engine creation
    we don't even need a DBAPI to be available.

    Calls to context.execute() here emit the given string to the
    script output.

    """
    def render_item(type_, obj, autogen_context):
        """Apply custom rendering for func.now() and GeoAlchemy2"""
        # Fix for func.now()
        if type_ == 'server_default' and hasattr(obj, 'arg') and obj.arg == func.now():
            return "func.now()"

        # Fallback to GeoAlchemy2's render_item
        from geoalchemy2.alembic_helpers import render_item as geo_render_item
        return geo_render_item(type_, obj, autogen_context)

    url = config.get_main_option("sqlalchemy.url")

    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        include_object=alembic_helpers.include_object,
        process_revision_directives=alembic_helpers.writer,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode.

    In this scenario we need to create an Engine
    and associate a connection with the context.

    """

    # Add this custom render function somewhere above run_migrations_online()
    def render_item(type_, obj, autogen_context):
        """Apply custom rendering for func.now() and GeoAlchemy2"""
        # Fix for func.now()
        if type_ == 'server_default' and hasattr(obj, 'arg') and obj.arg == func.now():
            return "func.now()"

        # Fallback to GeoAlchemy2's render_item
        from geoalchemy2.alembic_helpers import render_item as geo_render_item
        return geo_render_item(type_, obj, autogen_context)


    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:

        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            include_object=alembic_helpers.include_object,
            process_revision_directives=alembic_helpers.writer,
        )

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
