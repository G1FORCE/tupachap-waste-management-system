"""change_trip_waste_class_to_array

Revision ID: 169fcb625daf
Revises: 1338edd762df
Create Date: 2026-06-07 21:24:25.817350

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '169fcb625daf'
down_revision: Union[str, Sequence[str], None] = '1338edd762df'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    # Alter the waste_class column to be an array of WasteClassEnum
    # We use PostgreSQL's USING clause to cast the existing single value to an array
    op.execute("ALTER TABLE trips ALTER COLUMN waste_class TYPE wasteclassenum[] USING ARRAY[waste_class]")

def downgrade() -> None:
    """Downgrade schema."""
    # Revert back to single Enum (taking the first element from the array)
    op.execute("ALTER TABLE trips ALTER COLUMN waste_class TYPE wasteclassenum USING waste_class[1]")
