from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from src.core.config import settings

from src.core.redis_config import init_redis, close_redis
from src.routes import auth, collectors, admin, payments, contract, trip, tracking, analytics, customer


# from src.websockets import router as websocket_router

# Lifecycle events
async def startup_event():
    """Initialize Redis on startup"""
    print("Starting up Tupachap API...")
    try:
        await init_redis()
    except Exception as e:
        print(f"Warning: Redis initialization failed: {e}")
        print("Continuing without Redis (some real-time features may be unavailable)")


async def shutdown_event():
    """Close Redis connection on shutdown"""
    print("Shutting down Tupachap API...")
    try:
        await close_redis()
    except Exception as e:
        print(f"Error during shutdown: {e}")

@asynccontextmanager
async def lifespan(app: FastAPI):
    await startup_event()
    yield
    await shutdown_event()

app = FastAPI(
    title=settings.APP_NAME,
    description="API for Tupachap Waste Management System",
    version="2.0.0",
    debug=settings.DEBUG,
    lifespan=lifespan
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth.router)
app.include_router(collectors.router)
app.include_router(customer.router)
app.include_router(admin.router)
app.include_router(payments.router)
app.include_router(contract.router)
app.include_router(trip.router)
app.include_router(tracking.router)
app.include_router(analytics.router)





@app.get("api/", tags=["health"])
async def root():
    """Health check endpoint"""
    return {
        "message": "Tupachap Waste Management API - Enhanced for Contracts & Scheduling",
        "status": "operational",
        "version": "2.0.0",
        "features": [
            "Immediate pickups with photo-based fare estimation",
            "Scheduled pickups with fixed ward pricing",
            "Institutional contracts (Hospitals, Schools, Companies, Industries)",
            "QR code verification system",
            "Multi-step proof of service (estimation, pickup, dumpsite photos)",
            "Mobile Money payment integration"
        ]
    }


@app.get("/api-docs", tags=["documentation"])
async def api_docs():
    """API documentation endpoints"""
    return {
        "swagger": "/docs",
        "redoc": "/redoc",
        "openapi": "/openapi.json"
    }
