from src.models import Contract
from src.models.enums import CustomerTypeEnum


def get_contract_price(contract: Contract):
    match contract.contract_type:
        case CustomerTypeEnum.SCHOOL:
            return 200000
        case CustomerTypeEnum.COMPANY:
            return 100
        case CustomerTypeEnum.HOSPITAL:
            return 1000
        case CustomerTypeEnum.INDUSTRY:
            return 1000
        case _:
            return None

