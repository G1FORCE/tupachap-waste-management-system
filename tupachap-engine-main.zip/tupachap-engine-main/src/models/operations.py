import uuid
from sqlalchemy import Column, String, Boolean, DateTime, Date, Numeric, ForeignKey, Enum, Integer
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from sqlalchemy.sql import func
from src.core.database import Base
from geoalchemy2 import Geometry
from src.models.enums import BillingCycleEnum, CustomerTypeEnum
from src.models.enums import ContractStatusEnum
from src.models.enums import PickupMethodEnum
from src.models.enums import WasteClassEnum
from src.models.enums import TripStatusEnum
from src.models.enums import SiteTypeEnum





class Contract(Base):
    __tablename__ = 'contracts'

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    customer_id = Column(UUID(as_uuid=True), ForeignKey('customers.id'), nullable=False)
    billing_cycle = Column(Enum(BillingCycleEnum), nullable=False)
    contract_type = Column(Enum(CustomerTypeEnum), nullable=True)
    pickup_day = Column(Numeric(2, 0), nullable=False)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=False)
    contract_status = Column(Enum(ContractStatusEnum), nullable=False)


class Trip(Base):
    __tablename__ = 'trips'

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    customer_id = Column(UUID(as_uuid=True), ForeignKey('customers.id'), nullable=False)
    wastepicker_id = Column(UUID(as_uuid=True), ForeignKey('wastepickers.id'), nullable=True)
    pickup_method = Column(Enum(PickupMethodEnum), nullable=False)
    waste_class = Column(ARRAY(Enum(WasteClassEnum)), nullable=False)
    status = Column(Enum(TripStatusEnum), nullable=False)

    pickup_location = Column(Geometry(geometry_type='POINT', srid=4326), nullable=False)
    dumpsite_location = Column(Geometry(geometry_type='POINT', srid=4326), nullable=False)

    qr_code_hash = Column(String(255), unique=True, nullable=False)
    base_fare_tzs = Column(Numeric(10, 2), default=0.00, nullable=False)
    created_at = Column(DateTime, server_default=func.now())


class ProofOfService(Base):
    __tablename__ = 'proof_of_service'

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    trip_id = Column(UUID(as_uuid=True), ForeignKey('trips.id'), unique=True, nullable=False)

    estimation_pic = Column(ARRAY(String(255)), nullable=True)
    qr_scanned_at = Column(DateTime, nullable=True)
    pickup_pic = Column(ARRAY(String(255)), nullable=True)
    dumpsite_pic = Column(ARRAY(String(255)), nullable=True)

class Ward(Base):
    __tablename__ = 'wards'

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    municipality = Column(String(50), nullable=False)
    ward_name = Column(String(50), nullable=False)

    # Polygon to define the geofenced boundary of the ward
    boundary = Column(Geometry(geometry_type='POLYGON', srid=4326), nullable=False)

    household_fee_tzs = Column(Numeric(10, 2), nullable=False)
    commercial_fee_tzs = Column(Numeric(10, 2), nullable=False)
    policy_active = Column(Boolean, default=True)


class Dumpsite(Base):
    __tablename__ = 'dumpsites'

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(100), nullable=False)
    site_type = Column(Enum(SiteTypeEnum), nullable=False)

    # ARRAY of strings to store accepted waste classes
    accepted_waste = Column(ARRAY(String), nullable=False)

    location = Column(Geometry(geometry_type='POINT', srid=4326), nullable=False)
    geofence_radius_m = Column(Integer, nullable=False)
    is_active = Column(Boolean, default=True)

class WastePriceEstimation(Base):
    __tablename__ = 'waste_estimations'

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    trip_id = Column(UUID(as_uuid=True), ForeignKey('trips.id'), nullable=False)
    image_url = Column(String(255), nullable=False)
    price = Column(Numeric(10, 2), nullable=False)