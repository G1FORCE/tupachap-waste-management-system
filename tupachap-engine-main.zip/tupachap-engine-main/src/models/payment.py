import uuid
from sqlalchemy import Column, String, Numeric, DateTime, ForeignKey, Enum
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from src.core.database import Base
from .enums import ProviderEnum
from .enums import PaymentStatusEnum
class Payment(Base):
    __tablename__ = 'payments'

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    customer_id = Column(UUID(as_uuid=True), ForeignKey('customers.id'), nullable=False)
    trip_id = Column(UUID(as_uuid=True), ForeignKey('trips.id'), nullable=True)
    contract_id = Column(UUID(as_uuid=True), ForeignKey('contracts.id'), nullable=True)

    amount_tzs = Column(Numeric(10, 2), nullable=False)
    provider = Column(Enum(ProviderEnum), nullable=False)
    phone_number = Column(String(15), nullable=False)
    gateway_reference = Column(String(100), unique=True, nullable=True)

    status = Column(Enum(PaymentStatusEnum), default=PaymentStatusEnum.PENDING, nullable=False)

    paid_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, server_default=func.now(), nullable=False)

    def __repr__(self):
        return f"<Payment(id={self.id}, amount_tzs={self.amount_tzs}, status={self.status.name})>"