import uuid
from sqlalchemy import Column, String, Boolean, DateTime, ForeignKey, Enum
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from src.core.database import Base
from geoalchemy2 import Geometry

from .enums import RoleEnum
from .enums import CustomerTypeEnum
from .enums import VehicleTypeEnum

class User(Base):
    __tablename__ = 'users'

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    phone_number = Column(String(15), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(Enum(RoleEnum), nullable=False)
    first_name = Column(String(100), nullable=False)
    last_name = Column(String(100), nullable=False)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())


class Customer(Base):
    __tablename__ = 'customers'

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), unique=True, nullable=False)
    customer_type = Column(Enum(CustomerTypeEnum), nullable=False)
    default_location = Column(Geometry(geometry_type='POINT', srid=4326), nullable=False)


class Collector(Base):
    __tablename__ = 'collectors'

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), unique=True, nullable=False)
    company_name = Column(String(100), nullable=False)
    tin_number = Column(String(20), unique=True, nullable=True)
    is_verified = Column(Boolean, default=False)
    ward_id = Column(UUID(as_uuid=True), ForeignKey('wards.id'), nullable=False)

class Wastepicker(Base):
    __tablename__ = 'wastepickers'

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), unique=True, nullable=False)
    collector_id = Column(UUID(as_uuid=True), ForeignKey('collectors.id'), nullable=False)
    vehicle_type = Column(Enum(VehicleTypeEnum), nullable=False)
    is_online = Column(Boolean, default=False)
    last_known_location = Column(Geometry(geometry_type='POINT', srid=4326), nullable=True)