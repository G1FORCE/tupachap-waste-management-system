# Import ALL your model classes here.
from .user import User, Customer, Collector, Wastepicker
from .operations import Contract, Trip, ProofOfService
from .payment import Payment
from .operations import Ward, Dumpsite