from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    # Database
    DATABASE_URL: str = "postgresql+psycopg://user:password@localhost/tupachap_db"

    # JWT
    SECRET_KEY: str = "your-super-secret-key-change-this-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    SERVER_URL: str= "http://localhost:8000"
    # App
    APP_NAME: str = "Tupachap API"
    DEBUG: bool = False

    # OTP
    OTP_EXPIRY_MINUTES: int = 5


    # Pricing
    BASE_FARE_TZS: float = 5000.0  # Base fare in Tanzanian Shillings
    PER_KM_RATE_TZS: float = 1500.0  # Rate per kilometer

    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"

    # WebSocket
    WS_JOB_OFFER_TIMEOUT_SECONDS: int = 60  # 60-second bidding window
    WS_LOCATION_UPDATE_INTERVAL_SECONDS: int = 5  # Update every 5-10 seconds

    # Mongike Payment Integration
    MONGIKE_API_KEY: str = ""  # Set via environment variable
    MONGIKE_WEBHOOK_URL: Optional[str] = None  # Webhook URL for payment callbacks
    PLATFORM_COMMISSION_PERCENTAGE: float = 15.0  # Platform commission from fares

    class Config:
        env_file = ".env"


settings = Settings()
