import base64
import hashlib
import bcrypt
from datetime import datetime, timedelta
from typing import Optional
from zoneinfo import ZoneInfo

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from passlib.context import CryptContext
from jose import jwt, JWTError
from sqlalchemy.orm import Session

# --- Passlib & Bcrypt Compatibility Fix for Python 3.14 ---
# Recent bcrypt versions (5.0.0+) and Python 3.14+ cause passlib's bcrypt handler to fail.
# 1. Monkey-patch bcrypt.__about__ for passlib's version check.
if not hasattr(bcrypt, "__about__"):
    class BcryptAbout:
        __version__ = getattr(bcrypt, "__version__", "4.0.0")
    bcrypt.__about__ = BcryptAbout()

# 2. Monkey-patch bcrypt.hashpw to handle the 72-byte limit that passlib expects it to handle.
original_hashpw = bcrypt.hashpw

def patched_hashpw(password: bytes, salt: bytes) -> bytes:
    if len(password) > 72:
        password = password[:72]
    return original_hashpw(password, salt)

bcrypt.hashpw = patched_hashpw
# ---------------------------------------------------------

from src.core.config import settings
from src.core.database import get_db

eat_tz = ZoneInfo("Africa/Nairobi")
# Bcrypt context for hashing passwords
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer()
# JWT Settings (Move these to your config/env file in production)
SECRET_KEY = getattr(settings, "SECRET_KEY", "your-super-secret-key-change-this")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24 * 7 # 7 days for mobile apps

def verify_password(plain_password: str, hashed_password: str) -> bool:
    h = hashlib.sha256(plain_password.encode('utf-8')).digest()
    b64_password = base64.b64encode(h).decode('utf-8')
    try:
        if pwd_context.verify(b64_password, hashed_password):
            return True
    except Exception:
        pass

    # Fallback for old passwords that were truncated to 72 bytes
    safe_password = plain_password.encode('utf-8')[:72].decode('utf-8', 'ignore')
    try:
        return pwd_context.verify(safe_password, hashed_password)
    except Exception:
        return False
def get_password_hash(password: str) -> str:
    h = hashlib.sha256(password.encode('utf-8')).digest()
    b64_password = base64.b64encode(h).decode('utf-8')
    return pwd_context.hash(b64_password)

def create_access_token(user, role: str, expires_delta: Optional[timedelta] = None) -> str:
    """Generates a JWT containing the user's ID and Role."""
    to_encode = {
        "sub": str(user.id),
        "role": role
    }
    if expires_delta:
        expire = datetime.now(tz=eat_tz) + expires_delta
    else:
        expire = datetime.now(tz=eat_tz) + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)

    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
    return encoded_jwt

def create_refresh_token(data: dict) -> str:
    """Create JWT refresh token"""
    to_encode = data.copy()
    expire = datetime.now(tz=eat_tz) + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
    return encoded_jwt


def verify_token(token: str) -> Optional[dict]:
    """Verify and decode JWT token"""
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        return payload
    except JWTError:
        return None


def decode_token(token: str) -> Optional[dict]:
    """Decode token without verification (for OTP)"""
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        return payload
    except JWTError:
        return None


async def get_current_user(
        credentials: HTTPAuthorizationCredentials = Depends(security),
        db: Session = Depends(get_db),
):
    """
    FastAPI dependency to get current authenticated user
    Extracts and validates JWT token from Authorization header
    """
    token = credentials.credentials
    payload = verify_token(token)

    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"}
        )

    user_id = payload.get("sub")
    if user_id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token",
            headers={"WWW-Authenticate": "Bearer"}
        )

    # Import here to avoid circular imports
    from src.models.user import User
    import uuid

    # Convert string UUID to UUID object for proper query
    try:
        user_uuid = uuid.UUID(user_id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid user ID in token"
        )

    user = (
        db.query(User)
        .filter(User.id == user_uuid)
        .first()
    )
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found"
        )

    return user
