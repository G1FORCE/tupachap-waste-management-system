from typing import Dict, List
from fastapi import WebSocket

class ConnectionManager:
    def __init__(self):
        # Maps a trip_id to a list of active WebSocket connections
        self.active_connections: Dict[str, List[WebSocket]] = {}

    async def connect(self, websocket: WebSocket, trip_id: str):
        """Accepts the connection and adds it to the trip's room."""
        await websocket.accept()
        if trip_id not in self.active_connections:
            self.active_connections[trip_id] = []
        self.active_connections[trip_id].append(websocket)

    def disconnect(self, websocket: WebSocket, trip_id: str):
        """Removes the connection when a user disconnects."""
        if trip_id in self.active_connections:
            self.active_connections[trip_id].remove(websocket)
            # Cleanup empty rooms
            if not self.active_connections[trip_id]:
                del self.active_connections[trip_id]

    async def broadcast_to_trip(self, trip_id: str, message: dict):
        """Sends a JSON message to all clients connected to a specific trip."""
        if trip_id in self.active_connections:
            # Create a copy of the list to avoid issues if it's modified during iteration
            for connection in list(self.active_connections[trip_id]):
                try:
                    await connection.send_json(message)
                except Exception:
                    # If sending fails, the connection might be dead
                    self.disconnect(connection, trip_id)

# Instantiate a single global manager
manager = ConnectionManager()