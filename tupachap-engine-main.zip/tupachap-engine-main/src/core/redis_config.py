"""
Redis client and pub/sub manager for real-time features
"""
import json
import redis
from redis import asyncio as aioredis
from typing import Optional, Dict, Any, List
from src.core.config import settings

# Global Redis client
redis_client: Optional[redis.Redis] = None
async_redis_client: Optional[aioredis.Redis] = None


def get_redis_client() -> redis.Redis:
    """Get synchronous Redis client"""
    global redis_client
    if redis_client is None:
        redis_url = getattr(settings, 'REDIS_URL', 'redis://localhost:6379/0')
        redis_client = redis.Redis(redis_url)
    return redis_client


async def get_async_redis_client() -> aioredis.Redis:
    """Get asynchronous Redis client"""
    global async_redis_client
    if async_redis_client is None:
        redis_url = getattr(settings, 'REDIS_URL', 'redis://localhost:6379/0')
        async_redis_client = await aioredis.from_url(redis_url, decode_responses=True)
    return async_redis_client


class RedisCache:
    """Redis caching service"""

    @staticmethod
    async def set_trip_cache(trip_id: str, trip_data: Dict[str, Any], ttl: int = 3600) -> bool:
        """Cache active trip (TTL: 1 hour by default)"""
        try:
            redis_conn = await get_async_redis_client()
            key = f"trip:{trip_id}"
            await redis_conn.setex(key, ttl, json.dumps(trip_data))
            return True
        except Exception as e:
            print(f"Redis cache error: {e}")
            return False

    @staticmethod
    async def get_trip_cache(trip_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve cached trip data"""
        try:
            redis_conn = await get_async_redis_client()
            key = f"trip:{trip_id}"
            data = await redis_conn.get(key)
            return json.loads(data) if data else None
        except Exception as e:
            print(f"Redis get error: {e}")
            return None

    @staticmethod
    async def set_collector_location(collector_id: str, location: Dict[str, float], ttl: int = 300) -> bool:
        """Cache online collector location (TTL: 5 min by default)"""
        try:
            redis_conn = await get_async_redis_client()
            key = f"collector_location:{collector_id}"
            await redis_conn.setex(key, ttl, json.dumps(location))
            return True
        except Exception as e:
            print(f"Redis location cache error: {e}")
            return False

    @staticmethod
    async def get_collector_location(collector_id: str) -> Optional[Dict[str, float]]:
        """Get cached collector location"""
        try:
            redis_conn = await get_async_redis_client()
            key = f"collector_location:{collector_id}"
            data = await redis_conn.get(key)
            return json.loads(data) if data else None
        except Exception as e:
            print(f"Redis location get error: {e}")
            return None

    @staticmethod
    async def get_online_collectors_by_location(location_hash: str) -> List[str]:
        """Get online collectors in a specific location area"""
        try:
            redis_conn = await get_async_redis_client()
            pattern = f"collector_location:*"
            keys = await redis_conn.keys(pattern)

            collectors = []
            for key in keys:
                data = await redis_conn.get(key)
                if data:
                    collector_id = key.replace("collector_location:", "")
                    collectors.append(collector_id)
            return collectors
        except Exception as e:
            print(f"Redis collectors lookup error: {e}")
            return []

    @staticmethod
    async def set_job_offer(job_id: str, job_data: Dict[str, Any], ttl: int = 60) -> bool:
        """Cache job offer (TTL: 60 sec by default)"""
        try:
            redis_conn = await get_async_redis_client()
            key = f"job_offer:{job_id}"
            await redis_conn.setex(key, ttl, json.dumps(job_data))
            return True
        except Exception as e:
            print(f"Redis job offer cache error: {e}")
            return False

    @staticmethod
    async def get_job_offer(job_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve cached job offer"""
        try:
            redis_conn = await get_async_redis_client()
            key = f"job_offer:{job_id}"
            data = await redis_conn.get(key)
            return json.loads(data) if data else None
        except Exception as e:
            print(f"Redis job offer get error: {e}")
            return None

    @staticmethod
    async def delete_cache(key: str) -> bool:
        """Delete cache entry"""
        try:
            redis_conn = await get_async_redis_client()
            await redis_conn.delete(key)
            return True
        except Exception as e:
            print(f"Redis delete error: {e}")
            return False


class RedisPubSub:
    """Redis Pub/Sub manager for real-time events"""

    CHANNELS = {
        'trip_status_changed': 'trip.status_changed',
        'job_offered': 'job.offered',
        'location_updated': 'location.updated',
        'collector_accepted_job': 'collector.accepted_job'
    }

    @staticmethod
    async def publish_trip_status_changed(trip_id: str, status: str, data: Dict[str, Any]) -> bool:
        """Publish trip status change event"""
        try:
            redis_conn = await get_async_redis_client()
            channel = RedisPubSub.CHANNELS['trip_status_changed']
            message = {
                'trip_id': trip_id,
                'status': status,
                'data': data
            }
            await redis_conn.publish(channel, json.dumps(message))
            return True
        except Exception as e:
            print(f"Redis publish error: {e}")
            return False

    @staticmethod
    async def publish_job_offered(job_id: str, collector_id: str, trip_id: str, data: Dict[str, Any]) -> bool:
        """Publish job offer event"""
        try:
            redis_conn = await get_async_redis_client()
            channel = RedisPubSub.CHANNELS['job_offered']
            message = {
                'job_id': job_id,
                'collector_id': collector_id,
                'trip_id': trip_id,
                'data': data
            }
            await redis_conn.publish(channel, json.dumps(message))
            return True
        except Exception as e:
            print(f"Redis publish error: {e}")
            return False

    @staticmethod
    async def publish_location_updated(collector_id: str, location: Dict[str, float]) -> bool:
        """Publish location update event"""
        try:
            redis_conn = await get_async_redis_client()
            channel = RedisPubSub.CHANNELS['location_updated']
            message = {
                'collector_id': collector_id,
                'location': location
            }
            await redis_conn.publish(channel, json.dumps(message))
            return True
        except Exception as e:
            print(f"Redis publish error: {e}")
            return False

    @staticmethod
    async def publish_collector_accepted_job(collector_id: str, job_id: str, trip_id: str) -> bool:
        """Publish job acceptance event"""
        try:
            redis_conn = await get_async_redis_client()
            channel = RedisPubSub.CHANNELS['collector_accepted_job']
            message = {
                'collector_id': collector_id,
                'job_id': job_id,
                'trip_id': trip_id
            }
            await redis_conn.publish(channel, json.dumps(message))
            return True
        except Exception as e:
            print(f"Redis publish error: {e}")
            return False


async def init_redis():
    """Initialize Redis connection on startup"""
    try:
        redis_conn = await get_async_redis_client()
        await redis_conn.ping()
        print("✓ Redis connected successfully")
    except Exception as e:
        print(f"✗ Redis connection failed: {e}")
        raise


async def close_redis():
    """Close Redis connection on shutdown"""
    global async_redis_client
    if async_redis_client:
        await async_redis_client.close()
        async_redis_client = None
    print("✓ Redis disconnected")
