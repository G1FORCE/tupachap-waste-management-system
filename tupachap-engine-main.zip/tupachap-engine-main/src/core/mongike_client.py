"""
Payment Service Module

Handles all payment-related operations including:
- Mobile money payments (Tanzania)
- Payment status tracking
- Webhook handling for payment confirmations
"""

import requests
from typing import Optional, Dict, Any
from datetime import datetime
from enum import Enum
from pydantic import BaseModel, Field
import logging

logger = logging.getLogger(__name__)


class FeePayerEnum(str, Enum):
    """Fee payer options for payment requests"""
    MERCHANT = "MERCHANT"
    CUSTOMER = "CUSTOMER"


class PaymentStatus(str, Enum):
    """Payment status options"""
    PENDING = "PENDING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    EXPIRED = "EXPIRED"


class PaymentRequestMetadata(BaseModel):
    """Metadata for payment request"""

    class Config:
        extra = "allow"


class PaymentRequest(BaseModel):
    """Mobile money payment request model"""
    order_id: str
    amount: float
    buyer_phone: str = Field(..., description="Phone number in international format (no +)")
    buyer_name: Optional[str] = None
    buyer_email: Optional[str] = None
    fee_payer: FeePayerEnum
    metadata: Optional[PaymentRequestMetadata] = None
    webhook_url: Optional[str] = None


class PaymentResponseData(BaseModel):
    """Payment response data model"""
    id: str
    order_id: str
    gateway_ref: str
    amount: float
    status: str
    expires_at: datetime


class PaymentResponse(BaseModel):
    """Mobile money payment response model"""
    status: str
    message: str
    data: PaymentResponseData


class ErrorResponse(BaseModel):
    """Error response model"""
    status: str
    message: str
    code: Optional[str] = None


class WebhookPayload(BaseModel):
    """Webhook payload model for payment confirmation"""
    order_id: str
    payment_status: str
    reference: str
    amount: float
    metadata: Optional[Dict[str, Any]] = None


def create_payment_request(
        order_id: str,
        amount: float,
        buyer_phone: str,
        buyer_name: Optional[str] = None,
        buyer_email: Optional[str] = None,
        fee_payer: FeePayerEnum = FeePayerEnum.MERCHANT,
        metadata: Optional[Dict[str, Any]] = None,
        webhook_url: Optional[str] = None
) -> PaymentRequest:
    """
    Helper method to create a PaymentRequest object

    Args:
        order_id: Unique order identifier
        amount: Payment amount
        buyer_phone: Buyer's phone number (international format without +)
        buyer_name: Buyer's name
        buyer_email: Buyer's email
        fee_payer: Who pays the transaction fee (MERCHANT or CUSTOMER)
        metadata: Additional metadata
        webhook_url: URL for payment status webhooks

    Returns:
        PaymentRequest object
    """
    metadata_obj = PaymentRequestMetadata() if metadata else None

    return PaymentRequest(
        order_id=order_id,
        amount=amount,
        buyer_phone=buyer_phone,
        buyer_name=buyer_name,
        buyer_email=buyer_email,
        fee_payer=fee_payer,
        metadata=metadata_obj,
        webhook_url=webhook_url
    )


class MongikeClient:
    """
    Service for handling Mongike payment operations

    Supports:
    - Mobile money payments (Tanzania)
    - Webhook verification and processing
    - Payment status tracking
    """

    # Mongike API configuration
    BASE_URL = "https://mongike.com/api/v1"
    MOBILE_MONEY_ENDPOINT = "/payments/mobile-money/tanzania"

    def __init__(self, api_key: str):
        """
        Initialize PaymentService with API key

        Args:
            api_key: Mongike API key for authentication
        """
        if not api_key:
            raise ValueError("API key is required for PaymentService initialization")

        self.api_key = api_key
        self.headers = {
            "x-api-key": self.api_key,
            "Content-Type": "application/json"
        }

    def initiate_mobile_money_payment(self, payment_request: PaymentRequest) -> Any | None:
        """
        Initiate a mobile money payment request

        Args:
            payment_request: PaymentRequest object with payment details

        Returns:
            Payment response containing payment ID and status

        Raises:
            requests.exceptions.RequestException: If API request fails
            ValueError: If payment request is invalid
        """
        try:
            # Validate payment request
            if not payment_request.order_id:
                raise ValueError("Order ID is required")
            if payment_request.amount <= 0:
                raise ValueError("Amount must be greater than 0")
            if not payment_request.buyer_phone:
                raise ValueError("Buyer phone is required")
            if not payment_request.fee_payer:
                raise ValueError("Fee payer must be specified")

            # Prepare request payload
            payload = {
                "order_id": payment_request.order_id,
                "amount": payment_request.amount,
                "buyer_phone": payment_request.buyer_phone,
                "fee_payer": payment_request.fee_payer.value
            }

            # Add optional fields
            if payment_request.buyer_name:
                payload["buyer_name"] = payment_request.buyer_name
            if payment_request.buyer_email:
                payload["buyer_email"] = payment_request.buyer_email
            if payment_request.metadata:
                payload["metadata"] = payment_request.metadata.model_dump()
            if payment_request.webhook_url:
                payload["webhook_url"] = payment_request.webhook_url

            # Make API request
            url = f"{self.BASE_URL}{self.MOBILE_MONEY_ENDPOINT}"
            response = requests.post(
                url,
                json=payload,
                headers=self.headers,
                timeout=30
            )

            # Handle response
            if response.status_code == 201:
                logger.info(f"Payment initiated successfully for order {payment_request.order_id}")
                return response.json()
            elif response.status_code == 400:
                error_data = response.json()
                logger.error(f"Validation error for order {payment_request.order_id}: {error_data}")
                raise ValueError(f"Payment validation error: {error_data.get('message', 'Unknown error')}")
            else:
                logger.error(f"Payment API error (status {response.status_code}): {response.text}")
                response.raise_for_status()

        except requests.exceptions.Timeout:
            logger.error(f"Timeout initiating payment for order {payment_request.order_id}")
            raise
        except requests.exceptions.RequestException as e:
            logger.error(f"Request error initiating payment: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error initiating payment: {str(e)}")
            raise

    def verify_webhook_signature(self, x_api_key: str) -> bool:
        """
        Verify that webhook request is from Mongike

        Args:
            x_api_key: API key from webhook request header

        Returns:
            True if signature is valid, False otherwise
        """
        try:
            is_valid = x_api_key == self.api_key
            if not is_valid:
                logger.warning("Webhook signature verification failed")
            return is_valid
        except Exception as e:
            logger.error(f"Error verifying webhook signature: {str(e)}")
            return False

    def handle_payment_webhook(self, payload: WebhookPayload, x_api_key: str) -> Dict[str, Any]:
        """
        Handle incoming payment webhook from Mongike

        Args:
            payload: Webhook payload containing payment status update
            x_api_key: API key from webhook request header for verification

        Returns:
            Confirmation response

        Raises:
            ValueError: If webhook signature is invalid
        """
        try:
            # Verify webhook authenticity
            if not self.verify_webhook_signature(x_api_key):
                raise ValueError("Invalid webhook signature - unauthorized request")

            # Log webhook receipt
            logger.info(f"Webhook received for order {payload.order_id} with status {payload.payment_status}")

            # Validate webhook payload
            if payload.payment_status == PaymentStatus.COMPLETED.value:
                logger.info(f"Payment completed for order {payload.order_id}, reference: {payload.reference}")
                # Payment confirmation - update order status
                return {
                    "status": "success",
                    "message": "Payment webhook processed successfully",
                    "order_id": payload.order_id,
                    "reference": payload.reference
                }
            else:
                logger.warning(f"Payment status {payload.payment_status} for order {payload.order_id}")
                return {
                    "status": "pending",
                    "message": f"Payment status: {payload.payment_status}",
                    "order_id": payload.order_id
                }

        except ValueError as e:
            logger.error(f"Webhook validation error: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Error processing webhook: {str(e)}")
            raise

    def process_payment(
            self,
            order_id: str,
            amount: float,
            buyer_phone: str,
            buyer_name: Optional[str] = None,
            buyer_email: Optional[str] = None,
            fee_payer: FeePayerEnum = FeePayerEnum.MERCHANT,
            metadata: Optional[Dict[str, Any]] = None,
            webhook_url: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Convenience method to create and initiate a payment in one call

        Args:
            order_id: Unique order identifier
            amount: Payment amount
            buyer_phone: Buyer's phone number
            buyer_name: Buyer's name
            buyer_email: Buyer's email
            fee_payer: Who pays the transaction fee
            metadata: Additional metadata
            webhook_url: URL for payment status webhooks

        Returns:
            Payment response with payment details
        """
        payment_request = create_payment_request(
            order_id=order_id,
            amount=amount,
            buyer_phone=buyer_phone,
            buyer_name=buyer_name,
            buyer_email=buyer_email,
            fee_payer=fee_payer,
            metadata=metadata,
            webhook_url=webhook_url
        )

        return self.initiate_mobile_money_payment(payment_request)


# Export for module usage
__all__ = [
    "MongikeClient",
    "PaymentRequest",
    "PaymentResponse",
    "PaymentResponseData",
    "PaymentRequestMetadata",
    "ErrorResponse",
    "WebhookPayload",
    "FeePayerEnum",
    "PaymentStatus",
]

