from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel

from src.core.database import get_db
from src.services.admin import AdminService
from src.models.user import User, Collector, RoleEnum
from src.dependencies import get_sys_admin, get_current_user
from src.services.collector import CollectorService

router = APIRouter(prefix="/api/admin", tags=["System Administration"])


class VerificationRequest(BaseModel):
    approve: bool


@router.get("/collectors/pending")
def list_pending_collectors(
        db: Session = Depends(get_db),
        admin_user: User = Depends(get_sys_admin)
):
    """
    Returns a list of all unverified Collector companies.
    Only accessible by users with the SYS_ADMIN role.
    """
    try:
        collectors = AdminService.get_pending_collectors(db)
        return {
            "status": "success",
            "count": len(collectors),
            "data": [
                {
                    "collector_id": str(c.id),
                    "company_name": c.company_name,
                    "tin_number": c.tin_number,
                    "is_verified": c.is_verified
                } for c in collectors
            ]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.patch("/collectors/{collector_id}/verify")
def verify_collector_status(
        collector_id: str,
        req: VerificationRequest,
        db: Session = Depends(get_db),
        admin_user: User = Depends(get_sys_admin)
):
    """
    Approves or rejects a pending Collector company.
    Only accessible by users with the SYS_ADMIN role.
    """
    try:
        collector = AdminService.verify_collector(db, collector_id, req.approve)

        if req.approve:
            return {
                "status": "success",
                "message": f"Collector '{collector.company_name}' has been verified."
            }
        else:
            return {
                "status": "success",
                "message": "Collector application has been rejected and removed."
            }

    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail="Internal Server Error")


# Add this to src/api/routes/collectors.py

@router.get("/fleet/verified-directory")
def get_verified_fleet_directory(
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_user)
):
    """
    Returns a structured list of all officially verified Waste Management
    companies and the active drivers operating under their fleet.
    """
    try:
        collector_id = None
        if current_user.role != RoleEnum.SYS_ADMIN:
            if current_user.role != RoleEnum.COLLECTOR_ADMIN:
                raise HTTPException(status_code=403, detail="Access denied.")

            collector = db.query(Collector).filter(Collector.user_id == current_user.id).first()
            if not collector:
                raise HTTPException(status_code=404, detail="Collector profile not found.")
            collector_id = collector.id

        directory = CollectorService.get_verified_collectors_with_drivers(db, collector_id=collector_id)

        return {
            "status": "success",
            "verified_company_count": len(directory),
            "data": directory
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail="Internal Server Error")