from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional

from src.core.database import get_db
from src.services.collector import CollectorService
from src.models.user import VehicleTypeEnum, User, RoleEnum, Collector
from src.dependencies import get_current_user  # Assumes you have your JWT auth setup

router = APIRouter(prefix="/api/fleet", tags=["Fleet & Collectors"])


# --- Pydantic Schemas for Request Validation ---

class CollectorRegisterRequest(BaseModel):
    phone_number: str
    password: str
    company_name: str
    tin_number: Optional[str] = None


class WastepickerRegisterRequest(BaseModel):
    phone_number: str
    password: str
    vehicle_type: VehicleTypeEnum


class CollectorUpdateSchema(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone_number: Optional[str] = None
    company_name: Optional[str] = None
    tin_number: Optional[str] = None
    ward_id: Optional[str] = None


class WastepickerUpdateSchema(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone_number: Optional[str] = None
    vehicle_type: Optional[VehicleTypeEnum] = None
    is_online: Optional[bool] = None


# --- Endpoints ---

@router.post("/register-company")
def register_collector_company(req: CollectorRegisterRequest, db: Session = Depends(get_db)):
    """Open endpoint for waste management companies to sign up."""
    try:
        user, collector = CollectorService.register_collector(
            db=db,
            phone=req.phone_number,
            password=req.password,
            company_name=req.company_name,
            tin_number=req.tin_number
        )
        return {
            "status": "success",
            "message": "Collector company registered successfully.",
            "data": {
                "user_id": str(user.id),
                "collector_id": str(collector.id),
                "company_name": collector.company_name
            }
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.post("/add-driver")
def add_wastepicker_to_fleet(
        req: WastepickerRegisterRequest,
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_user)  # Require valid JWT Token
):
    """
    Protected endpoint. Only logged-in Collector Admins can add drivers to their fleet.
    """
    # Security Check: Ensure the user calling this API is a Collector Admin
    if current_user.role != RoleEnum.COLLECTOR_ADMIN:
        raise HTTPException(status_code=403, detail="Only Collector Admins can add drivers.")

    # Find the Collector profile associated with the currently logged-in user
    from src.models.user import Collector
    collector_profile = db.query(Collector).filter(Collector.user_id == current_user.id).first()

    if not collector_profile:
        raise HTTPException(status_code=404, detail="Collector profile not found.")

    try:
        user, wastepicker = CollectorService.register_wastepicker(
            db=db,
            collector_id=collector_profile.id,
            phone=req.phone_number,
            password=req.password,
            vehicle_type=req.vehicle_type
        )
        return {
            "status": "success",
            "message": "Driver added to fleet successfully.",
            "data": {
                "wastepicker_id": str(wastepicker.id),
                "vehicle_type": wastepicker.vehicle_type.name
            }
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.get("/drivers")
def list_fleet_drivers(
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_user)
):
    """Returns all drivers in the authenticated collector admin's fleet."""
    if current_user.role != RoleEnum.COLLECTOR_ADMIN:
        raise HTTPException(status_code=403, detail="Only Collector Admins can view fleet drivers.")

    collector_profile = db.query(Collector).filter(Collector.user_id == current_user.id).first()
    if not collector_profile:
        raise HTTPException(status_code=404, detail="Collector profile not found.")

    try:
        drivers = CollectorService.get_collector_drivers(db=db, collector_id=collector_profile.id)
        return {
            "status": "success",
            "count": len(drivers),
            "data": drivers
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.patch("/profile")
def update_collector_profile(
        payload: CollectorUpdateSchema,
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_user)
):
    if current_user.role != RoleEnum.COLLECTOR_ADMIN:
        raise HTTPException(status_code=403, detail="Access denied.")

    try:
        user, collector = CollectorService.update_collector_profile(
            db=db,
            user=current_user,
            **payload.dict(exclude_unset=True)
        )
        return {
            "status": "success",
            "message": "Collector profile updated successfully.",
            "data": {
                "company_name": collector.company_name,
                "phone_number": user.phone_number
            }
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.patch("/drivers/{wastepicker_id}")
def update_wastepicker_profile(
        wastepicker_id: str,
        payload: WastepickerUpdateSchema,
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_user)
):
    """
    Allows a Collector Admin to update a driver in their fleet,
    or a Wastepicker to update their own profile (is_online, etc).
    """
    from src.models.user import Wastepicker, Collector
    
    target_wastepicker = db.query(Wastepicker).filter(Wastepicker.id == wastepicker_id).first()
    if not target_wastepicker:
        raise HTTPException(status_code=404, detail="Wastepicker not found.")

    # Authorization logic
    can_edit = False
    if current_user.role == RoleEnum.SYS_ADMIN:
        can_edit = True
    elif current_user.role == RoleEnum.COLLECTOR_ADMIN:
        # Check if the wastepicker belongs to this collector's fleet
        collector_profile = db.query(Collector).filter(Collector.user_id == current_user.id).first()
        if collector_profile and str(target_wastepicker.collector_id) == str(collector_profile.id):
            can_edit = True
    elif current_user.role == RoleEnum.WASTEPICKER:
        if str(target_wastepicker.user_id) == str(current_user.id):
            can_edit = True

    if not can_edit:
        raise HTTPException(status_code=403, detail="You do not have permission to update this profile.")

    target_user = db.query(User).filter(User.id == target_wastepicker.user_id).first()

    try:
        user, wp = CollectorService.update_wastepicker_profile(
            db=db,
            user=target_user,
            **payload.dict(exclude_unset=True)
        )
        return {
            "status": "success",
            "message": "Wastepicker profile updated successfully.",
            "data": {
                "wastepicker_id": str(wp.id),
                "is_online": wp.is_online,
                "vehicle_type": wp.vehicle_type.name
            }
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail="Internal Server Error")