from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from pydantic import BaseModel

from src.core.database import get_db
from src.services.auth import AuthService
from src.models.user import CustomerTypeEnum

router = APIRouter(prefix="/api/auth", tags=["Authentication"])

class CustomerRegisterSchema(BaseModel):
    first_name: str
    last_name: str
    phone_number: str
    password: str
    customer_type: CustomerTypeEnum
    lat: float
    lon: float

@router.post("/login")
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    """
    Standard OAuth2 Login endpoint.
    Expects 'username' (which we treat as phone_number) and 'password' as form data.
    """
    return AuthService.login_and_create_token(
        db=db,
        phone_number=form_data.username,
        password=form_data.password
    )

@router.post("/register/customer")
def register_customer(payload: CustomerRegisterSchema, db: Session = Depends(get_db)):
    try:
        user = AuthService.register_customer(
            last_name=payload.last_name,
            first_name=payload.first_name,
            db=db,
            phone=payload.phone_number,
            password=payload.password,
            customer_type=payload.customer_type,
            lat=payload.lat,
            lon=payload.lon
        )
        return {"status": "success", "message": "Customer created successfully", "user_id": user.id}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))