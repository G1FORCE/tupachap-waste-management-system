from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from geoalchemy2.shape import to_shape
from sqlalchemy.orm import Session
from pydantic import BaseModel

from sqlalchemy import func
from src.core.database import get_db
from src.dependencies import get_current_active_customer
from src.services.customer import CustomerService
from src.models.user import Customer, User, CustomerTypeEnum

router = APIRouter(prefix="/customers", tags=["Customer Portal"])


class CustomerUpdateSchema(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone_number: Optional[str] = None
    customer_type: Optional[CustomerTypeEnum] = None
    lat: Optional[float] = None
    lon: Optional[float] = None



def get_customer_profile(db: Session, current_user: User):
    """Utility to quickly grab the Customer ID and Location from the logged-in User ID."""
    # We use func.ST_X and func.ST_Y to extract coordinates from the Geometry column
    result = db.query(
        Customer,
        func.ST_X(Customer.default_location).label('lon'),
        func.ST_Y(Customer.default_location).label('lat')
    ).filter(Customer.user_id == str(current_user.id)).first()

    if not result:
        raise HTTPException(status_code=404, detail="Customer profile not found.")
    
    return result

@router.get("/profile")
def get_profile(db: Session = Depends(get_db), current_user: User = Depends(get_current_active_customer)):
    customer_data = get_customer_profile(db, current_user)
    customer = customer_data.Customer
    
    return {
        "status": "success",
        "data": {
            "user_id": str(current_user.id),
            "customer_id": str(customer.id),
            "customer_type": customer.customer_type.name,
            "phone_number": current_user.phone_number,
            "first_name": current_user.first_name,
            "last_name": current_user.last_name,
            "role": current_user.role.name,
            "lat": float(customer_data.lat) if customer_data.lat is not None else None,
            "lon": float(customer_data.lon) if customer_data.lon is not None else None
        }
    }

@router.get("/trips")
def list_my_trips(
        limit: int = Query(20, ge=1, le=100, description="How many trips to fetch"),
        offset: int = Query(0, ge=0, description="Pagination offset"),
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_active_customer)
):
    """
    Returns a paginated list of the customer's past and active trips.
    """
    customer_data = get_customer_profile(db, current_user)
    customer = customer_data.Customer
    trips = CustomerService.get_my_trips(db, str(customer.id), limit, offset)

    return {
        "status": "success",
        "data": [
            {
                "trip_id": str(t.id),
                "status": t.status.name,
                "pickup_method": t.pickup_method.name,
                "waste_class": [wc.name for wc in t.waste_class],
                "fare_tzs": float(t.base_fare_tzs),
                "qr_hash": t.qr_code_hash,
                "created_at": t.created_at,
                "pickup_location": {'coordinates': [to_shape(t.pickup_location).x, to_shape(t.pickup_location).y]},
                "driver_assigned": t.wastepicker_id is not None
            } for t in trips
        ]
    }


@router.patch("/trips/{trip_id}/cancel")
def cancel_my_trip(
        trip_id: str,
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_active_customer)
):
    """
    Cancels an active trip request, provided a driver hasn't accepted it yet.
    """
    customer_data = get_customer_profile(db, current_user)
    customer = customer_data.Customer

    try:
        trip = CustomerService.cancel_trip(db, str(customer.id), trip_id)

        return {
            "status": "success",
            "message": "Trip cancelled successfully.",
            "data": {
                "trip_id": str(trip.id),
                "status": trip.status.name
            }
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail="Internal Server Error")

@router.patch("/profile")
def update_profile(
        payload: CustomerUpdateSchema,
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_active_customer)
):
    try:
        user, customer = CustomerService.update_customer_profile(
            db=db,
            user=current_user,
            **payload.dict(exclude_unset=True)
        )
        return {
            "status": "success",
            "message": "Profile updated successfully.",
            "data": {
                "first_name": user.first_name,
                "last_name": user.last_name,
                "phone_number": user.phone_number,
                "customer_type": customer.customer_type.name
            }
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail="Internal Server Error")

