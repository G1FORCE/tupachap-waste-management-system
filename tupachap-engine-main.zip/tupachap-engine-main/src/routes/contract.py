from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field
from datetime import date

from src.core.database import get_db
from src.services.profile_contract import ProfileService
from src.models.user import CustomerTypeEnum, Customer
from src.models.operations import BillingCycleEnum
from src.dependencies import get_current_user, get_current_active_customer

router = APIRouter(prefix="/contract", tags=["Profiles & Contracts"])


# ==========================================
# PYDANTIC SCHEMAS
# ==========================================

class CustomerProfileRequest(BaseModel):
    customer_type: CustomerTypeEnum = Field(..., description="Type of customer (e.g., HOUSEHOLD, HOSPITAL)")
    lat: float = Field(..., description="Latitude of the default pickup location")
    lon: float = Field(..., description="Longitude of the default pickup location")


class SubscriptionRequest(BaseModel):
    billing_cycle: BillingCycleEnum = Field(..., description="Frequency of billing (e.g., ANNUALLY, MONTHLY)")
    start_date: date = Field(..., description="Contract start date (YYYY-MM-DD)")
    pickup_day: int = Field(..., description="The first pickup day from the creation of the subscription contract")
    end_date: date = Field(..., description="Contract end date (YYYY-MM-DD)")


# ==========================================
# API ENDPOINTS
# ==========================================

@router.post("/setup")
def setup_customer_profile(
        req: CustomerProfileRequest,
        db: Session = Depends(get_db),
        current_user=Depends(get_current_user)
):
    existing_profile = db.query(Customer).filter(Customer.user_id == str(current_user.id)).first()
    if existing_profile:
        raise HTTPException(status_code=400, detail="A customer profile already exists for this user.")

    try:
        profile = ProfileService.create_customer_profile(
            db=db,
            user_id=str(current_user.id),
            customer_type=req.customer_type,
            lat=req.lat,
            lon=req.lon
        )
        return {
            "status": "success",
            "message": "Customer profile and location saved successfully.",
            "data": {
                "customer_id": str(profile.id),
                "customer_type": profile.customer_type.name
            }
        }
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to create profile: {str(e)}")


@router.post("/subscribe")
def create_subscription_contract(
        req: SubscriptionRequest,
        db: Session = Depends(get_db),
        current_user=Depends(get_current_active_customer)
):
    customer = db.query(Customer).filter(Customer.user_id == str(current_user.id)).first()
    if not customer:
        raise HTTPException(status_code=404, detail="You must set up a customer profile first before subscribing.")

    if req.end_date <= req.start_date:
        raise HTTPException(status_code=400, detail="End date must be after start date.")

    try:
        contract = ProfileService.create_subscription_contract(
            db=db,
            customer_id=str(customer.id),
            cycle=req.billing_cycle,
            pickup_day=req.pickup_day,
            start=req.start_date,
            end=req.end_date
        )
        return {
            "status": "success",
            "message": "Subscription contract drafted. Pending payment.",
            "data": {
                "contract_id": str(contract.id),
                "status": contract.contract_status.name,
                "billing_cycle": contract.billing_cycle.name
            }
        }
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to create contract: {str(e)}")


# ==========================================
# NEW ENDPOINT: View Current Contract
# ==========================================
@router.get("/contract")
def get_current_contract_details(
        db: Session = Depends(get_db),
        current_user=Depends(get_current_active_customer)
):
    """
    Fetches the details of the customer's current active or pending subscription contract.
    """
    # 1. Ensure the user has a customer profile
    customer = db.query(Customer).filter(Customer.user_id == str(current_user.id)).first()
    if not customer:
        raise HTTPException(status_code=404, detail="Customer profile not found.")

    # 2. Fetch the contract using the service
    contract = ProfileService.get_current_contract(db, str(customer.id))

    if not contract:
        raise HTTPException(status_code=404, detail="No active or previous subscription contract found.")

    # 3. Format the response
    return {
        "status": "success",
        "data": {
            "contract_id": str(contract.id),
            "billing_cycle": contract.billing_cycle.name,
            "start_date": contract.start_date,
            "end_date": contract.end_date,
            "status": contract.contract_status.name,
            "pickup_day": contract.pickup_day,
            # Calculate if the contract is currently active based on dates and status
            "is_valid_today": (
                    contract.contract_status.name == "ACTIVE" and
                    contract.start_date <= date.today() <= contract.end_date
            )
        }
    }