from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from src.core.database import get_db
from src.services.analytics import AnalyticsService
from src.dependencies import get_current_user, get_sys_admin
from src.models.user import User, RoleEnum, Wastepicker, Collector

router = APIRouter(prefix="/api/analytics", tags=["Data & Analytics"])


@router.get("/wastepicker/me")
def get_my_driver_stats(
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_user)
):
    """Driver App: View personal earnings, completed trips, and history."""
    if current_user.role != RoleEnum.WASTEPICKER:
        raise HTTPException(status_code=403, detail="Only wastepickers can access this.")

    picker = db.query(Wastepicker).filter(Wastepicker.user_id == current_user.id).first()
    return AnalyticsService.get_wastepicker_stats(db, str(picker.id))


@router.get("/collector/dashboard")
def get_fleet_dashboard(
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_user)
):
    """Collector Admin App: View overall fleet revenue and active contracts."""
    if current_user.role != RoleEnum.COLLECTOR_ADMIN:
        raise HTTPException(status_code=403, detail="Only fleet owners can access this.")

    collector = db.query(Collector).filter(Collector.user_id == current_user.id).first()
    return AnalyticsService.get_collector_dashboard(db, str(collector.id))


@router.get("/admin/wards", dependencies=[Depends(get_sys_admin)])
def view_ward_activity(db: Session = Depends(get_db)):
    """Admin Dashboard: Shows which municipal wards generate the most trips."""
    try:
        data = AnalyticsService.get_ward_trip_history(db)
        return {"status": "success", "data": data}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/admin/heatmap", dependencies=[Depends(get_sys_admin)])
def view_waste_heatmap(db: Session = Depends(get_db)):
    """
    Admin Dashboard: Returns raw lat/lon coordinates of completed pickups.
    Plug this directly into Google Maps Heatmap Layer or Mapbox GL.
    """
    try:
        points = AnalyticsService.get_waste_heatmap_data(db)
        return {
            "status": "success",
            "total_points": len(points),
            "data": points
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))