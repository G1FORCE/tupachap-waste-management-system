import uuid
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field
from typing import Optional, List

from src.core.database import get_db
from src.services.trip import TripService
from src.models.operations import WasteClassEnum, TripStatusEnum, PickupMethodEnum
from src.models.user import RoleEnum, Wastepicker
from src.dependencies import get_current_active_customer, get_current_wastepicker
from geoalchemy2.shape import to_shape

router = APIRouter(prefix="/trips", tags=["Trips & Dispatch"])


# ==========================================
# PYDANTIC SCHEMAS (Request & Response Validation)
# ==========================================

class TripResponse(BaseModel):
    id: uuid.UUID
    customer_id: uuid.UUID
    wastepicker_id: Optional[uuid.UUID] = None
    pickup_method: PickupMethodEnum
    waste_class: List[WasteClassEnum]
    status: TripStatusEnum
    pickup_location: dict
    dumpsite_location: dict
    qr_code_hash: str
    base_fare_tzs: float
    created_at: datetime

    class Config:
        from_attributes = True

    @classmethod
    def from_orm_model(cls, trip):
        # Convert Geometry to GeoJSON-like dict
        pickup_shape = to_shape(trip.pickup_location)
        dumpsite_shape = to_shape(trip.dumpsite_location)
        
        return cls(
            id=trip.id,
            customer_id=trip.customer_id,
            wastepicker_id=trip.wastepicker_id,
            pickup_method=trip.pickup_method,
            waste_class=trip.waste_class,
            status=trip.status,
            pickup_location={"type": "Point", "coordinates": [pickup_shape.x, pickup_shape.y]},
            dumpsite_location={"type": "Point", "coordinates": [dumpsite_shape.x, dumpsite_shape.y]},
            qr_code_hash=trip.qr_code_hash,
            base_fare_tzs=float(trip.base_fare_tzs),
            created_at=trip.created_at
        )

class ImmediatePickupRequest(BaseModel):
    lat: float = Field(..., description="Latitude of the pickup location")
    lon: float = Field(..., description="Longitude of the pickup location")
    waste_class: List[WasteClassEnum] = Field(..., description="List of waste classes to be picked up")
    image_estimated_price: float = Field(default=0.0, description="Estimated price returned by the AI Verification API")
    estimation_image_url: Optional[List[str]] = Field(default=None, description="URL of the uploaded waste image")


class ScanQRRequest(BaseModel):
    qr_hash: str


class UpdateTripPicsRequest(BaseModel):
    estimation_pics: Optional[List[str]] = None
    pickup_pics: Optional[List[str]] = None
    dumpsite_pics: Optional[List[str]] = None


# ==========================================
# API ENDPOINTS
# ==========================================

@router.post("/request-immediate")
def create_immediate_trip(
        req: ImmediatePickupRequest,
        db: Session = Depends(get_db),
        current_user=Depends(get_current_active_customer)  # Ensures only logged-in customers can request a trip
):
    """
    Endpoint for on-demand/immediate pickups.
    The mobile app should first call the Media/AI API to get the estimated price and image URL,
    and then pass those values into this endpoint.
    """
    try:
        # Call the TripService you provided
        result = TripService.request_immediate_pickup(
            db=db,
            customer_id=str(current_user.id),  # Extracted securely from the JWT token
            waste_class=req.waste_class,
            lat=req.lat,
            lon=req.lon,
            image_estimated_price=req.image_estimated_price,
            estimation_image_url=req.estimation_image_url
        )

        return {
            "status": "success",
            "message": "Trip requested successfully",
            "data": {
                "trip": TripResponse.from_orm_model(result["trip"]),
                "ward": result["ward_name"],
            }
        }

    except ValueError as e:
        # This catches your custom errors: "Pickup location is outside of supported zones"
        # or "No active dumpsite found..."
        raise HTTPException(status_code=400, detail=str(e))

    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"An error occurred while creating the trip: {str(e)}")


@router.get("/{trip_id}/status")
def get_trip_status(
        trip_id: str,
        db: Session = Depends(get_db),
        current_user=Depends(get_current_active_customer)
):
    """
    Allows the mobile app to poll for the trip status.
    Useful if a driver wasn't found immediately and the app is waiting for one to accept.
    """
    from src.models.operations import Trip

    trip = db.query(Trip).filter(Trip.id == trip_id, Trip.customer_id == str(current_user.id)).first()

    if not trip:
        raise HTTPException(status_code=404, detail="Trip not found")

    return {
        "status": "success",
        "data": TripResponse.from_orm_model(trip)
    }


# ==========================================
# WASTEPICKER ENDPOINTS
# ==========================================

@router.post("/{trip_id}/scan-qr")
def scan_trip_qr(
        trip_id: str,
        req: ScanQRRequest,
        db: Session = Depends(get_db),
        current_user=Depends(get_current_wastepicker)
):
    """
    Endpoint for wastepickers to scan the customer's QR code.
    Transitions the trip to 'IN_TRANSIT'.
    """
    # Get wastepicker profile
    wastepicker = db.query(Wastepicker).filter(Wastepicker.user_id == current_user.id).first()
    if not wastepicker:
        raise HTTPException(status_code=404, detail="Wastepicker profile not found.")

    try:
        trip = TripService.scan_trip_qr(
            db=db,
            wastepicker_id=str(wastepicker.id),
            trip_id=trip_id,
            qr_hash=req.qr_hash
        )
        return {
            "status": "success",
            "message": "QR code verified. Trip is now in transit.",
            "data": {
                "trip_id": str(trip.id),
                "status": trip.status.name
            }
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.patch("/{trip_id}/pics")
def update_trip_pics(
        trip_id: str,
        req: UpdateTripPicsRequest,
        db: Session = Depends(get_db),
        current_user=Depends(get_current_wastepicker)
):
    """
    Endpoint for wastepickers to upload pics during different stages.
    Expects URLs of images already uploaded to a storage service.
    """
    wastepicker = db.query(Wastepicker).filter(Wastepicker.user_id == current_user.id).first()
    if not wastepicker:
        raise HTTPException(status_code=404, detail="Wastepicker profile not found.")

    try:
        proof = TripService.update_trip_pics(
            db=db,
            wastepicker_id=str(wastepicker.id),
            trip_id=trip_id,
            estimation_pics=req.estimation_pics,
            pickup_pics=req.pickup_pics,
            dumpsite_pics=req.dumpsite_pics
        )
        return {
            "status": "success",
            "message": "Trip pictures updated successfully.",
            "data": {
                "proof_id": str(proof.id)
            }
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/{trip_id}/complete")
def complete_trip(
        trip_id: str,
        db: Session = Depends(get_db),
        current_user=Depends(get_current_wastepicker)
):
    """
    Endpoint for wastepickers to complete a trip.
    """
    wastepicker = db.query(Wastepicker).filter(Wastepicker.user_id == current_user.id).first()
    if not wastepicker:
        raise HTTPException(status_code=404, detail="Wastepicker profile not found.")

    try:
        trip = TripService.complete_trip(
            db=db,
            wastepicker_id=str(wastepicker.id),
            trip_id=trip_id
        )
        return {
            "status": "success",
            "message": "Trip completed successfully.",
            "data": {
                "trip_id": str(trip.id),
                "status": trip.status.name
            }
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/my-assigned")
def get_my_assigned_trips(
        db: Session = Depends(get_db),
        current_user=Depends(get_current_wastepicker)
):
    """
    Returns trips currently assigned to the logged-in waste picker
    (status: ACCEPTED or IN_TRANSIT).
    """
    wastepicker = db.query(Wastepicker).filter(Wastepicker.user_id == current_user.id).first()
    if not wastepicker:
        raise HTTPException(status_code=404, detail="Wastepicker profile not found.")

    trips = TripService.get_wastepicker_trips(
        db=db,
        wastepicker_id=str(wastepicker.id),
        status_filter="assigned"
    )
    return {
        "status": "success",
        "data": [TripResponse.from_orm_model(t) for t in trips]
    }


@router.get("/available")
def get_available_trips(
        db: Session = Depends(get_db),
        current_user=Depends(get_current_wastepicker)
):
    """
    Returns REQUESTED trips that are not yet assigned to any driver.
    """
    wastepicker = db.query(Wastepicker).filter(Wastepicker.user_id == current_user.id).first()
    if not wastepicker:
        raise HTTPException(status_code=404, detail="Wastepicker profile not found.")

    trips = TripService.get_wastepicker_trips(
        db=db,
        wastepicker_id=str(wastepicker.id),
        status_filter="available"
    )
    return {
        "status": "success",
        "data": [TripResponse.from_orm_model(t) for t in trips]
    }