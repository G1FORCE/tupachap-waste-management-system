from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Header, Request
from sqlalchemy.orm import Session
from pydantic import BaseModel

from src.core.database import get_db
from src.models import Trip, Contract, Customer
from src.services.payment import PaymentService
from src.core.mongike_client import WebhookPayload
from src.dependencies import get_current_active_customer

router = APIRouter(prefix="/payments", tags=["Billing & Payments"])


class PaymentInitiateRequest(BaseModel):
    contract_id: Optional[str]
    trip_id: Optional[str]
    amount: float
    phone_number: str


@router.post("/initiate/trip")
def initiate_payment(
        req: PaymentInitiateRequest,
        db: Session = Depends(get_db),
        current_user=Depends(get_current_active_customer)
):
    """
    Called by the mobile app to trigger a USSD push to the user's phone.
    """
    try:
        trip = db.query(Trip).filter(Trip.id == req.trip_id).first()
        if trip.base_fare_tzs != req.amount:
            raise HTTPException(status_code=400, detail="Fare amount does not match our records.")
        customer = db.query(Customer).filter(Customer.user_id == current_user.id).first()
        payment, gateway_response = PaymentService.initiate_trip_payment(
            db=db,
            customer_id=str(customer.id),
            trip_id=req.trip_id,
            amount=req.amount,
            phone=req.phone_number
        )
        return {
            "status": "success",
            "message": "Payment prompt sent to phone.",
            "payment_id": str(payment.id),
            "gateway_data": gateway_response
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/initiate/contract")
def initiate_contract_payment(
        req: PaymentInitiateRequest,
        db: Session = Depends(get_db),
        current_user=Depends(get_current_active_customer)
):
    """
    Called by the mobile app to trigger a USSD push to the user's phone.
    """
    try:
        trip = db.query(Contract).filter(Contract.id == req.contract_id).first()
        if trip.base_fare_tzs > req.amount:
            raise HTTPException(status_code=400, detail="Fare amount does not match our records.")
        customer = db.query(Customer).filter(Customer.user_id == current_user.id).first()
        payment, gateway_response = PaymentService.initiate_contract_payment(
            db=db,
            customer_id=str(customer.id),
            contract_id=req.contract_id,
            amount=req.amount,
            phone=req.phone_number
        )
        return {
            "status": "success",
            "message": "Payment prompt sent to phone.",
            "payment_id": str(payment.id),
            "gateway_data": gateway_response
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))



@router.post("/webhook/mongike")
async def mongike_webhook(
        payload: WebhookPayload,
        request: Request,
        db: Session = Depends(get_db)
):
    """
    Public webhook endpoint for Mongike to send payment status updates.
    """
    # Extract the API key from headers (Mongike uses 'x-api-key')
    x_api_key = request.headers.get("x-api-key")

    if not x_api_key:
        raise HTTPException(status_code=401, detail="Missing API Key header")

    try:
        result = PaymentService.process_mongike_webhook(db, payload, x_api_key)
        # Always return 200 to acknowledge receipt to the gateway
        return result

    except ValueError as e:
        # Signature mismatch or missing DB record
        raise HTTPException(status_code=400, detail=str(e))