from jose import jwt, exceptions
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Query
from sqlalchemy.orm import Session
from typing import Optional

from src.core.database import SessionLocal
from src.core.websocket_manager import manager
from src.core.security import SECRET_KEY, ALGORITHM
from src.models.user import User, Wastepicker, RoleEnum

router = APIRouter(prefix="/api/ws", tags=["Live Tracking"])


# ==========================================
# HELPER: WebSocket Authentication
# ==========================================
def get_user_from_token(token: str, db: Session) -> Optional[User]:
    """Authenticates a WebSocket connection using a JWT token from query params."""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")
        if user_id:
            return db.query(User).filter(User.id == user_id).first()
    except exceptions.JWTError:
        return None
    return None


# ==========================================
# 1. WASTE PICKER PUBLISHER ENDPOINT
# ==========================================
@router.websocket("/driver/{trip_id}")
async def driver_location_publisher(
        websocket: WebSocket,
        trip_id: str,
        token: str = Query(...)
):
    """
    The Mobile App for the Waste Picker connects here to push live GPS updates.
    """
    db = SessionLocal()
    user = get_user_from_token(token, db)

    # Secure the connection: Ensure they are a logged-in waste picker
    if not user or user.role != RoleEnum.WASTEPICKER:
        await websocket.close(code=1008, reason="Unauthorized or invalid role")
        db.close()
        return

    picker_profile = db.query(Wastepicker).filter(Wastepicker.user_id == user.id).first()

    await manager.connect(websocket, trip_id)

    try:
        while True:
            # 1. Wait for the mobile app to send coordinates
            # Expected JSON: {"lat": -6.7924, "lon": 39.2083, "heading": 90, "speed": 15}
            data = await websocket.receive_json()

            # 2. Broadcast the live location to the Customer listening in the same room
            broadcast_message = {
                "type": "LOCATION_UPDATE",
                "lat": data.get("lat"),
                "lon": data.get("lon"),
                "heading": data.get("heading", 0),  # Useful for rotating the car icon on the map
                "speed": data.get("speed", 0)
            }
            await manager.broadcast_to_trip(trip_id, broadcast_message)

            # 3. Update the database (PostGIS) silently
            # Note: In a massive scale app, you'd batch these updates to avoid hammering the DB.
            if picker_profile and data.get("lat") and data.get("lon"):
                try:
                    point_geom = f"SRID=4326;POINT({data['lon']} {data['lat']})"
                    picker_profile.last_known_location = point_geom
                    db.commit()
                except Exception as e:
                    db.rollback()
                    print(f"Error updating driver location: {e}")

    except WebSocketDisconnect:
        manager.disconnect(websocket, trip_id)
        # Notify the customer that the driver went offline
        await manager.broadcast_to_trip(trip_id, {
            "type": "STATUS_UPDATE",
            "status": "DRIVER_DISCONNECTED",
            "message": "Driver lost connection."
        })
    finally:
        try:
            db.close()
        except Exception as e:
            print(f"Error closing DB session for driver: {e}")


# ==========================================
# 2. CUSTOMER SUBSCRIBER ENDPOINT
# ==========================================
@router.websocket("/customer/{trip_id}")
async def customer_location_subscriber(
        websocket: WebSocket,
        trip_id: str,
        token: str = Query(...)
):
    """
    The Mobile App for the Customer connects here to listen for the driver's GPS updates.
    """
    db = SessionLocal()
    user = get_user_from_token(token, db)

    # Secure the connection
    if not user:
        await websocket.close(code=1008, reason="Unauthorized")
        db.close()
        return

    await manager.connect(websocket, trip_id)

    try:
        # Acknowledge connection
        await websocket.send_json({"type": "SYSTEM", "message": "Connected to live tracking."})

        while True:
            # The customer connection stays open just to receive messages.
            # We use receive_text() to keep the connection alive (ping/pong).
            await websocket.receive_text()

    except WebSocketDisconnect:
        manager.disconnect(websocket, trip_id)
    finally:
        try:
            db.close()
        except Exception as e:
            print(f"Error closing DB session for customer: {e}")