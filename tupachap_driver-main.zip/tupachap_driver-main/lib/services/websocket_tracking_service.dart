import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'api_service.dart';

class WebSocketTrackingService {
  static final WebSocketTrackingService _instance = WebSocketTrackingService._internal();
  factory WebSocketTrackingService() => _instance;
  WebSocketTrackingService._internal();

  WebSocketChannel? _tripChannel;
  StreamSubscription? _subscription;
  final ApiService _apiService = ApiService();

  Function(double lat, double lon)? onCollectorLocationUpdate;
  Function(String error)? onError;

  Future<void> connectToTripTracking({
    required String tripId,
    required String token,
    required String userType,
  }) async {
    try {
      // Use publishLocation for drivers as defined in ApiService
      _tripChannel = _apiService.publishLocation(tripId, token);

      _subscription = _tripChannel!.stream.listen(
        (message) {
          final data = jsonDecode(message);
          if (data['lat'] != null && data['lon'] != null) {
            onCollectorLocationUpdate?.call(
              (data['lat'] as num).toDouble(),
              (data['lon'] as num).toDouble(),
            );
          }
        },
        onError: (err) => onError?.call(err.toString()),
        onDone: () => debugPrint('WS Connection Closed'),
      );
    } catch (e) {
      onError?.call(e.toString());
    }
  }

  void broadcastCollectorLocation({
    required double latitude,
    required double longitude,
    double? accuracy,
    double? heading,
  }) {
    if (_tripChannel != null) {
      _apiService.sendLocationUpdate(
        _tripChannel!,
        lat: latitude,
        lon: longitude,
        heading: heading ?? 0,
      );
    }
  }

  void disconnectAll() {
    _subscription?.cancel();
    _tripChannel?.sink.close();
    _tripChannel = null;
  }

  void dispose() => disconnectAll();

  List<LatLng> decodePolyline(String encoded) {
    final polylinePoints = PolylinePoints();
    final result = polylinePoints.decodePolyline(encoded);
    return result.map((point) => LatLng(point.latitude, point.longitude)).toList();
  }
}

class LatLng {
  final double latitude;
  final double longitude;
  LatLng(this.latitude, this.longitude);
}
