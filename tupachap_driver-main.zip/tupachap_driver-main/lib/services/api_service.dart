import 'dart:io';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:http_parser/http_parser.dart';
import 'dart:async';

/// ApiService for Tupachap Waste Management System
/// This client facilitates communication between the mobile apps and the backend.
class ApiService {
  static const String baseUrl = "https://tupachap-engine.onrender.com";
  static const String mlVisionUrl = "https://tupachap-vision-ml.onrender.com";

  String get _wsBaseUrl => baseUrl.replaceFirst('https://', 'wss://').replaceFirst('http://', 'ws://');

  // ==========================================
  // AUTHENTICATION
  // ==========================================

  /// Login and receive access token
  /// Backend expects OAuth2 form data (username, password)
  Future<AccessCredentials> login(String phoneNumber, String password) async {
    var url = Uri.parse('$baseUrl/api/auth/login');
    var response = await http.post(
      url,
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: {
        'username': phoneNumber,
        'password': password,
      },
    );

    if (response.statusCode != 200) {
      final errorData = jsonDecode(response.body);
      throw Exception(errorData['detail'] ?? 'Login failed');
    }

    final data = jsonDecode(response.body);

    return AccessCredentials(
      accessToken: data['access_token'],
      tokenType: data['token_type'] ?? 'bearer',
      role: data['role'] ?? 'CUSTOMER',
    );
  }
  // ==========================================
  // WASTEPICKER WORKFLOW
  // ==========================================

  /// Wastepicker: Get assigned trips (ACCEPTED or IN_TRANSIT)
  Future<List<dynamic>> getMyAssignedTrips(String token) async {
    var url = Uri.parse('$baseUrl/trips/my-assigned');
    var response = await http.get(
      url,
      headers: {'Authorization': 'Bearer $token'},
    );

    if (response.statusCode != 200) {
      throw Exception('Failed to fetch assigned trips: ${response.body}');
    }
    return jsonDecode(response.body)['data'];
  }

  /// Wastepicker: Get available trips (REQUESTED and unassigned)
  Future<List<dynamic>> getAvailableTrips(String token) async {
    var url = Uri.parse('$baseUrl/trips/available');
    var response = await http.get(
      url,
      headers: {'Authorization': 'Bearer $token'},
    );

    if (response.statusCode != 200) {
      throw Exception('Failed to fetch available trips: ${response.body}');
    }
    return jsonDecode(response.body)['data'];
  }

  /// Wastepicker: Get personal stats (earnings, trip counts, history)
  Future<Map<String, dynamic>> getWastepickerStats(String token) async {
    var url = Uri.parse('$baseUrl/api/analytics/wastepicker/me');
    var response = await http.get(
      url,
      headers: {'Authorization': 'Bearer $token'},
    );

    if (response.statusCode != 200) {
      throw Exception('Failed to get wastepicker stats: ${response.body}');
    }
    return jsonDecode(response.body);
  }

  /// Wastepicker: Scan the customer's QR code to start the trip
  /// Transitions status to IN_TRANSIT
  Future<Map<String, dynamic>> scanTripQR(String token, String tripId, String qrHash) async {
    var url = Uri.parse('$baseUrl/trips/$tripId/scan-qr');
    var response = await http.post(
      url,
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({'qr_hash': qrHash}),
    );

    if (response.statusCode != 200) {
      throw Exception('Failed to verify QR code: ${response.body}');
    }
    return jsonDecode(response.body);
  }

  /// Wastepicker: Upload proof of service photos
  /// mobile app should upload files to storage (Cloudinary/S3) first
  Future<Map<String, dynamic>> updateTripPics(String token, String tripId, {
    List<String>? estimationPics,
    List<String>? pickupPics,
    List<String>? dumpsitePics,
  }) async {
    var url = Uri.parse('$baseUrl/trips/$tripId/pics');
    var response = await http.patch(
      url,
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        if (estimationPics != null) 'estimation_pics': estimationPics,
        if (pickupPics != null) 'pickup_pics': pickupPics,
        if (dumpsitePics != null) 'dumpsite_pics': dumpsitePics,
      }),
    );

    if (response.statusCode != 200) {
      throw Exception('Failed to update trip pictures: ${response.body}');
    }
    return jsonDecode(response.body);
  }

  /// Wastepicker: Complete the trip after disposal
  Future<Map<String, dynamic>> completeTrip(String token, String tripId) async {
    var url = Uri.parse('$baseUrl/trips/$tripId/complete');
    var response = await http.post(
      url,
      headers: {'Authorization': 'Bearer $token'},
    );

    if (response.statusCode != 200) {
      throw Exception('Failed to complete trip: ${response.body}');
    }
    return jsonDecode(response.body);
  }

  // ==========================================
  // WEBSOCKETS (REAL-TIME TRACKING)
  // ==========================================

  /// Customer: Track a driver's live location for a trip
  WebSocketChannel trackTrip(String tripId, String token) {
    final wsUrl = Uri.parse('$_wsBaseUrl/api/ws/customer/$tripId?token=$token');
    return WebSocketChannel.connect(wsUrl);
  }

  /// Waste Picker: Publish live location for a trip
  WebSocketChannel publishLocation(String tripId, String token) {
    final wsUrl = Uri.parse('$_wsBaseUrl/api/ws/driver/$tripId?token=$token');
    return WebSocketChannel.connect(wsUrl);
  }

  /// Waste picker: Broadcast location to the WebSocket channel
  void sendLocationUpdate(WebSocketChannel channel, {
    required double lat,
    required double lon,
    double heading = 0,
    double speed = 0,
  }) {
    channel.sink.add(jsonEncode({
      'lat': lat,
      'lon': lon,
      'heading': heading,
      'speed': speed,
    }));
  }
}

// ==========================================
// MODELS
// ==========================================

class AccessCredentials {
  final String accessToken;
  final String tokenType;
  final String role;

  AccessCredentials({
    required this.accessToken,
    required this.tokenType,
    required this.role,
  });
}

class UserProfile {
  final String id;
  final String firstName;
  final String lastName;
  final String phoneNumber;
  final String role;

  UserProfile({
    required this.id,
    required this.firstName,
    required this.lastName,
    required this.phoneNumber,
    required this.role,
  });

  factory UserProfile.fromJson(Map<String, dynamic> json) {
    return UserProfile(
      id: json['id'] ?? '',
      firstName: json['first_name'] ?? '',
      lastName: json['last_name'] ?? '',
      phoneNumber: json['phone_number'] ?? '',
      role: json['customer_type'] ?? 'CUSTOMER',
    );
  }
}
