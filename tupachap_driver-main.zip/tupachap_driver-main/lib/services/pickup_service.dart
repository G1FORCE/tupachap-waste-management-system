import 'package:tupachap_driver/models/models.dart';

class PickupService {
  static final PickupService _instance = PickupService._internal();

  factory PickupService() {
    return _instance;
  }

  PickupService._internal();

  // Simulated data - replace with actual API calls
  Future<List<PickupRequest>> fetchAvailableRequests() async {
    await Future.delayed(const Duration(seconds: 1));
    return [
      PickupRequest(
        id: '1',
        distance: 2.5,
        category: 'Construction Debris',
        volume: '500 cu ft',
        earnings: 1500,
        customerLocation: Location(latitude: 40.7128, longitude: -74.0060),
        customerName: 'John Smith', tripId: null,
      ),
      PickupRequest(
        id: '2',
        distance: 5.2,
        category: 'Residential Waste',
        volume: '300 cu ft',
        earnings: 950,
        customerLocation: Location(latitude: 40.7282, longitude: -73.7949),
        customerName: 'Jane Doe', tripId: null,
      ),
      PickupRequest(
        id: '3',
        distance: 1.8,
        category: 'Yard Waste',
        volume: '200 cu ft',
        earnings: 750,
        customerLocation: Location(latitude: 40.7489, longitude: -73.9680),
        customerName: 'Mike Johnson', tripId: null,
      ),
    ];
  }

  Future<bool> submitPickupPhotos(String tripId, List<String> photoUrls) async {
    await Future.delayed(const Duration(seconds: 2));
    return true;
  }

  Future<bool> submitDisposalPhotos(String tripId, List<String> photoUrls) async {
    await Future.delayed(const Duration(seconds: 2));
    return true;
  }

  Future<bool> completeTrip(String tripId) async {
    await Future.delayed(const Duration(seconds: 1));
    return true;
  }
}
