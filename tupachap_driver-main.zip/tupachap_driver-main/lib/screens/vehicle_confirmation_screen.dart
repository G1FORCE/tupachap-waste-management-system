import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:tupachap_driver/providers/app_provider.dart';
import 'package:tupachap_driver/widgets/common_widgets.dart';
import 'package:tupachap_driver/widgets/logo_header.dart';
import 'package:tupachap_driver/utils/theme.dart';

class VehicleConfirmationScreen extends StatefulWidget {
  const VehicleConfirmationScreen({super.key});

  @override
  State<VehicleConfirmationScreen> createState() =>
      _VehicleConfirmationScreenState();
}

class _VehicleConfirmationScreenState extends State<VehicleConfirmationScreen> {
  String? _selectedVehicle;

  final List<_VehicleOption> vehicles = [
    _VehicleOption(
      id: 'van',
      name: 'Van',
      capacity: '500 cu ft',
      icon: Icons.local_shipping_outlined,
    ),
    _VehicleOption(
      id: 'truck',
      name: 'Truck',
      capacity: '1000 cu ft',
      icon: Icons.local_shipping_outlined,
    ),
    _VehicleOption(
      id: 'dumpster',
      name: 'Dumpster Truck',
      capacity: '2000 cu ft',
      icon: Icons.delete_outline,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.primary,
      body: Column(
        children: [
          const LogoHeader(isDark: true),
          Expanded(
            child: Container(
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(32),
                  topRight: Radius.circular(32),
                ),
              ),
              clipBehavior: Clip.antiAlias,
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 16),
                    Text('Vehicle Selection', style: AppTheme.headingMedium),
                    const SizedBox(height: 8),
                    Text(
                      'Select the vehicle you are using today',
                      style: TextStyle(color: Colors.grey.shade600, fontSize: 16),
                    ),
                    const SizedBox(height: 32),
                    ListView.separated(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: vehicles.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 16),
                      itemBuilder: (context, index) {
                        final vehicle = vehicles[index];
                        final isSelected = _selectedVehicle == vehicle.id;

                        return GestureDetector(
                          onTap: () {
                            setState(() {
                              _selectedVehicle = vehicle.id;
                            });
                          },
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            padding: const EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? AppTheme.primary.withOpacity(0.05)
                                  : Colors.white,
                              border: Border.all(
                                color: isSelected ? AppTheme.primary : Colors.grey.shade200,
                                width: isSelected ? 2 : 1,
                              ),
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: isSelected ? [
                                BoxShadow(
                                  color: AppTheme.primary.withOpacity(0.1),
                                  blurRadius: 10,
                                  offset: const Offset(0, 4),
                                )
                              ] : [],
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 56,
                                  height: 56,
                                  decoration: BoxDecoration(
                                    color: isSelected ? AppTheme.primary : Colors.grey.shade50,
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                  child: Icon(
                                    vehicle.icon,
                                    color: isSelected ? Colors.white : AppTheme.primary,
                                    size: 28,
                                  ),
                                ),
                                const SizedBox(width: 16),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        vehicle.name,
                                        style: const TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        'Capacity: ${vehicle.capacity}',
                                        style: TextStyle(
                                          fontSize: 14,
                                          color: Colors.grey.shade600,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Radio<String>(
                                  value: vehicle.id,
                                  groupValue: _selectedVehicle,
                                  activeColor: AppTheme.primary,
                                  onChanged: (value) {
                                    setState(() {
                                      _selectedVehicle = value;
                                    });
                                  },
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                    const SizedBox(height: 40),
                    PrimaryButton(
                      label: 'Confirm & Start Work',
                      onPressed: _selectedVehicle != null
                          ? () {

                            }
                          : () {},
                      disabled: _selectedVehicle == null,
                    ),
                    const SizedBox(height: 32),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _VehicleOption {
  final String id;
  final String name;
  final String capacity;
  final IconData icon;

  _VehicleOption({
    required this.id,
    required this.name,
    required this.capacity,
    required this.icon,
  });
}
