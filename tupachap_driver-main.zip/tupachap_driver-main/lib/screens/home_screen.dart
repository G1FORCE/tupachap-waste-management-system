import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:tupachap_driver/providers/app_provider.dart';
import 'package:tupachap_driver/widgets/common_widgets.dart';
import 'package:tupachap_driver/widgets/logo_header.dart';
import 'package:tupachap_driver/utils/theme.dart';
import 'package:tupachap_driver/models/models.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<void> _loadDataFuture;

  @override
  void initState() {
    super.initState();
    _loadDataFuture = _loadData();
  }

  Future<void> _loadData() async {
    await context.read<AppProvider>().refreshAvailableTrips();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.primary,
      body: Consumer<AppProvider>(
        builder: (context, provider, _) {
          return Column(
            children: [
              const LogoHeader(isDark: true),
              Expanded(
                child: Container(
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: RefreshIndicator(
                    onRefresh: () => provider.refreshAvailableTrips(),
                    child: SingleChildScrollView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Stats Overview
                          Row(
                            children: [
                              Expanded(
                                child: _StatCard(
                                  label: 'Total Earnings',
                                  value: 'Tsh ${provider.userProfile?.totalEarnings ?? 0}',
                                  icon: Icons.account_balance_wallet_outlined,
                                  color: AppTheme.primary,
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: _StatCard(
                                  label: 'Trips Done',
                                  value: '${provider.userProfile?.tripCount ?? 0}',
                                  icon: Icons.local_shipping_outlined,
                                  color: AppTheme.primaryDark,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 32),

                          // Assigned Jobs Section
                          if (provider.assignedRequests.isNotEmpty) ...[
                            Row(
                              children: [
                                const Icon(Icons.assignment_turned_in, color: AppTheme.primary, size: 20),
                                const SizedBox(width: 8),
                                Text('My Assigned Jobs', style: AppTheme.headingSmall),
                              ],
                            ),
                            const SizedBox(height: 16),
                            ...provider.assignedRequests.map((request) {
                              final isInTransit = request.status == 'IN_TRANSIT';
                              return Padding(
                                padding: const EdgeInsets.only(bottom: 16),
                                child: RequestCard(
                                  distance: '${request.distance} km',
                                  category: request.category,
                                  volume: request.volume,
                                  earnings: request.earnings.toString(),
                                  customerName: request.customerName,
                                  label: isInTransit ? 'Go to Dumpsite' : 'Start Navigation',
                                  color: isInTransit ? Colors.orange : AppTheme.primary,
                                  onAccept: () {
                                    provider.setCurrentRequest(request);
                                    provider.setAppState(
                                      isInTransit 
                                          ? AppState.navigationToDumpsite 
                                          : AppState.navigationToCustomer
                                    );
                                  },
                                ),
                              );
                            }).toList(),
                            const Divider(height: 40),
                          ],

                          // Available Requests Section
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  const Icon(Icons.search, color: AppTheme.textSecondary, size: 20),
                                  const SizedBox(width: 8),
                                  Text('Available Requests', style: AppTheme.headingSmall),
                                ],
                              ),
                              IconButton(
                                icon: const Icon(Icons.refresh, size: 20, color: AppTheme.primary),
                                onPressed: () => provider.refreshAvailableTrips(),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),
                          
                          if (provider.availableRequests.isEmpty)
                            Center(
                              child: Padding(
                                padding: const EdgeInsets.symmetric(vertical: 40),
                                child: Column(
                                  children: [
                                    Icon(Icons.assignment_outlined, size: 48, color: Colors.grey.shade200),
                                    const SizedBox(height: 12),
                                    Text(
                                      'No new requests in your area',
                                      style: AppTheme.bodyMedium.copyWith(color: AppTheme.textSecondary),
                                    ),
                                  ],
                                ),
                              ),
                            )
                          else
                            ...provider.availableRequests.map((request) => Padding(
                              padding: const EdgeInsets.only(bottom: 16),
                              child: RequestCard(
                                distance: '${request.distance} km',
                                category: request.category,
                                volume: request.volume,
                                earnings: request.earnings.toString(),
                                customerName: request.customerName,
                                onAccept: () => provider.acceptRequest(request),
                              ),
                            )).toList(),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;

  const _StatCard({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.05),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(height: 12),
          Text(label, style: AppTheme.bodySmall),
          const SizedBox(height: 4),
          Text(
            value, 
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: AppTheme.textPrimary,
            ),
          ),
        ],
      ),
    );
  }
}
