import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:tupachap_driver/providers/app_provider.dart';
import 'package:tupachap_driver/widgets/common_widgets.dart';
import 'package:tupachap_driver/widgets/logo_header.dart';
import 'package:tupachap_driver/utils/theme.dart';

class TripCompleteScreen extends StatefulWidget {
  const TripCompleteScreen({super.key});

  @override
  State<TripCompleteScreen> createState() => _TripCompleteScreenState();
}

class _TripCompleteScreenState extends State<TripCompleteScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  bool _isSubmitting = false;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _handleContinue(bool isFinal) async {
    final provider = context.read<AppProvider>();
    if (isFinal) {
      setState(() => _isSubmitting = true);
      try {
        await provider.completeTrip();
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error: $e')),
          );
        }
      } finally {
        if (mounted) setState(() => _isSubmitting = false);
      }
    } else {
      // After QR Scan completion, move to photo capture
      provider.setAppState(AppState.photoPickup);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.primary,
      body: Consumer<AppProvider>(
        builder: (context, provider, _) {
          final request = provider.currentRequest;
          final isFinal = provider.isFinalCompletion;
          final earnings = request?.earnings ?? 0;

          return Column(
            children: [
              const LogoHeader(isDark: true),
              Expanded(
                child: Container(
                  width: double.infinity,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      children: [
                        const SizedBox(height: 24),
                        ScaleTransition(
                          scale: Tween<double>(begin: 0, end: 1).animate(
                            CurvedAnimation(
                              parent: _animationController,
                              curve: Curves.elasticOut,
                            ),
                          ),
                          child: Container(
                            width: 100,
                            height: 100,
                            decoration: BoxDecoration(
                              color: AppTheme.primary.withOpacity(0.1),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.check_circle,
                              size: 64,
                              color: AppTheme.primary,
                            ),
                          ),
                        ),
                        const SizedBox(height: 32),
                        Text(
                          isFinal ? 'Trip Finished!' : 'Pickup Verified!',
                          style: AppTheme.headingMedium,
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 12),
                        Text(
                          isFinal 
                              ? 'Great job completing this pickup request.'
                              : 'The customer QR has been verified successfully.',
                          style: AppTheme.bodyMedium
                              .copyWith(color: AppTheme.textSecondary),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 40),
                        if (isFinal) ...[
                          Container(
                            padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
                            decoration: BoxDecoration(
                              color: AppTheme.primary.withOpacity(0.05),
                              borderRadius: BorderRadius.circular(24),
                              border: Border.all(color: AppTheme.primary.withOpacity(0.1)),
                            ),
                            child: Column(
                              children: [
                                Text('You earned', style: AppTheme.bodySmall),
                                const SizedBox(height: 8),
                                Text(
                                  'Tsh $earnings',
                                  style: const TextStyle(
                                    fontSize: 32,
                                    fontWeight: FontWeight.w900,
                                    color: AppTheme.primary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 32),
                          _SummaryRow(
                            icon: Icons.local_shipping_outlined,
                            label: 'Category',
                            value: request?.category ?? 'N/A',
                          ),
                          const SizedBox(height: 12),
                        ],
                        const SizedBox(height: 48),
                        PrimaryButton(
                          label: isFinal ? 'Back to Home' : 'Capture Pickup Photos',
                          onPressed: () => _handleContinue(isFinal),
                          isLoading: _isSubmitting,
                        ),
                        const SizedBox(height: 24),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _SummaryRow({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade100),
      ),
      child: Row(
        children: [
          Icon(icon, color: AppTheme.primary, size: 24),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: AppTheme.bodySmall),
                const SizedBox(height: 2),
                Text(value, style: AppTheme.labelLarge),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
