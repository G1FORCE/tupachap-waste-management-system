import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:tupachap_driver/utils/theme.dart';
import '../providers/app_provider.dart';
import 'package:provider/provider.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  final _storage = const FlutterSecureStorage();

  @override
  void initState() {
    super.initState();
    _checkLoginStatus();
  }

  Future<void> _checkLoginStatus() async {
    await Future.delayed(const Duration(seconds: 2));
    if (mounted) {
      // The AppProvider handles navigation logic based on token and active trips
      await context.read<AppProvider>().loadProfileFromToken();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.primary,
      body: Center(
        child: TweenAnimationBuilder(
          duration: const Duration(seconds: 1),
          tween: Tween<double>(begin: 0.8, end: 1.0),
          builder: (context, double value, child) {
            return Transform.scale(
              scale: value,
              child: SvgPicture.asset(
                'assets/images/brand_logo.svg',
                width: 200,
              ),
            );
          },
        ),
      ),
    );
  }
}
