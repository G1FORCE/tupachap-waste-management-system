import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:tupachap_driver/providers/app_provider.dart';
import 'package:tupachap_driver/widgets/common_widgets.dart';
import 'package:tupachap_driver/widgets/logo_header.dart';
import 'package:tupachap_driver/utils/theme.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:io';

class PhotoCaptureScreen extends StatefulWidget {
  final bool isPickupPhoto;

  const PhotoCaptureScreen({
    Key? key,
    this.isPickupPhoto = true,
  }) : super(key: key);

  @override
  State<PhotoCaptureScreen> createState() => _PhotoCaptureScreenState();
}

class _PhotoCaptureScreenState extends State<PhotoCaptureScreen> {
  final ImagePicker _imagePicker = ImagePicker();
  final List<File> _capturedPhotos = [];
  bool _isSubmitting = false;

  Future<void> _addPhoto() async {
    try {
      final XFile? pickedFile = await _imagePicker.pickImage(
        source: ImageSource.camera,
        imageQuality: 80,
      );

      if (pickedFile != null) {
        setState(() {
          _capturedPhotos.add(File(pickedFile.path));
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error capturing photo: $e')),
        );
      }
    }
  }

  void _removePhoto(int index) {
    setState(() {
      _capturedPhotos.removeAt(index);
    });
  }

  Future<String?> _uploadPhotoToFirebase(File photoFile, String fileName) async {
    try {
      final Reference storageRef = FirebaseStorage.instance
          .ref()
          .child('trip_photos')
          .child(fileName);

      final UploadTask uploadTask = storageRef.putFile(photoFile);
      final TaskSnapshot taskSnapshot = await uploadTask;
      final String downloadUrl = await taskSnapshot.ref.getDownloadURL();
      return downloadUrl;
    } catch (e) {
      debugPrint('Error uploading photo: $e');
      return null;
    }
  }

  Future<void> _submitPhotos() async {
    if (_capturedPhotos.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please capture at least one photo')),
      );
      return;
    }

    setState(() => _isSubmitting = true);

    try {
      final appProvider = context.read<AppProvider>();
      
      List<String> uploadedUrls = [];
      for (int i = 0; i < _capturedPhotos.length; i++) {
        final fileName = '${DateTime.now().millisecondsSinceEpoch}_photo_$i.jpg';
        final downloadUrl = await _uploadPhotoToFirebase(
          _capturedPhotos[i],
          fileName,
        );

        if (downloadUrl != null) {
          uploadedUrls.add(fileName);
        }
      }

      if (uploadedUrls.isEmpty) {
        throw Exception('Failed to upload any photos');
      }

      if (widget.isPickupPhoto) {
        await appProvider.uploadTripPhotos(pickupPics: uploadedUrls);
        if (mounted) {
          appProvider.photoPickupComplete();
        }
      } else {
        await appProvider.uploadTripPhotos(dumpsitePics: uploadedUrls);
        if (mounted) {
          appProvider.photoDisposalComplete();
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error submitting photos: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isSubmitting = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.primary,
      body: Column(
        children: [
          const LogoHeader(isDark: true),
          Expanded(
            child: Container(
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(32),
                  topRight: Radius.circular(32),
                ),
              ),
              clipBehavior: Clip.antiAlias,
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(24, 24, 24, 8),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.isPickupPhoto ? 'Pickup Photos' : 'Disposal Photos',
                          style: AppTheme.headingMedium,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          widget.isPickupPhoto
                              ? 'Take photos of the items being picked up'
                              : 'Take photos of the disposed items',
                          style: AppTheme.bodyMedium.copyWith(color: AppTheme.textSecondary),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: _capturedPhotos.isEmpty
                        ? Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.camera_alt_outlined,
                                  size: 80,
                                  color: AppTheme.primary.withOpacity(0.1),
                                ),
                                const SizedBox(height: 16),
                                Text(
                                  'No photos yet',
                                  style: AppTheme.bodyMedium
                                      .copyWith(color: AppTheme.textSecondary),
                                ),
                              ],
                            ),
                          )
                        : GridView.builder(
                            padding: const EdgeInsets.all(24),
                            gridDelegate:
                                const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2,
                              crossAxisSpacing: 16,
                              mainAxisSpacing: 16,
                            ),
                            itemCount: _capturedPhotos.length,
                            itemBuilder: (context, index) {
                              return Stack(
                                children: [
                                  Container(
                                    width: double.infinity,
                                    decoration: BoxDecoration(
                                      color: Colors.grey.shade50,
                                      borderRadius: BorderRadius.circular(16),
                                      border: Border.all(color: Colors.grey.shade100),
                                    ),
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(16),
                                      child: Image.file(
                                        _capturedPhotos[index],
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    top: 8,
                                    right: 8,
                                    child: GestureDetector(
                                      onTap: () => _removePhoto(index),
                                      child: Container(
                                        decoration: const BoxDecoration(
                                          color: AppTheme.error,
                                          shape: BoxShape.circle,
                                        ),
                                        padding: const EdgeInsets.all(4),
                                        child: const Icon(
                                          Icons.close,
                                          color: Colors.white,
                                          size: 16,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              );
                            },
                          ),
                  ),
                  Container(
                    padding: const EdgeInsets.fromLTRB(24, 24, 24, 32),
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black12,
                          blurRadius: 20,
                          offset: Offset(0, -5),
                        ),
                      ],
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SecondaryButton(
                          label: 'Add Photo',
                          onPressed: _addPhoto,
                        ),
                        const SizedBox(height: 16),
                        PrimaryButton(
                          label: 'Submit Photos',
                          onPressed: _submitPhotos,
                          isLoading: _isSubmitting,
                          disabled: _capturedPhotos.isEmpty,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
