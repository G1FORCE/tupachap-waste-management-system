import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';
import 'package:provider/provider.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import '../providers/tracking_provider.dart';
import '../providers/app_provider.dart';
import '../utils/theme.dart';
import '../widgets/common_widgets.dart';
import 'qr_scanner_screen.dart';

class TripTrackingScreen extends StatefulWidget {
  final String tripId;
  final String token;
  final String userType;
  final String collectorId;
  final String origin;
  final dynamic destination;
  final dynamic accessCredentials;

  const TripTrackingScreen({
    Key? key,
    required this.tripId,
    required this.token,
    required this.userType,
    required this.collectorId,
    required this.origin,
    required this.destination,
    this.accessCredentials,
  }) : super(key: key);

  @override
  State<TripTrackingScreen> createState() => _TripTrackingScreenState();
}

class _TripTrackingScreenState extends State<TripTrackingScreen> {
  late GoogleMapController _mapController;
  final Location _locationService = Location();
  Set<Polyline> _polylines = {};
  Set<Marker> _markers = {};
  LatLng? _currentCollectorLocation;
  bool _isTrackingEnabled = true;
  bool _arrivedAtDestination = false;
  bool _isVerifying = false;
  
  // Replace with your actual Google Maps API Key
  final String _googleApiKey = "AIzaSyBKBwJqkGFPbM9hrwoehpVPXWXdLvH4oZA";

  @override
  void initState() {
    super.initState();
    _initializeTracking();
  }

  Future<void> _initializeTracking() async {
    final trackingProvider = context.read<TrackingProvider>();

    bool hasPermission = await _locationService.hasPermission() != PermissionStatus.denied;
    if (!hasPermission) {
      await _locationService.requestPermission();
    }

    LocationData? initialLoc;
    String startLocationStr = widget.origin;
    if (await _locationService.hasPermission() != PermissionStatus.denied) {
      try {
        initialLoc = await _locationService.getLocation();
        if (initialLoc.latitude != null && initialLoc.longitude != null) {
          startLocationStr = '${initialLoc.latitude},${initialLoc.longitude}';
          if (mounted) {
            setState(() {
              _currentCollectorLocation = LatLng(initialLoc!.latitude!, initialLoc!.longitude!);
            });
            // Fetch directions once initial location is known
            _getPolyline(initialLoc.latitude!, initialLoc.longitude!);
          }
        }
      } catch (e) {
        debugPrint('Error getting start location: $e');
      }
    }
    
    await trackingProvider.initiateTripTracking(
      tripId: widget.tripId,
      token: widget.token,
      userType: widget.userType,
      origin: startLocationStr,
      destination: widget.destination,
      accessCredentials: widget.accessCredentials,
    );

    // Send initial location update to WebSocket room immediately after connection
    if (initialLoc != null && initialLoc.latitude != null && initialLoc.longitude != null) {
      trackingProvider.broadcastCollectorLocation(
        latitude: initialLoc.latitude!,
        longitude: initialLoc.longitude!,
        accuracy: initialLoc.accuracy,
        heading: initialLoc.heading,
      );
    }
  }

  Future<void> _getPolyline(double startLat, double startLng) async {
    PolylinePoints polylinePoints = PolylinePoints();
    
    try {
      PolylineResult result = await polylinePoints.getRouteBetweenCoordinates(
        googleApiKey: _googleApiKey,
        request: PolylineRequest(
          origin: PointLatLng(startLat, startLng),
          destination: PointLatLng(widget.destination.latitude, widget.destination.longitude),
          mode: TravelMode.driving,
        ),
      );

      if (result.points.isNotEmpty) {
        List<LatLng> polylineCoordinates = result.points
            .map((point) => LatLng(point.latitude, point.longitude))
            .toList();

        setState(() {
          _polylines.add(
            Polyline(
              polylineId: const PolylineId("route"),
              color: AppTheme.primary,
              points: polylineCoordinates,
              width: 5,
            ),
          );
        });
      }
    } catch (e) {
      debugPrint("Error fetching polylines: $e");
    }
  }

  Future<void> _requestLocationAndStartTracking() async {
    bool hasPermission = await _locationService.hasPermission() != PermissionStatus.denied;
    if (!hasPermission) await _locationService.requestPermission();

    _locationService.onLocationChanged.listen((LocationData locationData) {
      if (_isTrackingEnabled && mounted) {
        _handleLocationUpdate(locationData);
      }
    });
  }

  void _handleLocationUpdate(LocationData locationData) {
    if (locationData.latitude == null || locationData.longitude == null) return;
    
    final newLocation = LatLng(locationData.latitude!, locationData.longitude!);
    _currentCollectorLocation = newLocation;
    final customerLocation = LatLng(widget.destination.latitude!, widget.destination.longitude!);
    
    _mapController.animateCamera(CameraUpdate.newLatLng(newLocation));
    _updateMarker(customerLocation);

    // Keep broadcasting location as long as we're on this screen
    context.read<TrackingProvider>().broadcastCollectorLocation(
      latitude: locationData.latitude!,
      longitude: locationData.longitude!,
      accuracy: locationData.accuracy,
      heading: locationData.heading,
    );
  }

  void _updateMarker(LatLng location) {
    setState(() {
      _markers = {
        Marker(
          markerId: const MarkerId('customer_location'),
          position: location,
          infoWindow: const InfoWindow(
            title: 'Customer Location',
            snippet: 'Destination',
          ),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
        ),
      };
    });
  }

  void _handleQRScan() async {
    final String? result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const QRScannerScreen()),
    );

    if (result != null) {
      setState(() => _isVerifying = true);
      try {
        await context.read<AppProvider>().startTrip(result);
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('QR Verification failed: $e')),
          );
        }
      } finally {
        if (mounted) setState(() => _isVerifying = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<AppProvider>();
    final isPickup = provider.appState == AppState.navigationToCustomer;

    return Scaffold(
      appBar: AppBar(
        title: Text(isPickup ? 'Heading to Customer' : 'Heading to Dumpsite'),
        backgroundColor: AppTheme.primary,
      ),
      body: Stack(
        children: [
          GoogleMap(
            style: _mapStyle,
            initialCameraPosition: CameraPosition(
              target: _currentCollectorLocation ?? const LatLng(-6.7924, 39.2083),
              zoom: 15,
            ),
            onMapCreated: (controller) {
              _mapController = controller;
              _requestLocationAndStartTracking();
            },
            markers: _markers,
            polylines: _polylines,
            myLocationEnabled: true,
          ),
          Positioned(
            bottom: 0, left: 0, right: 0,
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(topLeft: Radius.circular(32), topRight: Radius.circular(32)),
                boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 20)],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (!_arrivedAtDestination)
                    PrimaryButton(
                      label: 'I Have Arrived',
                      onPressed: () => setState(() => _arrivedAtDestination = true),
                    )
                  else
                    Column(
                      children: [
                        Text(
                          isPickup ? 'Please scan the customer\'s QR code to verify the pickup.' : 'Confirm arrival at the disposal site.',
                          textAlign: TextAlign.center,
                          style: AppTheme.bodyMedium,
                        ),
                        const SizedBox(height: 16),
                        PrimaryButton(
                          label: isPickup ? 'Verify QR Code' : 'Proceed to Photos',
                          isLoading: _isVerifying,
                          onPressed: isPickup ? _handleQRScan : () => provider.arrivedAtDumpsite(),
                        ),
                      ],
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

final String _mapStyle =  """
[
  {
    "elementType": "geometry",
    "stylers": [{ "color": "#ffffff" }]
  },
  {
    "featureType": "landscape",
    "elementType": "geometry",
    "stylers": [{ "color": "#f7f9f7" }]
  },
  {
    "featureType": "poi.park",
    "elementType": "geometry",
    "stylers": [{ "color": "#c8e6c9" }]
  },
  {
    "featureType": "road",
    "elementType": "geometry",
    "stylers": [{ "color": "#a9c4aa" }]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry",
    "stylers": [{ "color": "#a5d6a7" }]
  },
  {
    "featureType": "water",
    "elementType": "geometry",
    "stylers": [{ "color": "#e8f5e9" }]
  },
]
""";
