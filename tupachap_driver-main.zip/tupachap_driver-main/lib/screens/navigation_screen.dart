import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import 'package:tupachap_driver/providers/app_provider.dart';
import 'package:tupachap_driver/widgets/common_widgets.dart';
import 'package:tupachap_driver/widgets/logo_header.dart';
import 'package:tupachap_driver/utils/theme.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';

class NavigationScreen extends StatefulWidget {
  final bool isToCustomer;

  const NavigationScreen({
    super.key,
    this.isToCustomer = true,
  });

  @override
  State<NavigationScreen> createState() => _NavigationScreenState();
}

class _NavigationScreenState extends State<NavigationScreen> {
  bool _arrivedAtDestination = false;
  late GoogleMapController mapController;
  final Set<Polyline> _polylines = {};

  // Your encoded polyline string from Google Maps API
  final String encodedPolylineString = "`smh@_{hnFh@gC\\iCViBb@yAdAwCf@_BpAcD\\m@n@wAZ_AZsAfAwEh@yDp@eG`@aCn@yEkBWSFEB?BA@C@C@IACGBIBA@?J]Lm@Hm@BGDCJAVBfC^WzA[dCvAHdC`@lEh@rCb@k@bBgAdD_@hA?JDH`@Pt@HRBbB^h@LbAJbBKb@@RDNH^]VT|@bA|BxBnBfBv@h@z@d@zDvAjA`@f@Lt@ClBKj@ANDTNtAeBdBcBtAcAtAy@`Ae@`Aa@tEsAnJsCvAc@~B_Ar@]nBmAnCcC|@eAxAuBpEeIpA{BpA_ClCoE~DqHhCsEdAgBjBeCf@k@lFkF`E_EdK}Jz]m]vCwC`K}JdDeDfBuAnEaC`KmFvBeA|HcEpDkB~@m@`FiChDcBjBi@fC[lBi@fDkA~H{CzBiAdBgAnB{ApAoAn@s@pBmCzAcCdB{Dp@_B^mAb@sBHy@@{@IaAYuA]aAiBuEgDeImAkDg@cCIs@Cw@@eALuAXyAd@oAh@aAvAqBhIwJlG{HfE_FnAyAzAqBzCoDhCeD~E{FfAoA|@mAn@mAb@wAV}ABiAAwBSkJSgFOsF@eCD}@^yCReAZoA`@sAjB{G\\oBP{AH_BJ{@Ha@T{@Vu@f@_Ar@sAl@sATy@Lw@H{@@_ACi@Is@WoAMa@c@w@_AmAmBqBe@k@Ma@IS_AyAS]o@u@YYo@k@a@[M]EU?QHYLMLEXI\\Ah@?nAJp@Bj@ITIVQLO`@u@GyBGo@Ou@WcAQ{@Gq@AgABa@PqAh@{CT}AL{AJcDDaBf@aRZyKDyAAaCO}ECuB?iEHiFKiA[qAISa@mAMS]a@m@e@i@]aAc@sA]_@GkCe@uASoDm@iEo@QCcC]aDOoAYa@YYY_@k@Yi@yAmBg@m@]_@o@i@aGaGcBcB}B{BkEmD}HiHkFcFkByAqA}@U]I?SCGEqA@yCMcBVgEl@c@FcAR{@ViAf@UNg@f@u@x@SRaAv@{AbAoDrBsAfAQTkA`C_@x@{@xA_ChDgCdCy@y@{@sAm@m@_BqA}@q@eC_BcBoAgAy@i@]mDiC{H}FoBuAkCNJlCuBFN`DD|@";
  static const LatLng _center = LatLng(-6.7924, 39.2083);
  final Set<Marker> _markers = {};

  @override
  void initState() {
    super.initState();
    _addTruckMarkers();
    _convertStringToPolyline();
  }

  void _convertStringToPolyline() {
    // 1. Initialize the decoder
    PolylinePoints polylinePoints = PolylinePoints();

    // 2. Decode the string into a list of PointLatLng
    List<PointLatLng> decodedPoints = polylinePoints.decodePolyline(encodedPolylineString);

    // 3. Convert PointLatLng to LatLng format required by google_maps_flutter
    List<LatLng> polylineCoordinates = decodedPoints
        .map((point) => LatLng(point.latitude, point.longitude))
        .toList();

    // 4. Create the Polyline object and add it to your state set
    setState(() {
      _polylines.add(
        Polyline(
          polylineId: PolylineId('route_path'),
          visible: true,
          points: polylineCoordinates,
          color: Color(0xFF00AA08),
          width: 5,
        ),
      );
    });
  }

  void _addTruckMarkers() {
    setState(() {
      _markers.add(
        Marker(
          markerId: const MarkerId('truck1'),
          position: const LatLng(-6.7950, 39.2150),
          infoWindow: const InfoWindow(title: 'TupaChap Truck #102', snippet: 'Available'),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
        ),
      );
      _markers.add(
        Marker(
          markerId: const MarkerId('truck2'),
          position: const LatLng(-6.7924, 39.2083),
          infoWindow: const InfoWindow(title: 'TupaChap Truck #089', snippet: 'En route'),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
        ),
      );
      _markers.add(
        Marker(
          markerId: const MarkerId('truck3'),
          position: const LatLng(-6.7980, 39.2050),
          infoWindow: const InfoWindow(title: 'TupaChap Truck #114', snippet: 'Available'),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
        ),
      );
    });
  }

  void _onMapCreated(GoogleMapController controller) {
    mapController = controller;
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.primary,
      body: Consumer<AppProvider>(
        builder: (context, provider, _) {
          final request = provider.currentRequest;
          if (request == null) {
            return const Center(child: Text('No request data', style: TextStyle(color: Colors.white)));
          }

          return Column(
            children: [
              const LogoHeader(isDark: true),
              Expanded(
                child: Container(
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Stack(
                    children: [
                      // Map Placeholder
                      Container(
                        width: double.infinity,
                        color: AppTheme.divider,
                        child: GoogleMap(
                          polylines: _polylines,
                          padding: const EdgeInsets.only(top: 90, bottom: 190),
                          style: _mapStyle,
                          onMapCreated: _onMapCreated,
                          initialCameraPosition: const CameraPosition(
                            target: _center,
                            zoom: 14.5,
                          ),
                          markers: _markers,
                          myLocationEnabled: true,
                          myLocationButtonEnabled: true,
                          mapType: MapType.normal,
                          zoomControlsEnabled: false,
                          mapToolbarEnabled: false,
                          compassEnabled: false,
                        ),
                      ),
                      
                      // Top Overlay Info
                      Positioned(
                        top: 24,
                        left: 20,
                        right: 20,
                        child: Container(
                          padding: const EdgeInsets.all(16),
                          decoration: AppTheme.cardDecoration.copyWith(
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.location_on, color: AppTheme.primary),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      widget.isToCustomer ? 'Pickup Location' : 'Disposal Point',
                                      style: AppTheme.bodySmall,
                                    ),
                                    Text(
                                      widget.isToCustomer ? request.customerName : 'City Central Dumpsite',
                                      style: AppTheme.labelLarge,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      // Bottom Panel
                      Positioned(
                        bottom: 0,
                        left: 0,
                        right: 0,
                        child: Container(
                          padding: const EdgeInsets.fromLTRB(24, 24, 24, 32),
                          decoration: const BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(32),
                              topRight: Radius.circular(32),
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black12,
                                blurRadius: 20,
                                offset: Offset(0, -5),
                              ),
                            ],
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (!_arrivedAtDestination) ...[
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text('Estimated Time', style: AppTheme.bodySmall),
                                        Text('~${(request.distance * 2).toStringAsFixed(0)} mins',
                                            style: AppTheme.headingSmall),
                                      ],
                                    ),
                                    Text('${request.distance} km', style: AppTheme.bodyLarge),
                                  ],
                                ),
                                const SizedBox(height: 24),
                                PrimaryButton(
                                  label: 'I Have Arrived',
                                  onPressed: () {
                                    setState(() {
                                      _arrivedAtDestination = true;
                                    });
                                  },
                                ),
                              ] else ...[
                                Container(
                                  padding: const EdgeInsets.all(16),
                                  decoration: BoxDecoration(
                                    color: AppTheme.primary.withOpacity(0.05),
                                    borderRadius: BorderRadius.circular(16),
                                    border: Border.all(color: AppTheme.primary.withOpacity(0.1)),
                                  ),
                                  child: Row(
                                    children: [
                                      const Icon(Icons.check_circle, color: AppTheme.primary),
                                      const SizedBox(width: 12),
                                      Expanded(
                                        child: Text(
                                          widget.isToCustomer
                                              ? 'Arrived at pickup. Please take photos of the items.'
                                              : 'Arrived at dumpsite. Please take disposal photos.',
                                          style: AppTheme.bodyMedium,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(height: 24),
                                PrimaryButton(
                                  label: 'Proceed to Photos',
                                  onPressed: () {
                                    if (widget.isToCustomer) {
                                      provider.arrivedAtCustomer();
                                    } else {
                                      provider.arrivedAtDumpsite();
                                    }
                                  },
                                ),
                              ],
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

final String _mapStyle =  """
[
  {
    "elementType": "geometry",
    "stylers": [{ "color": "#ffffff" }]
  },
  {
    "featureType": "landscape",
    "elementType": "geometry",
    "stylers": [{ "color": "#f7f9f7" }]
  },
  {
    "featureType": "poi.park",
    "elementType": "geometry",
    "stylers": [{ "color": "#c8e6c9" }]
  },
  {
    "featureType": "road",
    "elementType": "geometry",
    "stylers": [{ "color": "#a9c4aa" }]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry",
    "stylers": [{ "color": "#a5d6a7" }]
  },
  {
    "featureType": "water",
    "elementType": "geometry",
    "stylers": [{ "color": "#e8f5e9" }]
  },
]
""";
