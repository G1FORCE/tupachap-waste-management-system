import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:tupachap_driver/providers/app_provider.dart';
import 'package:tupachap_driver/providers/tracking_provider.dart';
import 'package:tupachap_driver/screens/login_screen.dart';
import 'package:tupachap_driver/screens/splash_screen.dart';
import 'package:tupachap_driver/screens/home_screen.dart';
import 'package:tupachap_driver/screens/navigation_screen.dart';
import 'package:tupachap_driver/screens/photo_capture_screen.dart';
import 'package:tupachap_driver/screens/trip_complete_screen.dart';
import 'package:tupachap_driver/screens/trip_tracking_screen.dart';
import 'package:tupachap_driver/utils/theme.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppProvider()),
        ChangeNotifierProvider(create: (_) => TrackingProvider()),
      ],
      child: MaterialApp(
        title: 'TupaChap Driver',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(
            seedColor: AppTheme.primary,
            brightness: Brightness.light,
          ),
          scaffoldBackgroundColor: AppTheme.background,
          appBarTheme: const AppBarThemeData(
            backgroundColor: AppTheme.primary,
            foregroundColor: Colors.white,
            elevation: 0,
            centerTitle: true,
          ),
          fontFamily: 'Roboto',
        ),
        home: const AppNavigator(),
      ),
    );
  }
}

class AppNavigator extends StatelessWidget {
  const AppNavigator({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<AppProvider>(
      builder: (context, provider, _) {
        return Scaffold(body: _buildScreen(context, provider));
      },
    );
  }

  Widget _buildScreen(BuildContext context, AppProvider provider) {
    switch (provider.appState) {
      case AppState.splashScreen:
        return const SplashScreen();
      case AppState.login:
        return const LoginScreen();
      case AppState.home:
        return const HomeScreen();
      case AppState.navigationToCustomer:
        final request = provider.currentRequest;
        final credentials = provider.credentials;
        final userProfile = provider.userProfile;
        final tripId = provider.currentTripId ?? request?.id;

        if (request != null && credentials != null && userProfile != null && tripId != null) {
          return TripTrackingScreen(
            tripId: tripId,
            token: credentials.accessToken,
            userType: 'driver',
            collectorId: userProfile.id,
            origin: '-6.7924,39.2083', 
            destination: request.customerLocation,
            accessCredentials: credentials,
          );
        }
        return const NavigationScreen(isToCustomer: true);
      case AppState.photoPickup:
        return const PhotoCaptureScreen(isPickupPhoto: true);
      case AppState.navigationToDumpsite:
        final request = provider.currentRequest;
        final credentials = provider.credentials;
        final userProfile = provider.userProfile;
        final tripId = provider.currentTripId ?? request?.id;

        if (request != null && credentials != null && userProfile != null && tripId != null) {
          return TripTrackingScreen(
            tripId: tripId,
            token: credentials.accessToken,
            userType: 'driver',
            collectorId: userProfile.id,
            origin: '${request.customerLocation.latitude},${request.customerLocation.longitude}',
            destination: '-6.7980,39.2050',
            accessCredentials: credentials,
          );
        }
        return const NavigationScreen(isToCustomer: false);
      case AppState.photoDisposal:
        return const PhotoCaptureScreen(isPickupPhoto: false);
      case AppState.tripComplete:
        return const TripCompleteScreen();
      default:
        return const SplashScreen();
    }
  }
}
