class PickupRequest {
  final String id;
  final double distance;
  final String category;
  final String volume;
  final int earnings;
  final Location customerLocation;
  final String customerName;
  final String? tripId;
  final String status;

  PickupRequest({
    required this.id,
    required this.distance,
    required this.category,
    required this.volume,
    required this.earnings,
    required this.customerLocation,
    required this.customerName,
    this.tripId,
    this.status = 'REQUESTED',
  });

  factory PickupRequest.fromJson(Map<String, dynamic> json) {
    // Mapping new API fields to existing model if possible
    // The new API returns dynamic data for trips. 
    // Usually these have 'id', 'status', 'total_price' (earnings), etc.

    return PickupRequest(
      id: json['id']?.toString() ?? '',
      distance: (json['distance'] ?? 0).toDouble(),
      category: json['waste_class'][0] ?? json['category'] ?? 'General',
      volume: json['volume'] ?? 'Standard',
      earnings: (json['base_fare_tzs'] ?? json['earnings'] ?? 0).toInt(),
      customerLocation: Location.fromJson(json['pickup_location'] ?? json['customerLocation'] ?? {}),
      customerName: json['customer_name'] ?? json['customerName'] ?? 'Customer',
      tripId: json['id']?.toString(),
      status: json['status'] ?? 'REQUESTED',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'distance': distance,
      'category': category,
      'volume': volume,
      'earnings': earnings,
      'customerLocation': customerLocation.toJson(),
      'customerName': customerName,
      'status': status,
    };
  }
}

class Location {
  final double latitude;
  final double longitude;

  Location({
    required this.latitude,
    required this.longitude,
  });

  factory Location.fromJson(Map<String, dynamic> json) {
    return Location(
      latitude: (json['coordinates'][1] ?? json['latitude'] ?? 0).toDouble(),
      longitude: (json['coordinates'][0] ?? json['longitude'] ?? 0).toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'lat': latitude,
      'lng': longitude,
    };
  }
}

class UserProfile {
  final String id;
  final String firstName;
  final String lastName;
  final String phoneNumber;
  final String role;
  final int totalEarnings;
  final int tripCount;

  String get name => '$firstName $lastName';

  UserProfile({
    required this.id,
    required this.firstName,
    required this.lastName,
    required this.phoneNumber,
    required this.role,
    this.totalEarnings = 0,
    this.tripCount = 0,
  });

  factory UserProfile.fromJson(Map<String, dynamic> json) {
    return UserProfile(
      id: json['id'] ?? '',
      firstName: json['first_name'] ?? '',
      lastName: json['last_name'] ?? '',
      phoneNumber: json['phone_number'] ?? '',
      role: json['role'] ?? json['customer_type'] ?? 'WASTEPICKER',
      totalEarnings: json['total_earnings'] ?? 0,
      tripCount: json['trip_count'] ?? 0,
    );
  }

  UserProfile copyWith({
    int? totalEarnings,
    int? tripCount,
  }) {
    return UserProfile(
      id: id,
      firstName: firstName,
      lastName: lastName,
      phoneNumber: phoneNumber,
      role: role,
      totalEarnings: totalEarnings ?? this.totalEarnings,
      tripCount: tripCount ?? this.tripCount,
    );
  }
}

class CollectorLocationUpdate {
  final String collectorId;
  final double latitude;
  final double longitude;
  final double? accuracy;
  final double? altitude;
  final DateTime timestamp;

  CollectorLocationUpdate({
    required this.collectorId,
    required this.latitude,
    required this.longitude,
    this.accuracy,
    this.altitude,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();

  factory CollectorLocationUpdate.fromJson(Map<String, dynamic> json) {
    return CollectorLocationUpdate(
      collectorId: json['collector_id'] ?? '',
      latitude: (json['latitude'] ?? 0).toDouble(),
      longitude: (json['longitude'] ?? 0).toDouble(),
      accuracy: json['accuracy'] != null ? (json['accuracy']).toDouble() : null,
      altitude: json['altitude'] != null ? (json['altitude']).toDouble() : null,
      timestamp: json['timestamp'] != null ? DateTime.parse(json['timestamp']) : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'collector_id': collectorId,
      'latitude': latitude,
      'longitude': longitude,
      'accuracy': accuracy,
      'altitude': altitude,
      'timestamp': timestamp.toIso8601String(),
    };
  }
}

class VehicleLocationUpdate {
  final String vehicleId;
  final double latitude;
  final double longitude;
  final double? accuracy;
  final double? heading;
  final double? speed;
  final DateTime timestamp;

  VehicleLocationUpdate({
    required this.vehicleId,
    required this.latitude,
    required this.longitude,
    this.accuracy,
    this.heading,
    this.speed,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();

  factory VehicleLocationUpdate.fromJson(Map<String, dynamic> json) {
    return VehicleLocationUpdate(
      vehicleId: json['vehicle_id'] ?? '',
      latitude: (json['latitude'] ?? 0).toDouble(),
      longitude: (json['longitude'] ?? 0).toDouble(),
      accuracy: json['accuracy'] != null ? (json['accuracy']).toDouble() : null,
      heading: json['heading'] != null ? (json['heading']).toDouble() : null,
      speed: json['speed'] != null ? (json['speed']).toDouble() : null,
      timestamp: json['timestamp'] != null ? DateTime.parse(json['timestamp']) : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'vehicle_id': vehicleId,
      'latitude': latitude,
      'longitude': longitude,
      'accuracy': accuracy,
      'heading': heading,
      'speed': speed,
      'timestamp': timestamp.toIso8601String(),
    };
  }
}

class TripTrackingData {
  final String tripId;
  final List<CollectorLocationUpdate> locationHistory;
  final CollectorLocationUpdate? currentLocation;
  final String? polyline;
  final double? distance;
  final int? estimatedTimeMinutes;
  final double? fare;

  TripTrackingData({
    required this.tripId,
    this.locationHistory = const [],
    this.currentLocation,
    this.polyline,
    this.distance,
    this.estimatedTimeMinutes,
    this.fare,
  });

  TripTrackingData copyWith({
    String? tripId,
    List<CollectorLocationUpdate>? locationHistory,
    CollectorLocationUpdate? currentLocation,
    String? polyline,
    double? distance,
    int? estimatedTimeMinutes,
    double? fare,
  }) {
    return TripTrackingData(
      tripId: tripId ?? this.tripId,
      locationHistory: locationHistory ?? this.locationHistory,
      currentLocation: currentLocation ?? this.currentLocation,
      polyline: polyline ?? this.polyline,
      distance: distance ?? this.distance,
      estimatedTimeMinutes: estimatedTimeMinutes ?? this.estimatedTimeMinutes,
      fare: fare ?? this.fare,
    );
  }
}
