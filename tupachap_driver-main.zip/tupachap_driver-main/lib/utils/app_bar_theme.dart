import 'package:flutter/material.dart';

class AppBarThemeData extends AppBarTheme {
  const AppBarThemeData({
    Color? backgroundColor,
    Color? foregroundColor,
    double elevation = 0,
    bool centerTitle = false,
    IconThemeData? iconTheme,
  }) : super(
    backgroundColor: backgroundColor,
    foregroundColor: foregroundColor,
    elevation: elevation,
    centerTitle: centerTitle,
    iconTheme: iconTheme,
  );
}
