import 'package:flutter/material.dart';
import 'package:tupachap_driver/models/models.dart';
import 'package:tupachap_driver/services/api_service.dart' hide UserProfile;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class AppProvider extends ChangeNotifier {
  final ApiService _apiService = ApiService();
  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  AppState _appState = AppState.splashScreen;
  PickupRequest? _currentRequest;
  String? _currentTripId;
  UserProfile? _userProfile;
  List<PickupRequest> _availableRequests = [];
  List<PickupRequest> _assignedRequests = [];
  AccessCredentials? _credentials;
  bool _isFinalCompletion = false;

  AppState get appState => _appState;
  PickupRequest? get currentRequest => _currentRequest;
  String? get currentTripId => _currentTripId;
  UserProfile? get userProfile => _userProfile;
  List<PickupRequest> get availableRequests => _availableRequests;
  List<PickupRequest> get assignedRequests => _assignedRequests;
  AccessCredentials? get credentials => _credentials;
  bool get isFinalCompletion => _isFinalCompletion;

  void setAppState(AppState state) {
    _appState = state;
    notifyListeners();
  }

  void setCurrentRequest(PickupRequest? request) {
    _currentRequest = request;
    if (request != null) _currentTripId = request.id;
    notifyListeners();
  }

  void setUserProfile(UserProfile profile) {
    _userProfile = profile;
    notifyListeners();
  }

  Future<void> login(String phoneNumber, String password) async {
    try {
      final creds = await _apiService.login(phoneNumber, password);
      _credentials = creds;
      await _storage.write(key: 'auth_token', value: creds.accessToken);

      await _fetchProfileAndResumeState(creds.accessToken);
    } catch (e) {
      throw Exception('Login failed: ${e.toString()}');
    }
  }

  Future<void> loadProfileFromToken() async {
    try {
      final token = await _storage.read(key: 'auth_token');
      if (token != null) {
        _credentials = AccessCredentials(
          accessToken: token, 
          tokenType: 'bearer', 
          role: 'WASTEPICKER'
        );
        await _fetchProfileAndResumeState(token);
      } else {
        setAppState(AppState.login);
      }
    } catch (e) {
      await _storage.deleteAll();
      setAppState(AppState.login);
    }
  }

  Future<void> _fetchProfileAndResumeState(String token) async {
    try {
      final stats = await _apiService.getWastepickerStats(token);
      
      final profile = UserProfile(
        id: stats['user_id']?.toString() ?? '',
        firstName: stats['first_name'] ?? '',
        lastName: stats['last_name'] ?? '',
        phoneNumber: '', 
        role: _credentials?.role ?? 'WASTEPICKER',
        totalEarnings: (stats['revenue_tzs'] ?? 0).toInt(),
        tripCount: (stats['trips_completed'] ?? 0).toInt(),
      );
      setUserProfile(profile);
      await refreshAvailableTrips();
      
      // Determine if there's an active trip and set current state
      if (_assignedRequests.isNotEmpty) {
        final activeTrip = _assignedRequests.first;
        _currentRequest = activeTrip;
        _currentTripId = activeTrip.id;
        
        if (activeTrip.status == 'IN_TRANSIT') {
          setAppState(AppState.navigationToDumpsite);
        } else {
          setAppState(AppState.home);
        }
      } else {
        setAppState(AppState.home);
      }
    } catch (e) {
      debugPrint('Error fetching profile: $e');
      setAppState(AppState.login);
    }
  }

  Future<void> refreshAvailableTrips() async {
    if (_credentials == null) return;
    try {
      final tripsData = await _apiService.getAvailableTrips(_credentials!.accessToken);
      _availableRequests = tripsData.map((json) => PickupRequest.fromJson(json)).toList();
      
      final assignedData = await _apiService.getMyAssignedTrips(_credentials!.accessToken);
      _assignedRequests = assignedData.map((json) => PickupRequest.fromJson(json)).toList();
      
      notifyListeners();
    } catch (e) {
      debugPrint('Error refreshing trips: $e');
    }
  }

  Future<void> acceptRequest(PickupRequest request) async {
    setCurrentRequest(request);
    setAppState(AppState.navigationToCustomer);
  }

  Future<void> startTrip(String qrHash) async {
    if (_credentials == null || _currentTripId == null) return;
    try {
      await _apiService.scanTripQR(_credentials!.accessToken, _currentTripId!, qrHash);
      _isFinalCompletion = false; // It's pickup completion (status becomes IN_TRANSIT)
      setAppState(AppState.tripComplete); 
    } catch (e) {
      throw Exception('Failed to verify QR code: $e');
    }
  }

  Future<void> uploadTripPhotos({
    List<String>? pickupPics,
    List<String>? dumpsitePics,
  }) async {
    if (_credentials == null || _currentTripId == null) return;
    try {
      await _apiService.updateTripPics(
        _credentials!.accessToken,
        _currentTripId!,
        pickupPics: pickupPics,
        dumpsitePics: dumpsitePics,
      );
    } catch (e) {
      throw Exception('Failed to upload photos: $e');
    }
  }

  void arrivedAtCustomer() => setAppState(AppState.photoPickup); 
  
  void photoPickupComplete() {
    refreshAvailableTrips();
    setAppState(AppState.home); 
  }

  void arrivedAtDumpsite() {
    setAppState(AppState.photoDisposal);
  }

  void photoDisposalComplete() {
    _isFinalCompletion = true;
    setAppState(AppState.tripComplete);
  }

  Future<void> completeTrip() async {
    if (_credentials == null || _currentTripId == null) return;
    try {
      await _apiService.completeTrip(_credentials!.accessToken, _currentTripId!);
      
      final stats = await _apiService.getWastepickerStats(_credentials!.accessToken);
      if (_userProfile != null) {
        setUserProfile(_userProfile!.copyWith(
          totalEarnings: (stats['total_earnings'] ?? 0).toInt(),
          tripCount: (stats['total_trips'] ?? 0).toInt(),
        ));
      }
      
      _currentRequest = null;
      _currentTripId = null;
      await refreshAvailableTrips();
      setAppState(AppState.home);
    } catch (e) {
      throw Exception('Failed to complete trip: $e');
    }
  }

  void logout() {
    _storage.deleteAll();
    _userProfile = null;
    _currentRequest = null;
    _currentTripId = null;
    _availableRequests = [];
    _assignedRequests = [];
    _credentials = null;
    setAppState(AppState.login);
  }
}

enum AppState {
  splashScreen,
  login,
  home,
  navigationToCustomer,
  photoPickup,
  navigationToDumpsite,
  photoDisposal,
  tripComplete,
}
