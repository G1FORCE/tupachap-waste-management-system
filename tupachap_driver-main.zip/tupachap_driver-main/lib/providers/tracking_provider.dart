import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/websocket_tracking_service.dart';
import '../services/api_service.dart';

class TrackingProvider extends ChangeNotifier {
  final WebSocketTrackingService _wsService = WebSocketTrackingService();
  
  TripTrackingData? _tripTrackingData;
  bool _isConnected = false;
  String? _connectionError;
  List<CollectorLocationUpdate> _collectorLocationHistory = [];
  Map<String, VehicleLocationUpdate> _vehicleLocations = {};

  // Callbacks for different message types
  Function(dynamic jobOffer)? onJobOffer;
  Function(String jobId)? onJobAccepted;
  Function(String jobId)? onJobRejected;
  Function(Map<String, dynamic> stats)? onPlatformStats;

  TripTrackingData? get tripTrackingData => _tripTrackingData;
  bool get isConnected => _isConnected;
  String? get connectionError => _connectionError;
  List<CollectorLocationUpdate> get collectorLocationHistory => _collectorLocationHistory;
  Map<String, VehicleLocationUpdate> get vehicleLocations => _vehicleLocations;

  TrackingProvider() {
    _setupWebSocketCallbacks();
  }

  void _setupWebSocketCallbacks() {


    _wsService.onError = (error) {
      _connectionError = error;
      notifyListeners();
    };

    _wsService.onCollectorLocationUpdate = (latitude, longitude) {
      _updateCollectorLocation(latitude, longitude);
    };


  }

  void _updateCollectorLocation(double latitude, double longitude) {
    final update = CollectorLocationUpdate(
      collectorId: _tripTrackingData?.tripId ?? '',
      latitude: latitude,
      longitude: longitude,
    );

    _collectorLocationHistory.add(update);
    
    _tripTrackingData = _tripTrackingData?.copyWith(
      currentLocation: update,
      locationHistory: _collectorLocationHistory,
    );

    notifyListeners();
  }

  void _updateVehicleLocation(String vehicleId, double latitude, double longitude) {
    final update = VehicleLocationUpdate(
      vehicleId: vehicleId,
      latitude: latitude,
      longitude: longitude,
    );

    _vehicleLocations[vehicleId] = update;
    notifyListeners();
  }

  /// Initialize trip tracking
  Future<void> initiateTripTracking({
    required String tripId,
    required String token,
    required String userType,
    required String origin,
    required Location destination,
    AccessCredentials? accessCredentials,
  }) async {
    try {
      _tripTrackingData = TripTrackingData(tripId: tripId);
      
      // Note: Directions API is currently not available in ApiService.
      // We will rely on raw coordinates for now or implement a client-side polyline decoder if needed.
      
      notifyListeners();

      // Connect to WebSocket using the new publishLocation logic if driver
      await _wsService.connectToTripTracking(
        tripId: tripId,
        token: token,
        userType: userType,
      );
    } catch (e) {
      _connectionError = 'Failed to initiate trip tracking: $e';
      notifyListeners();
    }
  }

  /// Broadcast current collector location to trip tracking channel
  void broadcastCollectorLocation({
    required double latitude,
    required double longitude,
    double? accuracy,
    double? heading,
  }) {
    _wsService.broadcastCollectorLocation(
      latitude: latitude,
      longitude: longitude,
      accuracy: accuracy,
      heading: heading,
    );
  }

  void stopTracking() {
    _wsService.disconnectAll();
    _tripTrackingData = null;
    _collectorLocationHistory.clear();
    _vehicleLocations.clear();
    _isConnected = false;
    notifyListeners();
  }

  @override
  void dispose() {
    _wsService.dispose();
    super.dispose();
  }
}
