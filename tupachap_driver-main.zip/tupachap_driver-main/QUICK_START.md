# Quick Start Guide - Real-time Tracking Implementation

## Files Overview

### Core Service Files
- **lib/services/api_service.dart** - HTTP requests + WebSocket connection management
- **lib/services/websocket_tracking_service.dart** - High-level WebSocket service with auto-reconnect
- **lib/providers/tracking_provider.dart** - Provider for state management with Consumer

### UI Files
- **lib/screens/trip_tracking_screen.dart** - Two screens:
  - `TripTrackingScreen` - For tracking a collector during a trip
  - `VehicleTrackingScreen` - For broadcasting vehicle location

### Models
- **lib/models/models.dart** - Added:
  - `CollectorLocationUpdate`
  - `VehicleLocationUpdate`
  - `TripTrackingData`

## How to Use

### 1. Start Trip Tracking
```dart
// Navigate to tracking screen
Navigator.push(
  context,
  MaterialPageRoute(
    builder: (context) => TripTrackingScreen(
      tripId: 'trip_123',
      token: credentials.authToken,
      userType: 'customer',
      collectorId: 'collector_456',
      origin: '-6.8048,39.2834',
      destination: '-6.7924,39.2083',
      accessCredentials: credentials,
    ),
  ),
);
```

### 2. Start Vehicle Location Broadcasting
```dart
Navigator.push(
  context,
  MaterialPageRoute(
    builder: (context) => VehicleTrackingScreen(
      token: credentials.authToken,
      vehicleId: 'vehicle_789',
    ),
  ),
);
```

### 3. Access Tracking Data in Any Widget
```dart
Consumer<TrackingProvider>(
  builder: (context, trackingProvider, _) {
    final distance = trackingProvider.tripTrackingData?.distance;
    final eta = trackingProvider.tripTrackingData?.estimatedTimeMinutes;
    final fare = trackingProvider.tripTrackingData?.fare;
    final isConnected = trackingProvider.isConnected;
    
    // Use data in UI
    return Text('Distance: $distance km, ETA: $eta min');
  },
)
```

## WebSocket Message Flow

### Trip Tracking
```
Client -> Server: {"type": "update_location", "collector_id": "...", "location": {...}}
Server -> Client: {"type": "pong"} or {"type": "location_ack"}
```

### Vehicle Tracking  
```
Vehicle -> Server: {"type": "update_location", "vehicle_id": "...", "location": {...}}
Server -> All Vehicles: {"type": "vehicle_location", "vehicle_id": "...", ...}
```

## Required Permissions (Android/iOS)

Add to AndroidManifest.xml:
```xml
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
```

## Testing Checklist

- [ ] Install dependencies: `flutter pub get`
- [ ] Google Maps API key configured for both platforms
- [ ] Test WebSocket connection establishment
- [ ] Test location broadcasting
- [ ] Test polyline rendering on map
- [ ] Test connection auto-recovery
- [ ] Test error handling
- [ ] Test UI state updates with real location data

## Troubleshooting

**WebSocket Connection Failed:**
- Check token validity
- Verify backend is running
- Check firewall/network settings

**Polyline Not Rendering:**
- Verify Google Maps API key is correct
- Check if directions API returned valid polyline
- Ensure flutter_polyline_points is properly initialized

**Location Permission Denied:**
- Run app with location enabled
- Check if permission was granted
- iOS: Check NSLocationWhenInUseUsageDescription in Info.plist

**Map Not Showing:**
- Verify Google Maps API keys for both platforms
- Check AndroidManifest.xml and Info.plist configuration
- Ensure location service is enabled on device
