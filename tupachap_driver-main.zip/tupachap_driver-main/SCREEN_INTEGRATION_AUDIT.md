# Screen Integration Audit Report

## Overview
This document outlines the current screen integration status and recommendations for full API service integration following the WebSocket communication guidelines.

---

## Current Screen Structure

### 1. **Splash Screen** (`splash_screen.dart`)
**Purpose:** Initial loading screen
**Current Integration:** ❌ No API integration
**Recommendation:** Keep as-is (pure UI)

---

### 2. **Login Screen** (`login_screen.dart`)
**Purpose:** User authentication
**Current Integration:** ✅ Partial (uses `ApiService.login()`)
**API Used:**
- `POST /api/auth/login` - Phone number & password

**Next Steps:**
- Store credentials securely
- Initialize WebSocket connection on successful login
- Handle token refresh

**Suggested Enhancement:**
```dart
// After successful login
final credentials = await ApiService().login(phone, password);

// Initialize tracking provider and WebSocket connections
if (mounted) {
  context.read<TrackingProvider>().initializePlatformChannels(
    token: credentials.authToken,
    userType: _getUserType(),  // 'collector' or 'admin'
  );
}
```

---

### 3. **Vehicle Confirmation Screen** (`vehicle_confirmation_screen.dart`)
**Purpose:** Select vehicle for trip
**Current Integration:** ❌ No API integration
**Recommendation:** Add vehicle selection API call

**Suggested Implementation:**
```dart
// After vehicle selection
Future<void> _selectVehicle(String vehicleId) async {
  try {
    await ApiService().selectVehicle(vehicleId, credentials);
    // Then connect to vehicle tracking
    context.read<TrackingProvider>().initiateVehicleTracking(
      token: credentials.authToken,
    );
  } catch (e) {
    _showError(e.toString());
  }
}
```

---

### 4. **Home Screen** (`home_screen.dart`)
**Purpose:** Display available pickup requests
**Current Integration:** ✅ Partial (uses `PickupService.fetchAvailableRequests()`)

**Current Flow:**
1. Fetches available requests via HTTP
2. Displays requests in list
3. User selects a request

**WebSocket Integration Needed:**
- Connect to collector channel on app startup
- Listen for `job_offer` messages
- Display notification popup for new offers

**Suggested Enhancement:**
```dart
@override
void initState() {
  super.initState();
  _loadRequests();
  _initializeCollectorChannel();
}

Future<void> _initializeCollectorChannel() async {
  final provider = context.read<TrackingProvider>();
  
  // Connect to collector WebSocket
  await provider.connectToCollectorChannel(
    collectorId: currentCollector.id,
    token: credentials.authToken,
  );

  // Listen for job offers
  provider.onJobOffer = (jobOffer) {
    _showJobOfferPopup(jobOffer);
  };
}
```

---

### 5. **Navigation Screen** (`navigation_screen.dart`)
**Purpose:** Show map with route to pickup/disposal location
**Current Integration:** ✅ Partial (displays map with hardcoded polyline)

**Current Status:**
- Shows static Google Map
- Displays hardcoded truck markers
- Shows distance and ETA

**WebSocket Integration Needed:**
- Real-time collector location updates
- Broadcast collector location to tracking users
- Receive status updates from server

**Suggested Enhancement:**
```dart
@override
void initState() {
  super.initState();
  _initializeTracking();
}

Future<void> _initializeTracking() async {
  final provider = context.read<TrackingProvider>();
  
  // Start trip tracking
  await provider.initiateTripTracking(
    tripId: currentRequest.tripId,
    token: credentials.authToken,
    userType: 'collector',
    origin: currentRequest.pickupLocation,
    destination: currentRequest.disposalLocation,
  );

  // Listen to location updates
  provider.onLocationUpdate = (latitude, longitude) {
    _updateMarkerPosition(latitude, longitude);
  };
}
```

---

### 6. **Photo Capture Screen** (`photo_capture_screen.dart`)
**Purpose:** Capture photos of waste
**Current Integration:** ✅ Uses HTTP to upload photos
**API Used:**
- `POST /api/requests/{id}/proof-of-service` - Upload photos

**Current Status:** ✅ Fully integrated

---

### 7. **Trip Complete Screen** (`trip_complete_screen.dart`)
**Purpose:** Show trip completion summary
**Current Integration:** ❌ No API integration
**Recommendation:** Display trip stats and earnings

**Suggested Implementation:**
```dart
Future<void> _completeTrip() async {
  final tripId = widget.currentRequest.tripId;
  
  // Call complete API
  final result = await ApiService().completePickup(tripId, credentials);
  
  // Update trip tracking status
  context.read<TrackingProvider>().notifyTripComplete(tripId);
  
  // Navigate to home
  Navigator.pushNamedAndRemoveUntil(context, '/', (route) => false);
}
```

---

## WebSocket Channel Integration Map

### Current Implementation Status:

| Channel | Purpose | Status | Used By |
|---------|---------|--------|---------|
| `/ws/track/{trip_id}` | Real-time trip tracking (customers/admins) | ✅ Ready | TripTrackingScreen |
| `/ws/collector/{id}` | Collector job offers & location | ❌ Not Used | HomeScreen, JobOfferPopup |
| `/ws/admin` | Admin dashboard & platform stats | ❌ Not Used | AdminDashboard (future) |
| `/ws/vehicles` | Vehicle location broadcasting | ✅ Ready | VehicleTrackingScreen |

---

## API Integration Checklist

### Authentication & Profile
- [x] Login (`POST /api/auth/login`)
- [x] Refresh token (`POST /api/auth/refresh`)
- [x] Get profile (`GET /api/users/profile`)
- [x] Update profile (`PUT /api/users/profile`)

### Requests & Jobs
- [x] Get available requests (`GET /api/jobs/available`)
- [x] Get request details (`GET /api/requests/{id}`)
- [x] Accept request (`POST /api/jobs/{id}/accept`)
- [x] Start pickup (`POST /api/jobs/{id}/start`)
- [x] Complete pickup (`POST /api/jobs/{id}/complete`)

### Proof of Service
- [x] Submit photos (`POST /api/requests/{id}/proof-of-service`)

### Directions
- [x] Get directions (`POST /api/location/directions`)

### WebSocket - Trip Tracking
- [x] Connect to trip channel
- [ ] Handle location_update messages
- [ ] Handle status_update messages
- [ ] Handle eta_update messages

### WebSocket - Collector Channel
- [ ] Connect to collector channel
- [ ] Receive job_offer messages
- [ ] Send accept_job messages
- [ ] Send reject_job messages
- [ ] Send update_location messages

### WebSocket - Vehicle Tracking
- [x] Connect to vehicle channel
- [x] Send vehicle location updates
- [x] Receive vehicle_location messages
- [ ] Request active vehicles list

---

## Recommended Screen Flow with WebSocket Integration

### Complete User Journey:

```
1. Splash Screen
   ↓
2. Login Screen
   ├─ Authenticate user
   └─ Initialize WebSocket connections
   ↓
3. Vehicle Confirmation Screen
   ├─ Select vehicle
   └─ Connect to vehicle tracking channel
   ↓
4. Home Screen
   ├─ Display available jobs from HTTP
   ├─ Listen for job_offer messages via WebSocket
   └─ Show notification popup for new offers
   ↓
5. Job Accepted → Navigation Screen
   ├─ Initialize trip tracking WebSocket
   ├─ Start broadcasting location
   ├─ Display real-time route & ETA
   └─ Receive status/ETA updates
   ↓
6. Arrived → Photo Capture Screen
   ├─ Capture photos
   └─ Upload via HTTP
   ↓
7. Trip Complete → Trip Complete Screen
   ├─ Show summary
   ├─ Notify trip complete via WebSocket
   └─ Return to Home Screen
```

---

## Critical Integration Points

### 1. **App Startup Sequence**
```dart
// In main.dart or splash screen
Future<void> _initializeApp() async {
  // 1. Check if logged in
  final credentials = await SecureStorage.getCredentials();
  
  if (credentials == null) {
    // Navigate to login
    return;
  }
  
  // 2. Initialize providers
  if (mounted) {
    context.read<AppProvider>().setCredentials(credentials);
    context.read<TrackingProvider>().setCredentials(credentials);
  }
  
  // 3. Establish WebSocket connections
  _initializeWebSocketConnections(credentials);
}
```

### 2. **WebSocket Connection Management**
```dart
// In app initialization
Future<void> _initializeWebSocketConnections(AccessCredentials creds) async {
  // Connect to collector channel (for job offers)
  await ApiService().connectToCollectorChannel(
    collectorId: userProfile.id,
    token: creds.authToken,
  );
  
  // Don't connect to vehicle/trip channels yet
  // They will be connected when needed
}
```

### 3. **Error Handling & Reconnection**
```dart
// In WebSocket service
Future<void> _reconnectTripTracking({...}) async {
  await Future.delayed(Duration(seconds: 2));
  await connectToTripTracking(...);
}
```

---

## Screen-by-Screen Integration Guide

### Home Screen
**Add WebSocket listener for job offers:**
```dart
void _setupJobOfferListener() {
  final apiService = ApiService();
  
  // Listen to WebSocket stream
  _wsService.onJobOffer = (jobOffer) {
    // Show popup or notification
    _showJobOfferDialog(jobOffer);
  };
}
```

### Navigation Screen
**Add real-time location tracking:**
```dart
void _startLocationTracking() {
  // Broadcast location periodically
  _locationSubscription = 
      _location.onLocationChanged.listen((LocationData location) {
    // Broadcast to server
    ApiService().broadcastCollectorLocation(
      channel: _tripChannel,
      latitude: location.latitude!,
      longitude: location.longitude!,
    );
    
    // Update map
    _updateMapMarker(location);
  });
}
```

---

## Deployment Checklist

- [ ] Update all screen imports
- [ ] Initialize WebSocket connections at app startup
- [ ] Add error handling for connection failures
- [ ] Test all WebSocket message types
- [ ] Verify automatic reconnection logic
- [ ] Test location permission handling
- [ ] Validate token refresh flow
- [ ] Test with actual backend WebSocket server
- [ ] Monitor connection stability
- [ ] Add analytics for connection events

---

## Next Steps

1. **Immediate:** Implement collector channel in HomeScreen
2. **Short-term:** Add real-time location broadcasting to NavigationScreen
3. **Medium-term:** Implement admin dashboard with `/ws/admin` channel
4. **Long-term:** Add analytics and connection monitoring

---

## Notes

- All WebSocket connections require valid JWT token
- Connections should be managed at the app level (not screen level)
- Use TrackingProvider for global WebSocket state
- Implement proper cleanup in dispose() methods
- Test with network throttling and disconnection scenarios
