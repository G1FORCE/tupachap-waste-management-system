package com.example.tupachap_driver;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
