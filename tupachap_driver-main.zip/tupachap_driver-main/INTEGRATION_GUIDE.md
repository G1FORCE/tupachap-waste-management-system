# TupaChap Driver - API Service Integration Guide

## Overview

This guide explains the newly implemented API service integration, WebSocket communication, and real-time tracking features.

## New Features

### 1. **Enhanced API Service** (`lib/services/api_service.dart`)

#### Updated Directions Endpoint

```dart
// Get directions between two locations
Future<DirectionsResponse> getDirections(
  Location origin,
  Location destination,
  AccessCredentials accessCredentials
) async {
  // Returns DirectionsResponse with:
  // - distanceKm: double
  // - estimatedTimeMinutes: int
  // - fare: double
  // - polyline: string (encoded polyline for Google Maps)
}
```

**Endpoint**: `POST /api/location/directions`

**Request Format**:
```json
{
  "origin": {
    "latitude": -6.8048,
    "longitude": 39.2834
  },
  "destination": {
    "latitude": -6.7924,
    "longitude": 39.2083
  }
}
```

**Response Format**:
```json
{
  "distance_km": 12.5,
  "estimated_time_minutes": 25,
  "fare": 15000,
  "polyline": "encoded_polyline_string"
}
```

### 2. **WebSocket Communication**

#### Trip Tracking WebSocket

Enables real-time tracking of collector location during a trip.

```dart
// Connect to trip tracking
WebSocketChannel channel = apiService.connectToTripTracking(
  tripId: 'trip_123',
  token: 'jwt_token',
  userType: 'customer', // or 'admin', 'collector'
);

// Broadcast collector location
apiService.broadcastCollectorLocation(
  channel: channel,
  collectorId: 'collector_456',
  latitude: -6.8048,
  longitude: 39.2834,
  accuracy: 5.0,
);

// Send ping to keep connection alive
apiService.sendPing(channel);

// Disconnect
apiService.disconnectWebSocket(channel);
```

**Endpoint**: `ws://localhost:8000/ws/track/{trip_id}?token={jwt}&user_type={type}`

**Message Types Supported**:
- `update_location` - Broadcaster sends location update
- `ping` - Keep-alive ping
- `pong` - Server response to ping
- `error` - Error message from server

#### Vehicle Tracking WebSocket

Enables real-time broadcasting of vehicle locations to all connected vehicles.

```dart
// Connect to vehicle tracking
WebSocketChannel channel = apiService.connectToVehicleTracking(
  token: 'jwt_token',
);

// Broadcast vehicle location
apiService.broadcastVehicleLocation(
  channel: channel,
  vehicleId: 'vehicle_789',
  latitude: -6.8048,
  longitude: 39.2834,
  accuracy: 5.0,
  heading: 45.0,
  speed: 60.0,
);
```

**Endpoint**: `ws://localhost:8000/ws/vehicles?token={jwt}`

**Message Format**:
```json
{
  "type": "update_location",
  "vehicle_id": "vehicle_789",
  "location": {
    "latitude": -6.8048,
    "longitude": 39.2834,
    "accuracy": 5.0,
    "heading": 45.0,
    "speed": 60.0
  }
}
```

### 3. **WebSocket Tracking Service** (`lib/services/websocket_tracking_service.dart`)

A high-level service that manages WebSocket connections, automatic reconnection, and provides callbacks for location updates.

```dart
final wsService = WebSocketTrackingService();

// Set up callbacks
wsService.onConnectionEstablished = () {
  print('Connected');
};

wsService.onConnectionClosed = () {
  print('Disconnected');
};

wsService.onError = (error) {
  print('Error: $error');
};

wsService.onCollectorLocationUpdate = (latitude, longitude) {
  print('Collector location: $latitude, $longitude');
};

wsService.onVehicleLocationUpdate = (vehicleId, latitude, longitude) {
  print('Vehicle $vehicleId: $latitude, $longitude');
};

// Connect to trip tracking
await wsService.connectToTripTracking(
  tripId: 'trip_123',
  token: 'jwt_token',
  userType: 'customer',
);

// Broadcast location
wsService.broadcastCollectorLocation(
  collectorId: 'collector_456',
  latitude: -6.8048,
  longitude: 39.2834,
  accuracy: 5.0,
);

// Disconnect
wsService.disconnectFromTripTracking();
```

### 4. **Tracking Provider** (`lib/providers/tracking_provider.dart`)

A Provider-based state management solution for tracking.

```dart
// In your widget
Consumer<TrackingProvider>(
  builder: (context, trackingProvider, _) {
    // Initialize tracking
    trackingProvider.initiateTripTracking(
      tripId: 'trip_123',
      token: 'jwt_token',
      userType: 'customer',
      origin: '-6.8048,39.2834',
      destination: '-6.7924,39.2083',
      accessCredentials: credentials,
    );

    // Get current tracking data
    final tripData = trackingProvider.tripTrackingData;
    final distance = tripData?.distance;
    final eta = tripData?.estimatedTimeMinutes;
    final fare = tripData?.fare;
    final polyline = tripData?.polyline;

    // Get polyline coordinates for Google Maps
    final coordinates = trackingProvider.getPolylineCoordinates();

    // Get connection status
    final isConnected = trackingProvider.isConnected;
    final error = trackingProvider.connectionError;

    // Stop tracking
    trackingProvider.stopTracking();

    return YourWidget();
  },
)
```

### 5. **Tracking Models**

#### CollectorLocationUpdate
```dart
class CollectorLocationUpdate {
  final String collectorId;
  final double latitude;
  final double longitude;
  final double? accuracy;
  final double? altitude;
  final DateTime timestamp;
}
```

#### VehicleLocationUpdate
```dart
class VehicleLocationUpdate {
  final String vehicleId;
  final double latitude;
  final double longitude;
  final double? accuracy;
  final double? heading;
  final double? speed;
  final DateTime timestamp;
}
```

#### TripTrackingData
```dart
class TripTrackingData {
  final String tripId;
  final List<CollectorLocationUpdate> locationHistory;
  final CollectorLocationUpdate? currentLocation;
  final String? polyline;
  final double? distance;
  final int? estimatedTimeMinutes;
  final double? fare;
}
```

### 6. **Trip Tracking Screen** (`lib/screens/trip_tracking_screen.dart`)

A complete UI screen for real-time trip tracking with polyline visualization.

```dart
Navigator.push(
  context,
  MaterialPageRoute(
    builder: (context) => TripTrackingScreen(
      tripId: 'trip_123',
      token: 'jwt_token',
      userType: 'customer',
      collectorId: 'collector_456',
      origin: '-6.8048,39.2834',
      destination: '-6.7924,39.2083',
      accessCredentials: credentials,
    ),
  ),
);
```

**Features**:
- Real-time Google Map display
- Live collector location marker
- Polyline route visualization
- Distance, ETA, and fare information
- Connection status indicator
- Pause/resume tracking functionality

### 7. **Vehicle Tracking Screen** (`lib/screens/trip_tracking_screen.dart`)

A UI screen for vehicle location tracking and broadcasting.

```dart
Navigator.push(
  context,
  MaterialPageRoute(
    builder: (context) => VehicleTrackingScreen(
      token: 'jwt_token',
      vehicleId: 'vehicle_789',
    ),
  ),
);
```

**Features**:
- Real-time Google Map display
- Vehicle location marker
- List of active vehicles
- Connection status indicator
- Automatic location broadcasting

## Usage Examples

### Example 1: Starting Trip Tracking

```dart
class TripDetailPage extends StatelessWidget {
  final String tripId;
  final String collectorId;
  final AccessCredentials credentials;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Consumer<TrackingProvider>(
        builder: (context, trackingProvider, _) {
          return Center(
            child: ElevatedButton(
              onPressed: () async {
                await trackingProvider.initiateTripTracking(
                  tripId: tripId,
                  token: credentials.authToken,
                  userType: 'customer',
                  origin: '-6.8048,39.2834',
                  destination: '-6.7924,39.2083',
                  accessCredentials: credentials,
                );

                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => TripTrackingScreen(
                      tripId: tripId,
                      token: credentials.authToken,
                      userType: 'customer',
                      collectorId: collectorId,
                      origin: '-6.8048,39.2834',
                      destination: '-6.7924,39.2083',
                      accessCredentials: credentials,
                    ),
                  ),
                );
              },
              child: const Text('Start Live Tracking'),
            ),
          );
        },
      ),
    );
  }
}
```

### Example 2: Broadcasting Vehicle Location

```dart
class VehicleLocationBroadcaster extends StatefulWidget {
  final String vehicleId;
  final String token;

  @override
  State<VehicleLocationBroadcaster> createState() =>
      _VehicleLocationBroadcasterState();
}

class _VehicleLocationBroadcasterState
    extends State<VehicleLocationBroadcaster> {
  final Location _location = Location();
  late StreamSubscription _locationSubscription;

  @override
  void initState() {
    super.initState();
    _initializeLocationBroadcasting();
  }

  Future<void> _initializeLocationBroadcasting() async {
    // Request permission
    bool hasPermission =
        await _location.hasPermission() != PermissionStatus.denied;

    if (!hasPermission) {
      hasPermission =
          await _location.requestPermission() == PermissionStatus.granted;
      if (!hasPermission) return;
    }

    // Start broadcasting
    _locationSubscription =
        _location.onLocationChanged.listen((LocationData location) {
      context.read<TrackingProvider>().broadcastVehicleLocation(
            vehicleId: widget.vehicleId,
            latitude: location.latitude!,
            longitude: location.longitude!,
            accuracy: location.accuracy,
            heading: location.heading,
            speed: location.speed,
          );
    });
  }

  @override
  void dispose() {
    _locationSubscription.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Text('Broadcasting vehicle location...'),
      ),
    );
  }
}
```

### Example 3: Displaying Trip Information

```dart
class TripInfoCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<TrackingProvider>(
      builder: (context, trackingProvider, _) {
        final trip = trackingProvider.tripTrackingData;

        if (trip == null) {
          return const SizedBox();
        }

        return Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      children: [
                        const Text('Distance'),
                        Text(
                          '${trip.distance?.toStringAsFixed(1) ?? 'N/A'} km',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    Column(
                      children: [
                        const Text('ETA'),
                        Text(
                          '${trip.estimatedTimeMinutes ?? 'N/A'} min',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    Column(
                      children: [
                        const Text('Fare'),
                        Text(
                          'Tsh ${trip.fare?.toStringAsFixed(0) ?? 'N/A'}',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
```

## Integration Checklist

- [x] Add `web_socket_channel` to `pubspec.yaml`
- [x] Update `ApiService` with WebSocket methods and directions endpoint
- [x] Create `WebSocketTrackingService` for connection management
- [x] Add tracking models to `models.dart`
- [x] Create `TrackingProvider` for state management
- [x] Create `TripTrackingScreen` for UI
- [x] Create `VehicleTrackingScreen` for vehicle tracking
- [x] Add `TrackingProvider` to `main.dart`
- [ ] Run `flutter pub get` to install dependencies
- [ ] Update Google Maps API key in Android and iOS configuration
- [ ] Test WebSocket connection with backend
- [ ] Test polyline rendering on Google Maps
- [ ] Test location broadcasting

## Dependencies Added

```yaml
web_socket_channel: ^2.4.0
```

## Notes

- WebSocket connections automatically reconnect after 2 seconds if disconnected
- Ping messages are sent every 30 seconds to keep connections alive
- Location updates are broadcast every time the location changes (configurable in UI)
- Polyline is decoded using `flutter_polyline_points` package
- All location data includes timestamp for tracking accuracy

## Error Handling

The `TrackingProvider` provides error handling through:
- `connectionError` - String error message if connection fails
- `onError` callback in `WebSocketTrackingService` - Called when errors occur
- Automatic reconnection - Attempts to reconnect after 2 seconds

## Performance Considerations

- Use `Consumer` widget wisely to avoid unnecessary rebuilds
- Consider throttling location broadcasts to reduce server load
- Polyline decoding happens once when directions are received
- WebSocket messages are compressed automatically by the channel
