# WebSocket Integration Guide - Complete Implementation

This guide provides comprehensive instructions for integrating the four WebSocket channels into your Flutter driver app.

## Architecture Overview

The WebSocket implementation uses three layers:

1. **API Service Layer** (`lib/services/api_service.dart`): Low-level WebSocket connection management
2. **Tracking Service Layer** (`lib/services/websocket_tracking_service.dart`): High-level connection pooling, keep-alive, auto-reconnect
3. **Provider Layer** (`lib/providers/tracking_provider.dart`): State management and callbacks

## WebSocket Channels

### 1. Trip Tracking Channel (`/ws/track/{trip_id}`)

**Purpose**: Real-time tracking of collector location during active trip

**Connection**:
```dart
final provider = context.read<TrackingProvider>();
await provider.initiateTripTracking(
  tripId: trip.id,
  token: credentials.authToken,
  userType: 'collector', // or 'admin', 'customer'
  origin: trip.pickupLocation,
  destination: trip.disposalLocation,
  credentials: credentials,
);
```

**Broadcast Collector Location**:
```dart
provider.broadcastCollectorLocation(
  latitude: location.latitude!,
  longitude: location.longitude!,
  accuracy: location.accuracy,
  heading: location.heading,
);
```

**Message Format**:
```json
{
  "type": "update_location",
  "trip_id": "trip123",
  "collector_id": "collector456",
  "location": {
    "latitude": -6.7924,
    "longitude": 39.2083,
    "accuracy": 10.5,
    "heading": 45.0
  },
  "timestamp": "2024-01-15T10:30:00Z"
}
```

**Incoming Messages**:
- `location_update`: Collector location update
- `status_update`: Trip status changed
- `eta_update`: Estimated arrival time
- `pong`: Keep-alive response
- `error`: Error message

### 2. Collector Channel (`/ws/collector/{collector_id}`)

**Purpose**: Receive new job offers and send job acceptance/rejection

**Connection**:
```dart
final provider = context.read<TrackingProvider>();
provider.onJobOffer = (jobOffer) {
  // Handle job offer (60-second countdown popup)
};
await provider.connectToCollectorChannel(
  collectorId: userProfile.id,
  token: credentials.authToken,
);
```

**Accept Job**:
```dart
provider.acceptJob(
  jobId: offer.jobId,
  tripId: offer.tripId,
);
```

**Reject Job**:
```dart
provider.rejectJob(jobId: offer.jobId);
```

**Message Format**:
```json
{
  "type": "job_offer",
  "job_id": "job789",
  "trip_id": "trip123",
  "pickup_location": {
    "latitude": -6.7924,
    "longitude": 39.2083,
    "address": "123 Main Street"
  },
  "estimated_time_minutes": 15,
  "fare_amount": 2500.0,
  "countdown_seconds": 60
}
```

**Incoming Messages**:
- `job_offer`: New job (60-second countdown)
- `location_ack`: Location broadcast acknowledged
- `job_acceptance_ack`: Job acceptance confirmed
- `job_rejection_ack`: Job rejection confirmed
- `pong`: Keep-alive response
- `error`: Error message

### 3. Admin Channel (`/ws/admin`)

**Purpose**: Monitor platform statistics and active trips

**Connection**:
```dart
final provider = context.read<TrackingProvider>();
await provider.connectToAdminChannel(
  token: credentials.authToken,
);
```

**Request Statistics**:
```dart
provider.requestPlatformStats();
```

**Message Format**:
```json
{
  "type": "stats_update",
  "active_connections": 42,
  "active_trips": 15,
  "active_collectors": 28,
  "timestamp": "2024-01-15T10:30:00Z"
}
```

**Incoming Messages**:
- `stats_update`: Platform statistics
- `pong`: Keep-alive response
- `error`: Error message

### 4. Vehicle Tracking Channel (`/ws/vehicles`)

**Purpose**: Broadcast vehicle location to all connected clients

**Connection**:
```dart
final provider = context.read<TrackingProvider>();
await provider.initiateVehicleTracking(
  token: credentials.authToken,
);
```

**Broadcast Vehicle Location**:
```dart
provider.broadcastVehicleLocation(
  vehicleId: vehicle.id,
  latitude: location.latitude!,
  longitude: location.longitude!,
  accuracy: location.accuracy,
  heading: location.heading,
  speed: location.speed,
);
```

**Request Active Vehicles**:
```dart
provider.requestActiveVehicles();
```

**Message Format**:
```json
{
  "type": "vehicle_location",
  "vehicle_id": "vehicle123",
  "location": {
    "latitude": -6.7924,
    "longitude": 39.2083,
    "accuracy": 10.5,
    "heading": 45.0,
    "speed": 60.5
  },
  "timestamp": "2024-01-15T10:30:00Z"
}
```

**Incoming Messages**:
- `vehicle_location`: Vehicle location update
- `location_ack`: Location broadcast acknowledged
- `active_vehicles`: List of active vehicles
- `pong`: Keep-alive response
- `error`: Error message

## Screen Integration Examples

### HomeScreen - Job Offer Listener

```dart
class HomeScreen extends StatefulWidget {
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    _setupJobOfferListener();
  }

  void _setupJobOfferListener() {
    final provider = context.read<TrackingProvider>();
    
    // Set up callback for job offers
    provider.onJobOffer = (jobOffer) {
      _showJobOfferDialog(jobOffer);
    };
    
    // Connect to collector channel
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      try {
        final userProfile = context.read<AppProvider>().userProfile;
        final credentials = context.read<AppProvider>().credentials;
        
        if (userProfile != null && credentials != null) {
          await provider.connectToCollectorChannel(
            collectorId: userProfile.id,
            token: credentials.authToken,
          );
        }
      } catch (e) {
        if (kDebugMode) print('Error connecting to collector channel: $e');
      }
    });
  }

  void _showJobOfferDialog(Map<String, dynamic> jobOffer) {
    int countdownSeconds = jobOffer['countdown_seconds'] ?? 60;
    
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => JobOfferDialog(
        jobOffer: jobOffer,
        countdownSeconds: countdownSeconds,
        onAccept: () => _acceptJob(jobOffer),
        onReject: () => _rejectJob(jobOffer),
      ),
    );
  }

  void _acceptJob(Map<String, dynamic> jobOffer) {
    final provider = context.read<TrackingProvider>();
    provider.acceptJob(
      jobId: jobOffer['job_id'],
      tripId: jobOffer['trip_id'],
    );
    Navigator.pop(context); // Close dialog
  }

  void _rejectJob(Map<String, dynamic> jobOffer) {
    final provider = context.read<TrackingProvider>();
    provider.rejectJob(jobId: jobOffer['job_id']);
    Navigator.pop(context); // Close dialog
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Available Jobs')),
      body: Consumer<TrackingProvider>(
        builder: (context, provider, _) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (!provider.isConnected)
                  Chip(
                    label: Text('Connecting...'),
                    backgroundColor: Colors.orange,
                  )
                else
                  Chip(
                    label: Text('Ready for jobs'),
                    backgroundColor: Colors.green,
                  ),
                SizedBox(height: 20),
                Text('Waiting for job offers...'),
              ],
            ),
          );
        },
      ),
    );
  }
}
```

### NavigationScreen - Trip Tracking

```dart
class NavigationScreen extends StatefulWidget {
  final PickupRequest request;

  NavigationScreen({required this.request});

  @override
  State<NavigationScreen> createState() => _NavigationScreenState();
}

class _NavigationScreenState extends State<NavigationScreen> {
  late GoogleMapController mapController;
  Set<Marker> _markers = {};
  final Set<Polyline> _polylines = {};

  @override
  void initState() {
    super.initState();
    _initializeTracking();
    _startLocationTracking();
  }

  Future<void> _initializeTracking() async {
    final provider = context.read<TrackingProvider>();
    final credentials = context.read<AppProvider>().credentials;
    final userProfile = context.read<AppProvider>().userProfile;

    if (credentials == null || userProfile == null) return;

    try {
      await provider.initiateTripTracking(
        tripId: widget.request.id,
        token: credentials.authToken,
        userType: 'collector',
        origin: widget.request.pickupLocation,
        destination: widget.request.disposalLocation,
        credentials: credentials,
      );

      // Listen for status updates
      provider.onStatusUpdate = (status) {
        if (kDebugMode) print('Trip status: $status');
        if (status == 'COMPLETED') {
          _completeTrip();
        }
      };

      // Decode and display polyline
      final polylineCoords = provider.getPolylineCoordinates();
      setState(() {
        _polylines.add(
          Polyline(
            polylineId: PolylineId('trip_route'),
            points: polylineCoords,
            color: Colors.blue,
            width: 5,
          ),
        );
      });
    } catch (e) {
      if (kDebugMode) print('Error initializing tracking: $e');
    }
  }

  void _startLocationTracking() {
    final location = Location();
    location.onLocationChanged.listen((LocationData locationData) {
      if (locationData.latitude != null && locationData.longitude != null) {
        _updateMarker(
          LatLng(locationData.latitude!, locationData.longitude!),
        );

        // Broadcast location every 10-30 seconds
        final provider = context.read<TrackingProvider>();
        provider.broadcastCollectorLocation(
          latitude: locationData.latitude!,
          longitude: locationData.longitude!,
          accuracy: locationData.accuracy,
          heading: locationData.heading,
        );
      }
    });
  }

  void _updateMarker(LatLng location) {
    setState(() {
      _markers = {
        Marker(
          markerId: MarkerId('collector'),
          position: location,
          infoWindow: InfoWindow(title: 'Your Location'),
          icon: BitmapDescriptor.defaultMarkerWithHue(
            BitmapDescriptor.hueBlue,
          ),
        ),
      };
    });

    mapController.animateCamera(
      CameraUpdateOptions(
        bounds: CameraUpdateBounds(
          bounds: LatLngBounds(
            southwest: location,
            northeast: location,
          ),
        ),
      ),
    );
  }

  void _completeTrip() {
    final provider = context.read<TrackingProvider>();
    provider.stopTracking();
    Navigator.pop(context);
  }

  @override
  void dispose() {
    final provider = context.read<TrackingProvider>();
    provider.stopTracking();
    mapController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Navigation'),
      ),
      body: Stack(
        children: [
          Consumer<TrackingProvider>(
            builder: (context, provider, _) {
              return GoogleMap(
                onMapCreated: (controller) => mapController = controller,
                initialCameraPosition: CameraPosition(
                  target: LatLng(
                    widget.request.pickupLocation.latitude,
                    widget.request.pickupLocation.longitude,
                  ),
                  zoom: 15,
                ),
                markers: _markers,
                polylines: _polylines,
              );
            },
          ),
          Positioned(
            bottom: 16,
            left: 16,
            right: 16,
            child: Consumer<TrackingProvider>(
              builder: (context, provider, _) {
                final data = provider.tripTrackingData;
                return Card(
                  child: Padding(
                    padding: EdgeInsets.all(16),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Column(
                              children: [
                                Text('Distance'),
                                Text(
                                  '${data?.distance.toStringAsFixed(1)} km',
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                            Column(
                              children: [
                                Text('ETA'),
                                Text(
                                  '${data?.estimatedTimeMinutes} min',
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                            Column(
                              children: [
                                Text('Fare'),
                                Text(
                                  'TZS ${data?.fare.toStringAsFixed(0)}',
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        if (!provider.isConnected)
                          Padding(
                            padding: EdgeInsets.only(top: 12),
                            child: Text(
                              'Connection lost',
                              style: TextStyle(color: Colors.red),
                            ),
                          ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
```

## API Integration

### Directions Endpoint

**Endpoint**: `POST https://tupachap-api-vixj.vercel.app/api/location/directions`

**Request**:
```dart
final directions = await ApiService().getDirections(
  origin: trip.pickupLocation,
  destination: trip.disposalLocation,
  credentials: credentials,
);
```

**Response**:
```json
{
  "distance_km": 12.5,
  "estimated_time_minutes": 25,
  "fare": 5000.0,
  "polyline": "encoded_polyline_string"
}
```

## State Management

### TrackingProvider Properties

```dart
// Connection status
bool isConnected;
String? connectionError;

// Tracking data
TripTrackingData? tripTrackingData;
List<CollectorLocationUpdate> collectorLocationHistory;
Map<String, VehicleLocationUpdate> vehicleLocations;

// Callbacks
Function(Map<String, dynamic>)? onJobOffer;
Function(String)? onStatusUpdate;
Function(int)? onEtaUpdate;
Function(Map<String, dynamic>)? onError;
```

## Error Handling

All WebSocket operations include error handling:

```dart
try {
  await provider.initiateTripTracking(...);
} catch (e) {
  // Handle connection error
  print('Connection error: $e');
}
```

## Keep-Alive Mechanism

The WebSocket service automatically sends ping messages every 30 seconds and automatically reconnects if the connection is lost.

## Disconnection

Always disconnect when done:

```dart
@override
void dispose() {
  final provider = context.read<TrackingProvider>();
  provider.stopTracking();
  super.dispose();
}
```

## Testing Checklist

- [ ] Connect to trip tracking channel
- [ ] Broadcast collector location
- [ ] Receive location updates
- [ ] Connect to collector channel
- [ ] Receive job offers
- [ ] Accept/reject jobs
- [ ] Connect to vehicle tracking
- [ ] Broadcast vehicle location
- [ ] Connect to admin channel
- [ ] Receive platform stats
- [ ] Test automatic reconnection
- [ ] Test connection stability
- [ ] Test error scenarios

## Debugging

Enable debug logging in `api_service.dart`:

```dart
if (kDebugMode) {
  print('WebSocket connected: $url');
  print('Message sent: $message');
  print('Message received: $data');
}
```

## Production Considerations

1. **Authentication**: All connections require valid JWT tokens
2. **Token Refresh**: Handle token expiration and refresh
3. **Connection Pooling**: Reuse connections when possible
4. **Rate Limiting**: Implement backoff for reconnection attempts
5. **Monitoring**: Track connection metrics and errors
6. **Scalability**: Design for multiple concurrent connections

## Additional Resources

- [WebSocket Channel Package](https://pub.dev/packages/web_socket_channel)
- [Provider Package](https://pub.dev/packages/provider)
- [Location Package](https://pub.dev/packages/location)
- [Google Maps Flutter](https://pub.dev/packages/google_maps_flutter)
