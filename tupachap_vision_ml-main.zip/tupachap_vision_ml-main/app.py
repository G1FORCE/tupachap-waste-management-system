import os
import re
import math
import numpy as np
import cv2
from PIL import Image, ExifTags
from fastapi import FastAPI, File, UploadFile, HTTPException
from scipy.spatial import distance as dist
from imutils import perspective, grab_contours
from ultralytics import YOLO

app = FastAPI(title="TupaChap Waste Valuation API", version="1.0")
model = YOLO('yolov8n-seg.pt')
# Business Logic Configuration
RATE_PER_CUBIC_CM = 0.0275  # Adjust this pricing rate based on your local market
BASE_FEE = 1000.0  # Base collection fee (e.g., in TZS or your local currency)

def order_points(pts):
    """
    Orders points as:
    top-left, top-right, bottom-right, bottom-left
    """
    _rect = np.zeros((4, 2), dtype="float32")

    s = pts.sum(axis=1)
    _rect[0] = pts[np.argmin(s)]
    _rect[2] = pts[np.argmax(s)]

    diff = np.diff(pts, axis=1)
    _rect[1] = pts[np.argmin(diff)]
    _rect[3] = pts[np.argmax(diff)]

    return _rect

def extract_distance_from_filename(filename: str) -> float:
    """
    Extracts the trailing numerical distance right before the file extension.
    Example: 'capture_dumpster_150.jpg' -> 150.0 cm
    """
    # Matches numbers directly preceding the file extension (e.g., _150.jpg or -150.png)
    match = re.search(r'[-_](\d+(?:\.\d+)?)\.[^.]+$', filename)
    if not match:
        raise HTTPException(
            status_code=400,
            detail="Filename must end with the distance in cm before the extension (e.g., photo_150.jpg)"
        )
    return float(match.group(1))


def calculate_focal_length_pixels(img_pil: Image.Image) -> float:
    """
    Extracts 35mm equivalent focal length from EXIF and converts it to pixels.
    Falls back to a standard smartphone calibration if EXIF data is stripped.
    """
    exif_data = img_pil._getexif()
    image_width = img_pil.width

    if exif_data:
        exif = {ExifTags.TAGS[k]: v for k, v in exif_data.items() if k in ExifTags.TAGS}
        focal_length_35mm = exif.get('FocalLengthIn35mmFilm')
        if focal_length_35mm:
            # Standard 35mm film sensor width is universally 36mm
            return (focal_length_35mm * image_width) / 36.0

    # Fallback default configuration if metadata is missing (mimics a standard 26mm lens layout)
    fallback_35mm_equiv = 26.0
    return (fallback_35mm_equiv * image_width) / 36.0


@app.post("/estimate-price")
async def estimate_waste_price(file: UploadFile = File(...)):
    # 1. Extract physical distance from the filename anchor
    known_distance_cm = extract_distance_from_filename(file.filename)

    # Read file content into memory bytes
    contents = await file.read()

    # 2. Process image with PIL for EXIF extraction
    try:
        from io import BytesIO
        pil_img = Image.open(BytesIO(contents))
        focal_length_pixels = calculate_focal_length_pixels(pil_img)
    except Exception:
        raise HTTPException(status_code=422, detail="Invalid image file format submitted.")

    # 3. Process image with OpenCV for Computer Vision geometry
    nparr = np.frombuffer(contents, np.uint8)
    frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    # Core Image Preprocessing Pipeline
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (7, 7), 0)
    edged = cv2.Canny(blurred, 50, 120)
    edged = cv2.dilate(edged, None, iterations=1)
    edged = cv2.erode(edged, None, iterations=1)

    # Detect contours to isolate the waste container/pile
    cnts = cv2.findContours(edged.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts = grab_contours(cnts)

    if not cnts:
        raise HTTPException(status_code=400, detail="Could not identify or isolate any waste structures in the image.")

    # Assume the target waste pile/bin is the largest foreground contour detected
    largest_contour = max(cnts, key=cv2.contourArea)

    # Compute the minimal oriented bounding box around the target
    rect = cv2.minAreaRect(largest_contour)
    box = cv2.boxPoints(rect)
    box = perspective.order_points(box)

    (tl, tr, br, bl) = box
    pixel_width = dist.euclidean((tl[0], tl[1]), (tr[0], tr[1]))
    pixel_height = dist.euclidean((tl[0], tl[1]), (bl[0], bl[1]))

    # 4. Geometry execution via the Pinhole Camera Model
    real_width_cm = (pixel_width * known_distance_cm) / focal_length_pixels
    real_height_cm = (pixel_height * known_distance_cm) / focal_length_pixels

    # 5. Volume Estimation Engine
    # Approximating the trash heap/bin volume as a basic cylinder: Volume = pi * r^2 * h
    radius_cm = real_width_cm / 2.0
    estimated_volume_cubic_cm = math.pi * (radius_cm ** 2) * real_height_cm
    estimated_volume_liters = estimated_volume_cubic_cm / 1000.0

    # 6. Price Valuation Engine Calculation
    calculated_price = (estimated_volume_cubic_cm * RATE_PER_CUBIC_CM) + BASE_FEE
    rounded_price = round(calculated_price, -2)  # Round to nearest 100 currency units

    return {
        "status": "success",
        "input_metadata": {
            "parsed_filename": file.filename,
            "extracted_distance_cm": float(known_distance_cm),
            "calculated_focal_length_px": round(float(focal_length_pixels), 2)
        },
        "computed_dimensions": {
            "real_width_cm": round(float(real_width_cm), 2),
            "real_height_cm": round(float(real_height_cm), 2),
            "estimated_volume_liters": round(float(estimated_volume_liters), 2)
        },
        "valuation": {
            "currency_base_fee": float(BASE_FEE),
            "estimated_total_price": float(rounded_price)
        }
    }

@app.post("/ai/estimate-price")
async def estimate_waste_price(file: UploadFile = File(...)):
    # 1. Extract physical distance from the filename anchor
    known_distance_cm = extract_distance_from_filename(file.filename)

    # Read file content into memory bytes
    contents = await file.read()

    # 2. Process image with PIL for EXIF extraction
    try:
        from io import BytesIO
        pil_img = Image.open(BytesIO(contents))
        focal_length_pixels = calculate_focal_length_pixels(pil_img)
    except Exception:
        raise HTTPException(status_code=422, detail="Invalid image file format submitted.")

    nparr = np.frombuffer(contents, np.uint8)
    frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    if frame is None:
        raise ValueError(f"Could not read image")

    results = model(frame, verbose=False)

    candidate_contours = []
    candidate_info = []

    for result in results:
        if result.masks is None or result.boxes is None:
            continue

        names = result.names

        for mask_xy, box, cls, conf in zip(
                result.masks.xy,
                result.boxes.xyxy,
                result.boxes.cls,
                result.boxes.conf
        ):
            class_id = int(cls)
            class_name = names[class_id]
            confidence = float(conf)

            contour = np.array(mask_xy, dtype=np.int32)

            if contour.ndim != 2 or contour.shape[0] < 3:
                continue

            area = cv2.contourArea(contour)

            candidate_contours.append(contour)
            candidate_info.append(
                {
                    "class_id": class_id,
                    "class_name": class_name,
                    "confidence": confidence,
                    "area": area,
                }
            )

    print("YOLO segmented objects found:", len(candidate_contours))

    for i, info in enumerate(candidate_info):
        print(
            f"{i}: class={info['class_name']} "
            f"id={info['class_id']} "
            f"confidence={info['confidence']:.2f} "
            f"area={info['area']:.2f}"
        )

    if not candidate_contours:
        raise ValueError(
            "YOLO did not return any segmentation masks. "
            "Try a custom YOLO segmentation model trained for waste/bin objects."
        )

    # Pick the largest segmented object.
    # This is safer than class_id == 56 because COCO does not contain a true waste/bin class.
    best_index = int(np.argmax([info["area"] for info in candidate_info]))
    largest_contour = candidate_contours[best_index]
    best_info = candidate_info[best_index]

    print("Selected object:", best_info)

    rects = []
    boxes = []
    boxes_1 = []
    for contour in candidate_contours:
        rect = cv2.minAreaRect(contour)
        rects.append(rect)
        box = cv2.boxPoints(rect)
        boxes.append(cv2.boxPoints(rect))
        boxes_1.append(order_points(np.array(box, dtype="float32")))

    contour_view = frame.copy()
    overlay = contour_view.copy()
    d = 0
    for contour in candidate_contours:

        # Draw filled transparent mask
        cv2.drawContours(contour_view, [contour], -1, (0, 255, 0), thickness=cv2.FILLED)
        contour_view = cv2.addWeighted(overlay, 0.25, contour_view, 0.75, 0)
        # Draw exact YOLO segmentation contour
        cv2.drawContours(contour_view, [contour], -1, (0, 255, 0), 5)
        # Draw a minimum rotated bounding box
        cv2.drawContours(contour_view, [boxes_1[d].astype("int")], -1, (255, 0, 0), 5)

        # Draw corner points
        for i, point in enumerate(boxes_1[d]):
            x, y = point.astype("int")
            cv2.circle(contour_view, (x, y), 10, (0, 0, 255), -1)
            cv2.putText(
                contour_view,
                str(i),
                (x + 15, y - 15),
                cv2.FONT_HERSHEY_SIMPLEX,
                1.2,
                (0, 0, 255),
                3
            )

        label = f"{candidate_info[d]['class_name']} {candidate_info[d]['confidence']:.2f}"
        x, y = contour.reshape(-1, 2).min(axis=0)
        d += 1

        cv2.putText(
            contour_view,
            label,
            (int(x), max(int(y) - 20, 40)),
            cv2.FONT_HERSHEY_SIMPLEX,
            1.4,
            (0, 255, 0),
            4
        )

    total_price = 0
    computed_dimensions = []
    for box in boxes_1:
        tl, tr, br, bl = box

        pixel_width = dist.euclidean((tl[0], tl[1]), (tr[0], tr[1]))
        pixel_height = dist.euclidean((tl[0], tl[1]), (bl[0], bl[1]))

        real_width_cm = (pixel_width * known_distance_cm) / focal_length_pixels
        real_height_cm = (pixel_height * known_distance_cm) / focal_length_pixels

        radius_cm = real_width_cm / 2.0

        estimated_volume_cubic_cm = math.pi * (radius_cm ** 2) * real_height_cm
        estimated_volume_liters = estimated_volume_cubic_cm / 1000.0

        # FIX: Explicitly cast to native Python float types using float() here
        computed_dimensions.append({
            'real_width_cm': round(float(real_width_cm), 2),
            'real_height_cm': round(float(real_height_cm), 2),
            'estimated_volume_litre': round(float(estimated_volume_liters), 2)
        })

        calculated_price = (estimated_volume_cubic_cm * RATE_PER_CUBIC_CM)
        total_price += calculated_price

    # Apply base fee outside the loop if it represents a flat fee per order
    final_rounded_price = round(float(total_price + BASE_FEE), -2)

    print("Base fee:", BASE_FEE)
    print("Raw calculated price:", round(float(total_price), 2))
    print("Rounded price:", final_rounded_price)

    return {
        "status": "success",
        "input_metadata": {
            "parsed_filename": file.filename,
            "extracted_distance_cm": float(known_distance_cm),
            "calculated_focal_length_px": round(float(focal_length_pixels), 2)
        },
        "computed_dimensions": computed_dimensions,
        "valuation": {
            "currency_base_fee": float(BASE_FEE),
            "estimated_total_price": final_rounded_price  # Using the rounded value
        }
    }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)