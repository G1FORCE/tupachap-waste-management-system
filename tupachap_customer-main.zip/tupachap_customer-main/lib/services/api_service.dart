import 'dart:io';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:http_parser/http_parser.dart';
import 'dart:async';

/// ApiService for Tupachap Waste Management System
/// This client facilitates communication between the mobile apps and the backend.
class ApiService {
  static const String baseUrl = "https://api.tupachap.click";
  static const String mlVisionUrl = "https://ai.tupachap.click";

  String get _wsBaseUrl => baseUrl.replaceFirst('https://', 'wss://').replaceFirst('http://', 'ws://');

  // ==========================================
  // AUTHENTICATION
  // ==========================================

  /// Register a new customer
  Future<bool> registerCustomer({
    required String firstName,
    required String lastName,
    required String phoneNumber,
    required String password,
    required String customerType,
    required double latitude,
    required double longitude,
  }) async {
    var url = Uri.parse('$baseUrl/api/auth/register/customer');
    var response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'first_name': firstName,
        'last_name': lastName,
        'phone_number': phoneNumber,
        'password': password,
        'customer_type': customerType,
        'lat': latitude,
        'lon': longitude,
      }),
    );
    print("response: ${response.body}");
    return response.statusCode >= 200 && response.statusCode < 300;
  }

  /// Login and receive access token
  /// Backend expects OAuth2 form data (username, password)
  Future<AccessCredentials> login(String phoneNumber, String password) async {
    var url = Uri.parse('$baseUrl/api/auth/login');
    var response = await http.post(
      url,
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: {
        'username': phoneNumber,
        'password': password,
      },
    );

    if (response.statusCode != 200) {
      final errorData = jsonDecode(response.body);
      throw Exception(errorData['detail'] ?? 'Login failed');
    }

    final data = jsonDecode(response.body);

    return AccessCredentials(
      accessToken: data['access_token'],
      tokenType: data['token_type'] ?? 'bearer',
      role: data['role'] ?? 'CUSTOMER',
    );
  }

  // ==========================================
  // CUSTOMER PROFILE & CONTRACTS
  // ==========================================

  /// Set up or update customer profile
  Future<void> setupProfile(String token, {
    required String customerType,
    required double lat,
    required double lon,
  }) async {
    var url = Uri.parse('$baseUrl/contract/setup');
    var response = await http.post(
      url,
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'customer_type': customerType,
        'lat': lat,
        'lon': lon,
      }),
    );

    if (response.statusCode != 200) {
      throw Exception('Failed to setup profile: ${response.body}');
    }
  }

  Future<void> updateProfile(String token, Map<String, String> profileData, {
    required double lat,
    required double lon,
  }) async {
    var url = Uri.parse('$baseUrl/customers/profile');
    var response = await http.patch(
      url,
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'first_name': profileData['first_name'],
        'last_name': profileData['last_name'],
        'lon': lon,
        'lat': lat,
        'phone_number': profileData['phone_number'],
      }),
    );

    if (response.statusCode != 200) {
      throw Exception('Failed to update profile: ${response.body}');
    }
  }


  /// Subscribe to a waste collection contract
  Future<Map<String, dynamic>> subscribe(String token, {
    required String billingCycle,
    required String startDate,
    required String endDate,
    required int pickupDay,
  }) async {
    var url = Uri.parse('$baseUrl/contract/subscribe');
    var response = await http.post(
      url,
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'billing_cycle': billingCycle,
        'start_date': startDate,
        'end_date': endDate,
        'pickup_day': pickupDay,
      }),
    );

    if (response.statusCode != 200) {
      throw Exception('Subscription failed: ${response.body}');
    }
    return jsonDecode(response.body);
  }

  /// Get current subscription contract
  Future<Map<String, dynamic>> getCurrentContract(String token) async {
    var url = Uri.parse('$baseUrl/contract/contract');
    var response = await http.get(
      url,
      headers: {'Authorization': 'Bearer $token'},
    );

    if (response.statusCode != 200) {
      throw Exception('Failed to fetch contract');
    }
    print(jsonDecode(response.body)['data']);
    return jsonDecode(response.body)['data'];
  }

  /// Get the customer profile (including Customer ID) from the logged-in User
  Future<Map<String, dynamic>> getCustomerProfile(String token) async {
    var url = Uri.parse('$baseUrl/customers/profile');
    var response = await http.get(
      url,
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
    );

    if (response.statusCode != 200) {
      throw Exception('Failed to get customer profile: ${response.body}');
    }

    return jsonDecode(response.body);
  }

  // ==========================================
  // TRIPS & IMMEDIATE PICKUPS
  // ==========================================

  /// Request an immediate pickup
  Future<Map<String, dynamic>> requestImmediateTrip(String token, {
    required double lat,
    required double lon,
    required List<String> wasteClass,
    double imageEstimatedPrice = 0.0,
    List<String>? estimationImageUrl,
  }) async {
    var url = Uri.parse('$baseUrl/trips/request-immediate');
    var response = await http.post(
      url,
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'lat': lat,
        'lon': lon,
        'waste_class': wasteClass,
        'image_estimated_price': imageEstimatedPrice,
        'estimation_image_url': estimationImageUrl,
      }),
    );

    if (response.statusCode != 200) {
      throw Exception('Failed to request trip: ${response.body}');
    }
    return jsonDecode(response.body)['data']['trip'];
  }

  /// Get status of a specific trip
  Future<Map<String, dynamic>> getTripStatus(String token, String tripId) async {
    var url = Uri.parse('$baseUrl/trips/$tripId/status');
    var response = await http.get(
      url,
      headers: {'Authorization': 'Bearer $token'},
    );

    if (response.statusCode != 200) {
      throw Exception('Failed to get trip status');
    }
    return jsonDecode(response.body)['data'];
  }

  /// List customer's trips
  Future<List<dynamic>> listMyTrips(String token, {int limit = 20, int offset = 0}) async {
    var url = Uri.parse('$baseUrl/customers/trips?limit=$limit&offset=$offset');
    var response = await http.get(
      url,
      headers: {'Authorization': 'Bearer $token'},
    );
    print(jsonDecode(response.body));
    if (response.statusCode != 200) {
      throw Exception('Failed to list trips');
    }

    return jsonDecode(response.body)['data'];
  }

  /// Cancel a requested trip (before driver accepts)
  Future<void> cancelTrip(String token, String tripId) async {
    var url = Uri.parse('$baseUrl/customers/trips/$tripId/cancel');
    var response = await http.patch(
      url,
      headers: {'Authorization': 'Bearer $token'},
    );

    if (response.statusCode != 200) {
      throw Exception('Failed to cancel trip: ${response.body}');
    }
  }

  // ==========================================
  // PAYMENTS
  // ==========================================

  /// Initiate Mobile Money payment for a trip
  Future<Map<String, dynamic>> initiateTripPayment(String token, {
    required String tripId,
    required double amount,
    required String phoneNumber,
  }) async {
    var url = Uri.parse('$baseUrl/payments/initiate/trip');
    var response = await http.post(
      url,
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'trip_id': tripId,
        'amount': amount,
        'phone_number': phoneNumber,
        'contract_id':''
      }),
    );

    if (response.statusCode != 200) {
      throw Exception('Payment initiation failed: ${response.body}');
    }
    return jsonDecode(response.body);
  }

  /// Initiate Mobile Money payment for a subscription contract
  Future<Map<String, dynamic>> initiateContractPayment(String token, {
    required String contractId,
    required double amount,
    required String phoneNumber,
  }) async {
    var url = Uri.parse('$baseUrl/payments/initiate/contract');
    var response = await http.post(
      url,
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'contract_id': contractId,
        'amount': amount,
        'phone_number': phoneNumber,
        'trip_id': ''
      }),
    );

    if (response.statusCode != 200) {
      throw Exception('Contract payment initiation failed: ${response.body}');
    }
    return jsonDecode(response.body);
  }

  // ==========================================
  // AI & VISION (EXTERNAL)
  // ==========================================

  /// Use AI to estimate waste price from a photo
  Future<Map<String, dynamic>> estimateWastePrice(File imageFile) async {
    var url = Uri.parse('$mlVisionUrl/ai/estimate-price');
    var request = http.MultipartRequest('POST', url);
    request.files.add(await http.MultipartFile.fromPath(
      'file',
      imageFile.path,
      filename:  'IMG_200.jpeg',
      contentType: MediaType('image', 'jpeg'),
    ));

    var streamedResponse = await request.send();
    var response = await http.Response.fromStream(streamedResponse);

    if (response.statusCode != 200) {
      throw Exception('Failed to estimate waste price');
    }
    return jsonDecode(response.body);
  }
  // ==========================================
  // WASTEPICKER WORKFLOW
  // ==========================================

  /// Wastepicker: Get personal stats (earnings, trip counts, history)
  Future<Map<String, dynamic>> getWastepickerStats(String token) async {
    var url = Uri.parse('$baseUrl/api/analytics/wastepicker/me');
    var response = await http.get(
      url,
      headers: {'Authorization': 'Bearer $token'},
    );

    if (response.statusCode != 200) {
      throw Exception('Failed to get wastepicker stats: ${response.body}');
    }
    return jsonDecode(response.body);
  }

  /// Wastepicker: Scan the customer's QR code to start the trip
  /// Transitions status to IN_TRANSIT
  Future<Map<String, dynamic>> scanTripQR(String token, String tripId, String qrHash) async {
    var url = Uri.parse('$baseUrl/trips/$tripId/scan-qr');
    var response = await http.post(
      url,
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({'qr_hash': qrHash}),
    );

    if (response.statusCode != 200) {
      throw Exception('Failed to verify QR code: ${response.body}');
    }
    return jsonDecode(response.body);
  }

  /// Wastepicker: Upload proof of service photos
  /// mobile app should upload files to storage (Cloudinary/S3) first
  Future<Map<String, dynamic>> updateTripPics(String token, String tripId, {
    List<String>? estimationPics,
    List<String>? pickupPics,
    List<String>? dumpsitePics,
  }) async {
    var url = Uri.parse('$baseUrl/trips/$tripId/pics');
    var response = await http.patch(
      url,
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        if (estimationPics != null) 'estimation_pics': estimationPics,
        if (pickupPics != null) 'pickup_pics': pickupPics,
        if (dumpsitePics != null) 'dumpsite_pics': dumpsitePics,
      }),
    );

    if (response.statusCode != 200) {
      throw Exception('Failed to update trip pictures: ${response.body}');
    }
    return jsonDecode(response.body);
  }

  /// Wastepicker: Complete the trip after disposal
  Future<Map<String, dynamic>> completeTrip(String token, String tripId) async {
    var url = Uri.parse('$baseUrl/trips/$tripId/complete');
    var response = await http.post(
      url,
      headers: {'Authorization': 'Bearer $token'},
    );

    if (response.statusCode != 200) {
      throw Exception('Failed to complete trip: ${response.body}');
    }
    return jsonDecode(response.body);
  }

  // ==========================================
  // WEBSOCKETS (REAL-TIME TRACKING)
  // ==========================================

  /// Customer: Track a driver's live location for a trip
  WebSocketChannel trackTrip(String tripId, String token) {
    final wsUrl = Uri.parse('$_wsBaseUrl/api/ws/customer/$tripId?token=$token');
    return WebSocketChannel.connect(wsUrl);
  }

  /// Waste Picker: Publish live location for a trip
  WebSocketChannel publishLocation(String tripId, String token) {
    final wsUrl = Uri.parse('$_wsBaseUrl/api/ws/driver/$tripId?token=$token');
    return WebSocketChannel.connect(wsUrl);
  }

  /// Waste picker: Broadcast location to the WebSocket channel
  void sendLocationUpdate(WebSocketChannel channel, {
    required double lat,
    required double lon,
    double heading = 0,
    double speed = 0,
  }) {
    channel.sink.add(jsonEncode({
      'lat': lat,
      'lon': lon,
      'heading': heading,
      'speed': speed,
    }));
  }
}

// ==========================================
// MODELS
// ==========================================

class AccessCredentials {
  final String accessToken;
  final String tokenType;
  final String role;

  AccessCredentials({
    required this.accessToken,
    required this.tokenType,
    required this.role,
  });
}

class UserProfile {
  final String id;
  final String firstName;
  final String lastName;
  final String phoneNumber;
  final String role;

  UserProfile({
    required this.id,
    required this.firstName,
    required this.lastName,
    required this.phoneNumber,
    required this.role,
  });

  factory UserProfile.fromJson(Map<String, dynamic> json) {
    return UserProfile(
      id: json['id'] ?? '',
      firstName: json['first_name'] ?? '',
      lastName: json['last_name'] ?? '',
      phoneNumber: json['phone_number'] ?? '',
      role: json['customer_type'] ?? 'CUSTOMER',
    );
  }
}
