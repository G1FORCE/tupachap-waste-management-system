import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';
import 'package:firebase_core/firebase_core.dart';
import 'screens/splash_screen.dart';
import 'constants.dart';
import 'services/api_service.dart';

final locator = GetIt.instance;

void setupLocator() {
  locator.registerLazySingleton(() => ApiService());
}

void main() async {try {
  WidgetsFlutterBinding.ensureInitialized();

  // Add options if you are using FlutterFire CLI,
  // otherwise the default call is fine for manual setup
  await Firebase.initializeApp();

  setupLocator();
  runApp(const MyApp());
} catch (e) {
  debugPrint("Firebase Initialization Error: $e");
  // You can still run the app here, but Firebase features will fail
  runApp(const MyApp());
}
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TupaChap',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: kPrimaryColor),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: const SplashScreen(),
    );
  }
}
