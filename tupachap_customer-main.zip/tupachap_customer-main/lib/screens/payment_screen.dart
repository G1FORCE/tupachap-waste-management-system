import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'dart:async';
import '../constants.dart';
import '../widgets/logo_header.dart';
import '../main.dart';
import '../services/api_service.dart';
import 'trip_tracking_screen.dart';
import 'contract_details_screen.dart';

class PaymentScreen extends StatefulWidget {
  final double amount;
  final String requestId; // This is either tripId or contractId
  final String wasteCategory;
  final LatLng pickupLocation;
  final bool isSubscription;
  final String qr_code_hash;

  const PaymentScreen({
    super.key,
    required this.amount,
    required this.requestId,
    required this.wasteCategory,
    required this.pickupLocation,
    this.isSubscription = false,
    required this.qr_code_hash,
  });

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  final TextEditingController _phoneController = TextEditingController();
  final _storage = const FlutterSecureStorage();
  bool _isProcessing = false;
  String _statusMessage = 'Initiating payment...';
  Timer? _statusTimer;

  @override
  void dispose() {
    _statusTimer?.cancel();
    _phoneController.dispose();
    super.dispose();
  }

  void _startPayment() async {
    if (_phoneController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a mobile number')),
      );
      return;
    }

    String phone = _phoneController.text.trim();
    // Validate phone number format (should be Tanzania format like 07XXXXXXXX or 255XXXXXXXXX)
    if (!RegExp(r'^(0|255)[67]\d{8}$').hasMatch(phone)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid phone number (07XXXXXXXX or 255XXXXXXXXX)')),
      );
      return;
    }

    if (phone.startsWith('0')) {
      phone = '255${phone.substring(1)}';
    }

    setState(() {
      _isProcessing = true;
      _statusMessage = 'Sending payment request to $phone...';
    });

    try {
      final token = await _storage.read(key: 'auth_token');
      if (token == null) throw Exception('Session expired. Please login again.');

      final apiService = locator<ApiService>();

      // Call the appropriate endpoint based on payment type
      if (widget.isSubscription) {
        await apiService.initiateContractPayment(
          token,
          contractId: widget.requestId,
          amount: widget.amount,
          phoneNumber: phone,
        );
      } else {
        await apiService.initiateTripPayment(
          token,
          tripId: widget.requestId,
          amount: widget.amount,
          phoneNumber: phone,
        );
      }

      int pollCount = 0;
      const maxPolls = 60; // 5 minutes (60 * 5 seconds)

      if (mounted) {
        setState(() {
          _statusMessage = 'Please complete the payment on your phone...';
        });
      }

      // Start polling for confirmation
      _statusTimer = Timer.periodic(const Duration(seconds: 5), (timer) async {
        pollCount++;
        
        if (pollCount > maxPolls) {
          timer.cancel();
          if (mounted) {
            setState(() => _isProcessing = false);
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Payment confirmation timeout. Please check your status later.')),
            );
          }
          return;
        }

        try {
          if (widget.isSubscription) {
             // For subscriptions, poll for active contract status
             final contractData = await apiService.getCurrentContract(token);
             final status = (contractData['contract_status'] ?? '').toString().toUpperCase();
             if (status == 'ACTIVE') {
                _handleSuccess(timer);
             }
          } else {
            // For immediate trips, poll for accepted/in-transit/completed status
            final tripData = await apiService.getTripStatus(token, widget.requestId);
            final status = (tripData['status'] ?? '').toString().toUpperCase();
            
            if (['ACCEPTED', 'IN_TRANSIT', 'ARRIVING', 'COMPLETED'].contains(status)) {
               _handleSuccess(timer);
            } else if (['CANCELLED', 'REJECTED'].contains(status)) {
              if (mounted) {
                setState(() {
                  _statusMessage = 'Payment failed or request was rejected.';
                  _isProcessing = false;
                });
              }
              timer.cancel();
            }
          }
        } catch (e) {
          debugPrint('Error checking status: $e');
        }
      });

    } catch (e) {
      if (mounted) {
        setState(() => _isProcessing = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Payment Error: ${e.toString()}')),
        );
      }
    }
  }

  void _handleSuccess(Timer timer) {
    if (mounted) {
      setState(() {
        _statusMessage = 'Payment Confirmed!';
      });
      timer.cancel();
      _onPaymentSuccess();
    }
  }

  void _onPaymentSuccess() {
    Timer(const Duration(seconds: 2), () {
      if (mounted) {
        if (widget.isSubscription) {
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (context) => const ContractDetailsScreen()),
            (route) => route.isFirst,
          );
        } else {
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(
              builder: (context) => TripTrackingScreen(
                requestId: widget.requestId,
                qr_code_hash: widget.qr_code_hash,
                wasteCategory: widget.wasteCategory,
                pickupLocation: widget.pickupLocation,
                estimatedAmount: widget.amount,
              ),
            ),
            (route) => route.isFirst,
          );
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kPrimaryColor,
      body: Column(
        children: [
          const LogoHeader(isDark: true),
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(32),
                  topRight: Radius.circular(32),
                ),
              ),
              child: _isProcessing ? _buildWaitingUI() : _buildInputUI(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputUI() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          widget.isSubscription ? 'Setup Subscription' : 'Immediate Pickup', 
          style: kHeadingStyle
        ),
        const SizedBox(height: 8),
        Text(
          widget.isSubscription 
            ? 'Complete payment to activate your regular pickup schedule.'
            : 'Complete payment to request an immediate pickup.',
          style: TextStyle(color: Colors.grey.shade600, fontSize: 14),
        ),
        const SizedBox(height: 40),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.grey.shade50,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.grey.shade100),
          ),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Total Amount', style: TextStyle(fontWeight: FontWeight.w500)),
                  Text(
                    'TZS ${widget.amount.toStringAsFixed(0)}',
                    style: const TextStyle(fontWeight: FontWeight.w900, color: kPrimaryColor, fontSize: 20),
                  ),
                ],
              ),
              const Divider(height: 32),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(widget.isSubscription ? 'Subscription Type' : 'Waste Category', 
                    style: const TextStyle(fontSize: 12, color: Colors.grey)),
                  Expanded(
                    child: Text(
                      widget.wasteCategory, 
                      textAlign: TextAlign.end,
                      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 32),
        const Text(
          'Mobile Money Number',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: _phoneController,
          keyboardType: TextInputType.phone,
          style: const TextStyle(fontSize: 18, letterSpacing: 1.5, fontWeight: FontWeight.bold),
          decoration: kInputDecoration('07XXXXXXXX').copyWith(
            prefixIcon: const Icon(Icons.phone_iphone_rounded, color: kPrimaryColor),
          ),
        ),
        const Spacer(),
        SizedBox(
          width: double.infinity,
          height: 56,
          child: ElevatedButton(
            onPressed: _startPayment,
            style: ElevatedButton.styleFrom(
              backgroundColor: kPrimaryColor,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              elevation: 0,
            ),
            child: const Text('Pay Now', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          ),
        ),
        const SizedBox(height: 12),
        Center(
          child: TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: Colors.grey.shade600)),
          ),
        ),
      ],
    );
  }

  Widget _buildWaitingUI() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const SizedBox(
            width: 80,
            height: 80,
            child: CircularProgressIndicator(
              color: kPrimaryColor,
              strokeWidth: 6,
              strokeCap: StrokeCap.round,
            ),
          ),
          const SizedBox(height: 40),
          Text(
            _statusMessage,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: kSecondaryColor),
          ),
          const SizedBox(height: 16),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 40.0),
            child: Text(
              'Please check your phone and enter your mobile money PIN to complete the transaction.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey, fontSize: 14),
            ),
          ),
          if (_statusMessage == 'Payment Confirmed!') ...[
            const SizedBox(height: 32),
            const Icon(Icons.check_circle_rounded, color: kPrimaryColor, size: 64),
          ],
        ],
      ),
    );
  }
}
