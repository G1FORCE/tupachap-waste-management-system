import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'dart:math' as math;
import '../constants.dart';
import '../main.dart';
import '../services/api_service.dart';
import '../widgets/logo_header.dart';
import 'trip_tracking_screen.dart';

class ActiveRequestsScreen extends StatefulWidget {
  const ActiveRequestsScreen({super.key});

  @override
  State<ActiveRequestsScreen> createState() => _ActiveRequestsScreenState();
}

class _ActiveRequestsScreenState extends State<ActiveRequestsScreen> {
  final _storage = const FlutterSecureStorage();
  List<dynamic> _activeRequests = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadActiveRequests();
  }

  Future<void> _loadActiveRequests() async {
    try {
      final token = await _storage.read(key: 'auth_token');

      if (token != null) {
        // Changed from getRequests(creds) to listMyTrips(token)
        final requests = await locator<ApiService>().listMyTrips(token);
        
        setState(() {
          // Filter for active requests only
          _activeRequests = requests.where((req) => 
            req['status'] == 'REQUESTED' || 
            req['status'] == 'ACCEPTED' || 
            req['status'] == 'IN_TRANSIT' ||
            req['status'] == 'ARRIVING'
          ).toList();
          
          _isLoading = false;
        });
      }
    } catch (e) {
      debugPrint('Error loading active requests: $e');
      setState(() => _isLoading = false);
    }
  }

  String _getCategoryDisplay(String category) {
    const categoryMap = {
      'HOUSEHOLD': 'Household',
      'RECYCLABLE': 'Recyclables',
      'BULKY': 'Bulky',
    };
    return categoryMap[category] ?? category;
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'REQUESTED':
        return Colors.grey;
      case 'ACCEPTED':
        return Colors.blue;
      case 'IN_TRANSIT':
        return Colors.orange;
      case 'ARRIVING':
        return Colors.green;
      case 'COMPLETED':
        return Colors.teal;
      case 'REJECTED':
      case 'CANCELLED':
        return Colors.red;
      default:
        return kPrimaryColor;
    }
  }

  String _getStatusText(String status) {
    switch (status) {
      case 'REQUESTED':
        return 'Requested';
      case 'ACCEPTED':
        return 'Driver Accepted';
      case 'IN_TRANSIT':
        return 'In Transit';
      case 'ARRIVING':
        return 'Arriving Soon';
      case 'COMPLETED':
        return 'Completed';
      case 'REJECTED':
        return 'Rejected';
      case 'CANCELLED':
        return 'Cancelled';
      default:
        return status;
    }
  }

  String _formatTime(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);

    if (difference.inMinutes < 1) {
      return 'Just now';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inDays}d ago';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kPrimaryColor,
      body: Column(
        children: [
          const LogoHeader(isDark: true),
          Expanded(
            child: Container(
              margin: const EdgeInsets.only(top: 10),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(32),
                  topRight: Radius.circular(32),
                ),
              ),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Active Requests',
                          style: kHeadingStyle.copyWith(fontSize: 22),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Track your waste collection requests',
                          style: TextStyle(
                            color: Colors.grey.shade600,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: _isLoading
                        ? const Center(
                            child: CircularProgressIndicator(color: kPrimaryColor),
                          )
                        : _activeRequests.isEmpty
                            ? Center(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.inbox_rounded,
                                      size: 64,
                                      color: Colors.grey.shade300,
                                    ),
                                    const SizedBox(height: 16),
                                    Text(
                                      'No active requests',
                                      style: TextStyle(
                                        fontSize: 16,
                                        color: Colors.grey.shade600,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                ),
                              )
                            : ListView.builder(
                                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                itemCount: _activeRequests.length,
                                itemBuilder: (context, index) {
                                  final request = _activeRequests[index];
                                  return _buildRequestCard(context, request);
                                },
                              ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRequestCard(BuildContext context, dynamic request) {
    final requestId = request['trip_id'] ?? 'Unknown';
    final status = request['status'] ?? 'PENDING';
    final category = request['waste_class'].toString() ?? 'UNKNOWN';
    final createdAt = DateTime.tryParse(request['created_at'] ?? '')?.toLocal() ?? DateTime.now();
    final amount = request['fare_tzs'] != null? (request['fare_tzs']).toDouble() : 0.0;
    
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => TripTrackingScreen(
              qr_code_hash: request['qr_hash'] ?? 'null',
              requestId: requestId,
              wasteCategory: _getCategoryDisplay(category),
              pickupLocation: const LatLng(-6.7924, 39.2083),
              estimatedAmount: amount,
            ),
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: kPrimaryColor,
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: kPrimaryColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    category == 'HOUSEHOLD'
                        ? Icons.home_work_rounded
                        : category == 'RECYCLABLE'
                            ? Icons.eco_rounded
                            : Icons.unarchive_rounded,
                    color: kPrimaryColor,
                    size: 24,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        requestId.substring(0, math.min(8, requestId.length)),
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        _getCategoryDisplay(category),
                        style: TextStyle(
                          fontSize: 13,
                          color: Colors.grey.shade600,
                        ),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: _getStatusColor(status).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        _getStatusText(status),
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          color: _getStatusColor(status),
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'TZS ${amount.toStringAsFixed(0)}',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kPrimaryColor,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
