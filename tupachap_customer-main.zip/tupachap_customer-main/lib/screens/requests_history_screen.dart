import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:tupachap_customer/screens/payment_screen.dart';
import 'dart:math' as math;
import '../constants.dart';
import '../main.dart';
import '../services/api_service.dart';
import '../widgets/logo_header.dart';
import 'trip_tracking_screen.dart';

class RequestsHistoryScreen extends StatefulWidget {
  const RequestsHistoryScreen({super.key});

  @override
  State<RequestsHistoryScreen> createState() => _RequestsHistoryScreenState();
}

class _RequestsHistoryScreenState extends State<RequestsHistoryScreen> {
  final _storage = const FlutterSecureStorage();
  List<dynamic> _activeRequests = [];
  List<dynamic> _pastRequests = [];
  bool _isLoading = true;
  int _selectedTab = 0; // 0: Active, 1: Past

  @override
  void initState() {
    super.initState();
    _loadRequests();
  }

  Future<void> _loadRequests() async {
    try {
      final token = await _storage.read(key: 'auth_token');

      if (token != null) {
        // Updated to use listMyTrips(token) as getRequests(creds) is removed
        final requests = await locator<ApiService>().listMyTrips(token);
        
        setState(() {
          // Separate active and past requests
          _activeRequests = requests.where((req) => 
            req['status'] == 'REQUESTED' || 
            req['status'] == 'ACCEPTED' || 
            req['status'] == 'IN_TRANSIT' ||
            req['status'] == 'ARRIVING' ||
            req['status'] == 'PENDING_PAYMENT'
          ).toList();
          
          _pastRequests = requests.where((req) => 
            req['status'] == 'COMPLETED' || 
            req['status'] == 'REJECTED' ||
            req['status'] == 'CANCELLED'
          ).toList();
          
          _isLoading = false;
        });
      }
    } catch (e) {
      debugPrint('Error loading requests: $e');
      setState(() => _isLoading = false);
    }
  }

  String _getCategoryDisplay(String category) {
    const categoryMap = {
      'HOUSEHOLD': 'Household',
      'RECYCLABLE': 'Recyclables',
      'BULKY': 'Bulky',
    };
    return categoryMap[category] ?? category;
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'PENDING_PAYMENT':
        return Colors.yellow;
      case 'REQUESTED':
        return Colors.grey;
      case 'ACCEPTED':
        return Colors.blue;
      case 'IN_TRANSIT':
        return Colors.orange;
      case 'ARRIVING':
        return Colors.green;
      case 'COMPLETED':
        return Colors.teal;
      case 'REJECTED':
      case 'CANCELLED':
        return Colors.red;
      default:
        return kPrimaryColor;
    }
  }

  String _getStatusText(String status) {
    switch (status) {
      case 'PENDING_PAYMENT':
        return 'Pending Payment';
      case 'REQUESTED':
        return 'Requested';
      case 'ACCEPTED':
        return 'Driver Accepted';
      case 'IN_TRANSIT':
        return 'In Transit';
      case 'ARRIVING':
        return 'Arriving Soon';
      case 'COMPLETED':
        return 'Completed';
      case 'REJECTED':
        return 'Rejected';
      case 'CANCELLED':
        return 'Cancelled';
      default:
        return status;
    }
  }

  String _formatTime(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);

    if (difference.inMinutes < 1) {
      return 'Just now';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inDays}d ago';
    }
  }

  bool _isRequestTrackable(String status) {
    return status == 'ACCEPTED' || status == 'IN_TRANSIT' || status == 'ARRIVING';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kPrimaryColor,
      body: Column(
        children: [
          const LogoHeader(isDark: true),
          Expanded(
            child: Container(
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(32),
                  topRight: Radius.circular(32),
                ),
              ),
              child: _isLoading
                  ? const Center(
                      child: CircularProgressIndicator(color: kPrimaryColor),
                    )
                  : Column(
                      children: [
                        // Header
                        Padding(
                          padding: const EdgeInsets.all(24),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Your Requests',
                                style: kHeadingStyle.copyWith(fontSize: 22),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'Track your waste collection requests',
                                style: TextStyle(
                                  color: Colors.grey.shade600,
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                        ),
                        // Tab selector
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 24),
                          child: Row(
                            children: [
                              Expanded(
                                child: GestureDetector(
                                  onTap: () => setState(() => _selectedTab = 0),
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(vertical: 12),
                                    decoration: BoxDecoration(
                                      border: Border(
                                        bottom: BorderSide(
                                          color: _selectedTab == 0 ? kPrimaryColor : Colors.transparent,
                                          width: 3,
                                        ),
                                      ),
                                    ),
                                    child: Column(
                                      children: [
                                        Text(
                                          'Active',
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 15,
                                            color: _selectedTab == 0 ? kPrimaryColor : Colors.grey.shade500,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              Expanded(
                                child: GestureDetector(
                                  onTap: () => setState(() => _selectedTab = 1),
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(vertical: 12),
                                    decoration: BoxDecoration(
                                      border: Border(
                                        bottom: BorderSide(
                                          color: _selectedTab == 1 ? kPrimaryColor : Colors.transparent,
                                          width: 3,
                                        ),
                                      ),
                                    ),
                                    child: Column(
                                      children: [
                                        Text(
                                          'History',
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 15,
                                            color: _selectedTab == 1 ? kPrimaryColor : Colors.grey.shade500,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                        // Request list
                        Expanded(
                          child: _selectedTab == 0
                              ? _activeRequests.isEmpty
                                  ? Center(
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Icon(
                                            Icons.inbox_rounded,
                                            size: 64,
                                            color: Colors.grey.shade300,
                                          ),
                                          const SizedBox(height: 16),
                                          Text(
                                            'No active requests',
                                            style: TextStyle(
                                              fontSize: 16,
                                              color: Colors.grey.shade600,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                        ],
                                      ),
                                    )
                                  : ListView.builder(
                                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                      itemCount: _activeRequests.length,
                                      itemBuilder: (context, index) {
                                        final request = _activeRequests[index];
                                        return _buildRequestCard(context, request, isActive: true);
                                      },
                                    )
                              : _pastRequests.isEmpty
                                  ? Center(
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Icon(
                                            Icons.history_rounded,
                                            size: 64,
                                            color: Colors.grey.shade300,
                                          ),
                                          const SizedBox(height: 16),
                                          Text(
                                            'No request history',
                                            style: TextStyle(
                                              fontSize: 16,
                                              color: Colors.grey.shade600,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                        ],
                                      ),
                                    )
                                  : ListView.builder(
                                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                      itemCount: _pastRequests.length,
                                      itemBuilder: (context, index) {
                                        final request = _pastRequests[index];
                                        return _buildRequestCard(context, request, isActive: false);
                                      },
                                    ),
                        ),
                      ],
                    ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRequestCard(BuildContext context, dynamic request, {required bool isActive}) {
    final requestId = request['trip_id'] ?? 'Unknown';
    final status = request['status'] ?? 'PENDING';
    final category = request['waste_class'][0].toString() ?? 'UNKNOWN';
    final createdAt = DateTime.tryParse(request['created_at'] ?? '')?.toLocal() ?? DateTime.now();
    final double lat = request['pickup_location']['coordinates'][1] ?? -6.1;
    final double lng = request['pickup_location']['coordinates'][0] ?? 39.1;
    final isTrackable = isActive && _isRequestTrackable(status);

    return GestureDetector(
      onTap: isTrackable
          ? () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => TripTrackingScreen(
                    requestId: requestId,
                    wasteCategory: _getCategoryDisplay(category),
                    pickupLocation: LatLng(lat, lng),
                    qr_code_hash: request['qr_hash'] ?? 'null',
                    estimatedAmount: (request['fare_tzs'] ?? 0.0).toDouble(),
                  ),
                ),
              );
            }
          : status == 'PENDING_PAYMENT'? () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => PaymentScreen(
                    requestId: requestId,
                    amount: (request['fare_tzs'] ?? 0.0).toDouble(),
                    wasteCategory: category,
                    pickupLocation: LatLng(lat, lng),
                    qr_code_hash: request['qr_hash'] ?? 'null',
                  ),
                ),
              );
      }: null,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isTrackable ? kPrimaryColor : Colors.grey.shade100,
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: kPrimaryColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    category == 'HOUSEHOLD'
                        ? Icons.home_work_rounded
                        : category == 'RECYCLABLE'
                            ? Icons.eco_rounded
                            : Icons.unarchive_rounded,
                    color: kPrimaryColor,
                    size: 24,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        requestId.substring(0, math.min(8, requestId.length)),
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        _getCategoryDisplay(category),
                        style: TextStyle(
                          fontSize: 13,
                          color: Colors.grey.shade600,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        _formatTime(createdAt),
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey.shade400,
                        ),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: _getStatusColor(status).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        _getStatusText(status),
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          color: _getStatusColor(status),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
