import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:intl/intl.dart';
import 'package:tupachap_customer/screens/payment_screen.dart';
import '../constants.dart';
import '../models/contract.dart';
import '../services/api_service.dart';
import '../main.dart';
import '../widgets/logo_header.dart';

class ContractDetailsScreen extends StatefulWidget {
  const ContractDetailsScreen({super.key});

  @override
  State<ContractDetailsScreen> createState() => _ContractDetailsScreenState();
}

class _ContractDetailsScreenState extends State<ContractDetailsScreen> {
  final _storage = const FlutterSecureStorage();
  bool _isLoading = true;
  Contract? _contract;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetchContract();
  }

  Future<void> _fetchContract() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final token = await _storage.read(key: 'auth_token');
      if (token != null) {
        final data = await locator<ApiService>().getCurrentContract(token);
        setState(() {
          _contract = Contract.fromJson(data);
          _isLoading = false;
        });
      } else {
        setState(() {
          _error = 'Not authenticated';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = e.toString();
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kPrimaryColor,
      body: Column(
        children: [
          const LogoHeader(isDark: true),
          Expanded(
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(32),
                  topRight: Radius.circular(32),
                ),
              ),
              child: _buildContent(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContent() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator(color: kPrimaryColor));
    }

    if (_error != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Error: $_error', textAlign: TextAlign.center),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _fetchContract,
              child: const Text('Retry'),
            ),
          ],
        ),
      );
    }

    if (_contract == null) {
      return const Center(child: Text('No active contract found.'));
    }

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Contract Details', style: kHeadingStyle),
              _buildStatusBadge(_contract!.contractStatus),
            ],
          ),
          const SizedBox(height: 32),
          _buildDetailItem('Contract ID', _contract!.id),
          _buildDetailItem('Billing Cycle', _contract!.billingCycle.toUpperCase()),
          _buildDetailItem('Pickup Day', _getPickupDayName(_contract!.pickupDay)),
          _buildDetailItem('Start Date', DateFormat('MMM dd, yyyy').format(_contract!.startDate)),
          _buildDetailItem('End Date', DateFormat('MMM dd, yyyy').format(_contract!.endDate)),
          const SizedBox(height: 40),
          SizedBox(
            width: double.infinity,
            height: 56,
            child: ElevatedButton(
              onPressed: () {
                if(_contract!.contractStatus == 'PENDING_PAYMENT'){
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => PaymentScreen(
                        requestId: _contract!.id,
                        isSubscription: true, amount: 0, wasteCategory: '', pickupLocation: LatLng(0, 0), qr_code_hash: '',
                      ),
                    ),
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: kPrimaryColor,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
              child: const Text('Manage Contract', style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailItem(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              color: Colors.grey.shade600,
              fontSize: 12,
              fontWeight: FontWeight.w500,
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 8),
          Divider(color: Colors.grey.shade100),
        ],
      ),
    );
  }

  Widget _buildStatusBadge(String status) {
    Color color;
    switch (status.toLowerCase()) {
      case 'active':
        color = kPrimaryColor;
        break;
      case 'pending':
        color = Colors.orange;
        break;
      case 'expired':
        color = Colors.red;
        break;
      default:
        color = Colors.grey;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.5)),
      ),
      child: Text(
        status.toUpperCase(),
        style: TextStyle(
          color: color,
          fontSize: 10,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  String _getPickupDayName(int day) {
    // Assuming 1 = Monday, ..., 7 = Sunday
    const days = [
      'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'
    ];
    if (day >= 1 && day <= 7) {
      return days[day - 1];
    }
    return 'Day $day';
  }
}
