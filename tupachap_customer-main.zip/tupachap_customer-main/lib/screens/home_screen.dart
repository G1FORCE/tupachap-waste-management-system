import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:tupachap_customer/screens/camera_screen.dart';
import 'package:tupachap_customer/screens/active_requests_screen.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import '../constants.dart';
import '../main.dart';
import '../services/api_service.dart';
import '../widgets/logo_header.dart';
import 'qr_screen.dart';
import 'requests_history_screen.dart';
import 'profile_screen.dart';
import 'schedule_contract_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  late GoogleMapController mapController;
  final _storage = const FlutterSecureStorage();
  
  static  LatLng _center = LatLng(-6.7924, 39.2083);
  final Set<Marker> _markers = {};
  
  WebSocketChannel? _vehicleChannel;
  StreamSubscription? _vehicleSubscription;

  @override
  void initState() {
    super.initState();
    _initializeLocation();
    _startVehicleTracking();
  }

  @override
  void dispose() {
    _vehicleSubscription?.cancel();
    _vehicleChannel?.sink.close();
    super.dispose();
  }

  Future<void> _initializeLocation() async {
    try {
      final permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {

        return;
      }

      final isLocationServiceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!isLocationServiceEnabled) {

        return;
      }

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      if (mounted) {
        setState(() {
          _center = LatLng(position.latitude, position.longitude);
        });

      }
    } catch (e) {

    }
  }

  Future<void> _startVehicleTracking() async {
    try {
      final token = await _storage.read(key: 'auth_token');
      if (token == null) return;

      final apiService = locator<ApiService>();
      
      // Connect to the WebSocket
      /*
      _vehicleChannel = apiService.monitorVehicles(token);

      _vehicleSubscription = _vehicleChannel!.stream.listen(
        (message) {
          final data = jsonDecode(message);
          _handleWebSocketMessage(data);
        },
        onError: (error) {
          debugPrint('WebSocket error: $error');
          _reconnectTracking();
        },
        onDone: () {
          debugPrint('WebSocket connection closed');
          _reconnectTracking();
        },
      );

      // Request initial list of active vehicles
      _vehicleChannel!.sink.add(jsonEncode({"type": "get_active_vehicles"}));
      */
    } catch (e) {
      debugPrint('Error starting vehicle tracking: $e');
      _showPlaceholderVehicles();
    }
  }

  void _reconnectTracking() {
    // Basic retry logic after 5 seconds
    Future.delayed(const Duration(seconds: 5), () {
      if (mounted) _startVehicleTracking();
    });
  }

  void _handleWebSocketMessage(dynamic data) {
    if (data['type'] == 'active_vehicles' || data['type'] == 'vehicles_list') {
      _updateAllVehicles(data['vehicles'] ?? []);
    } else if (data['type'] == 'vehicle_location') {
      _updateSingleVehicle(data);
    }
  }

  void _updateAllVehicles(List vehicles) {
    if (!mounted) return;
    setState(() {
      _markers.clear();

      for (var vehicle in vehicles) {
        _addVehicleMarker(vehicle);
      }
    });
  }

  void _updateSingleVehicle(dynamic data) {
    if (!mounted) return;
    final vehicleId = data['collector_id'] ?? data['vehicle_id'];
    final location = data['location'];
    
    if (location != null) {
      setState(() {
        // Remove old marker if exists and add updated one
        _markers.removeWhere((m) => m.markerId.value == 'vehicle_$vehicleId');
        _addVehicleMarker(data);
      });
    }
  }

  void _addVehicleMarker(dynamic vehicle) {
    final id = vehicle['vehicle_id'] ?? vehicle['vehicle_id'] ?? vehicle['id'] ?? 'unknown';
    final location = vehicle['location'] ?? vehicle['current_location'];
    
    if (location == null) return;

    final lat = (location['latitude'] ?? -6.7924) as num;
    final lng = (location['longitude'] ?? 39.2083) as num;
    final name = 'TupaChap Truck ${vehicle['vehicle_id'] ?? ''}';
    final status = (vehicle['status'] ?? 'AVAILABLE').toString().toUpperCase();

    _markers.add(
      Marker(
        markerId: MarkerId('vehicle_$id'),
        position: LatLng(lat.toDouble(), lng.toDouble()),
        infoWindow: InfoWindow(title: name, snippet: status),
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
      ),
    );
  }

  void _showPlaceholderVehicles() {
    if (_markers.isNotEmpty) return;
    setState(() {
      _markers.add(
        Marker(
          markerId: const MarkerId('truck1'),
          position: const LatLng(-6.7950, 39.2150),
          infoWindow: const InfoWindow(title: 'TupaChap Truck #102', snippet: 'OFFLINE'),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
        ),
      );
    });
  }

  void _onMapCreated(GoogleMapController controller) {
    mapController = controller;
  }

  Widget _buildHomeBody() {
    return Column(
      children: [
        const LogoHeader(isDark: true),
        Expanded(
          child: Container(
            margin: const EdgeInsets.only(top: 10),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(32),
                topRight: Radius.circular(32),
              ),
            ),
            clipBehavior: Clip.antiAlias,
            child: Stack(
              children: [
                GoogleMap(
                  padding: const EdgeInsets.only(top: 90, bottom: 190),
                  style: _mapStyle,
                  onMapCreated: _onMapCreated,
                  initialCameraPosition: CameraPosition(
                    target: _center,
                    zoom: 14.5,
                  ),
                  markers: _markers,
                  myLocationEnabled: true,
                  myLocationButtonEnabled: true,
                  mapType: MapType.normal,
                  zoomControlsEnabled: false,
                  mapToolbarEnabled: false,
                  compassEnabled: false,
                ),
                Positioned(
                  top: 24,
                  left: 20,
                  right: 20,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.1),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.location_on, color: kPrimaryColor, size: 20),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Text(
                            'Current Location, City Center',
                            style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        Icon(Icons.search, color: Colors.grey.shade400),
                      ],
                    ),
                  ),
                ),
                Positioned(
                  bottom: 24,
                  left: 20,
                  right: 20,
                  child: Row(
                    children: [
                      Expanded(
                        child: _buildActionButton(
                          label: 'Immediate pickup',
                          icon: Icons.flash_on_rounded,
                          color: kPrimaryColor,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const CameraScreen()),
                            );
                          },
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _buildActionButton(
                          label: 'Schedule',
                          icon: Icons.calendar_today_rounded,
                          color: kSecondaryColor,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const ScheduleContractScreen()),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  bottom: 120,
                  right: 40,
                  child: FloatingActionButton(
                    heroTag: 'qr_btn',
                    backgroundColor: Colors.white,
                    elevation: 4,
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const QRScreen(qrData: 'gjj',)),
                      );
                    },
                    child: const Icon(Icons.qr_code_scanner_rounded, color: kPrimaryColor),
                  ),
                ),
                Positioned(
                  bottom: 120,
                  left: 40,
                  child: FloatingActionButton(
                    heroTag: 'tracking_btn',
                    backgroundColor: kSecondaryColor,
                    elevation: 4,
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const ActiveRequestsScreen(),
                        ),
                      );
                    },
                    child: const Icon(Icons.local_shipping_rounded, color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    List<Widget> screens = [
      _buildHomeBody(),
      const RequestsHistoryScreen(),
      const ProfileScreen(),
    ];

    return Scaffold(
      backgroundColor: kPrimaryColor,
      body: screens[_selectedIndex],
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.05),
              blurRadius: 10,
              offset: const Offset(0, -5),
            ),
          ],
        ),
        child: BottomNavigationBar(
          currentIndex: _selectedIndex,
          onTap: (index) => setState(() => _selectedIndex = index),
          selectedItemColor: kPrimaryColor,
          unselectedItemColor: Colors.grey.shade400,
          showSelectedLabels: false,
          showUnselectedLabels: false,
          elevation: 0,
          backgroundColor: Colors.transparent,
          type: BottomNavigationBarType.fixed,
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.home_filled, size: 28), label: ''),
            BottomNavigationBarItem(icon: Icon(Icons.receipt_long_rounded, size: 28), label: ''),
            BottomNavigationBarItem(icon: Icon(Icons.person_rounded, size: 28), label: ''),
          ],
        ),
      ),
    );
  }

  Widget _buildActionButton({required String label, required IconData icon, required Color color, required VoidCallback onTap}) {
    return InkWell(
      onTap: onTap,
      child: Container(
        height: 56,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: color.withValues(alpha: 0.3),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 20),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }

  final String _mapStyle =  """
[
  {
    "elementType": "geometry",
    "stylers": [{ "color": "#ffffff" }]
  },
  {
    "featureType": "landscape",
    "elementType": "geometry",
    "stylers": [{ "color": "#f7f9f7" }]
  },
  {
    "featureType": "poi.park",
    "elementType": "geometry",
    "stylers": [{ "color": "#c8e6c9" }]
  },
  {
    "featureType": "road",
    "elementType": "geometry",
    "stylers": [{ "color": "#a9c4aa" }]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry",
    "stylers": [{ "color": "#a5d6a7" }]
  },
  {
    "featureType": "water",
    "elementType": "geometry",
    "stylers": [{ "color": "#e8f5e9" }]
  }
]
""";
}
