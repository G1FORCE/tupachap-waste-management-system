import 'dart:io';
import 'package:camera/camera.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:path/path.dart' as path;
import 'package:tupachap_customer/screens/request_pickup_screen.dart';
import '../constants.dart';
import '../widgets/logo_header.dart';
import '../main.dart';
import '../services/api_service.dart';

class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key});

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  CameraController? _controller;
  List<XFile> _capturedImages = [];
  bool _isInitializing = true;
  bool _isUploading = false;
  final _storage = const FlutterSecureStorage();

  @override
  void initState() {
    super.initState();
    _initializeCamera();
  }

  Future<void> _initializeCamera() async {
    try {
      final cameras = await availableCameras();
      if (cameras.isEmpty) {
        if (mounted) setState(() => _isInitializing = false);
        return;
      }

      _controller = CameraController(
        cameras.first,
        ResolutionPreset.high,
        enableAudio: false,
      );

      await _controller!.initialize();
    } catch (e) {
      debugPrint('Camera initialization error: $e');
    }

    if (mounted) {
      setState(() => _isInitializing = false);
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  Future<void> _takePicture() async {
    if (_controller == null || !_controller!.value.isInitialized) return;

    try {
      final XFile image = await _controller!.takePicture();
      setState(() {
        _capturedImages.add(image);
      });
    } catch (e) {
      debugPrint('Error taking picture: $e');
    }
  }

  Future<void> _onDone() async {
    if (_capturedImages.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please take at least one photo'),
          duration: Duration(seconds: 2),
        ),
      );
      return;
    }

    setState(() => _isUploading = true);

    try {
      // 1. Get credentials and profile to get user ID
      final token = await _storage.read(key: 'auth_token');
      final refresh = await _storage.read(key: 'refresh_token');

      if (token == null) {
        throw Exception('Authentication failed. Please login again.');
      }
      
      final creds = AccessCredentials(accessToken: token, tokenType: 'bearer', role: 'CUSTOMER');
      final apiService = locator<ApiService>();
      
      debugPrint('Fetching user profile for image upload...');
      final profile = await apiService.getCustomerProfile(creds.accessToken);
      final userId = profile['data']['customer_id'];
      
      if (userId.isEmpty) {
        throw Exception('Failed to get user ID');
      }

      final batchPrefix = DateTime.now().millisecondsSinceEpoch.toString();
      List<String> imageUrls = [];
      
      // 2. Upload all images to Firebase Storage
      debugPrint('Uploading ${_capturedImages.length} images to Firebase...');
      for (int i = 0; i < _capturedImages.length; i++) {
        try {
          final File file = File(_capturedImages[i].path);
          final String ext = path.extension(file.path);
          final String fileName = '${batchPrefix}_img_200$i$ext';
          
          final storageRef = FirebaseStorage.instance
              .ref()
              .child('users')
              .child(userId)
              .child(fileName);
          
          await storageRef.putFile(file);
          final downloadUrl = await storageRef.getDownloadURL();
          imageUrls.add(downloadUrl);
          
          debugPrint('Image $i uploaded: $downloadUrl');
        } catch (e) {
          debugPrint('Error uploading image $i: $e');
          throw Exception('Failed to upload image ${i + 1}: ${e.toString()}');
        }
      }

      if (imageUrls.isEmpty) {
        throw Exception('No images were successfully uploaded');
      }

      debugPrint('All images uploaded successfully. Proceeding to request pickup screen...');

      if (mounted) {
        // Pass both URLs and actual file paths to request pickup screen
        final imageFiles = _capturedImages.map((xFile) => File(xFile.path)).toList();
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => RequestPickupScreen(
              imageUrls: imageUrls,
              imageFiles: imageFiles,
            ),
          ),
        );
      }
    } catch (e) {
      debugPrint('Error in _onDone: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Upload failed: ${e.toString()}'),
            duration: const Duration(seconds: 4),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isUploading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(50),
        child: const LogoHeader(isDark: false),
      ),
      backgroundColor: kPrimaryColor,
      body: Stack(
        children: [
          // Camera Preview
          Container(
            width: double.infinity,
            height: double.infinity,
            decoration: const BoxDecoration(
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(32),
                topRight: Radius.circular(32),
              ),
              color: Colors.black,
            ),
            clipBehavior: Clip.antiAlias,
            child: _isInitializing
                ? const Center(child: CircularProgressIndicator(color: Colors.white))
                : (_controller != null && _controller!.value.isInitialized)
                    ? CameraPreview(_controller!)
                    : const Center(child: Text('Camera error', style: TextStyle(color: Colors.white))),
          ),
          
          // Gradient Overlay
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(32),
                  topRight: Radius.circular(32),
                ),
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.4),
                    Colors.transparent,
                    Colors.transparent,
                    Colors.black.withOpacity(0.6),
                  ],
                  stops: const [0.0, 0.2, 0.7, 1.0],
                ),
              ),
            ),
          ),

          // Controls
          SafeArea(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                if (_isUploading)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 20),
                    child: Column(
                      children: [
                        const CircularProgressIndicator(color: kAccentColor),
                        const SizedBox(height: 8),
                        Text('Uploading ${_capturedImages.length} photos...', 
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),

                // Thumbnails
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0),
                  child: SizedBox(
                    height: 60,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: _capturedImages.length + 1,
                      separatorBuilder: (_, __) => const SizedBox(width: 12),
                      itemBuilder: (context, index) {
                        if (index == _capturedImages.length) {
                          return _buildAddMore();
                        }
                        return _buildThumbnail(_capturedImages[index], index);
                      },
                    ),
                  ),
                ),
                const SizedBox(height: 32),

                // Main Shutter and Done button
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 0, 24, 40),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                        onPressed: () => Navigator.pop(context),
                        icon: const Icon(Icons.close_rounded, color: Colors.white, size: 32),
                      ),
                      
                      // Shutter
                      GestureDetector(
                        onTap: _isUploading ? null : _takePicture,
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 4),
                          ),
                          child: Container(
                            width: 64,
                            height: 64,
                            decoration: const BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle,
                            ),
                          ),
                        ),
                      ),

                      // Done Button
                      ElevatedButton(
                        onPressed: (_isUploading || _capturedImages.isEmpty) ? null : _onDone,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: kAccentColor,
                          foregroundColor: kSecondaryColor,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                          elevation: 0,
                        ),
                        child: const Text('Done', style: TextStyle(fontWeight: FontWeight.w800)),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildThumbnail(XFile file, int index) {
    return Stack(
      children: [
        Container(
          width: 60,
          height: 60,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.white, width: 2),
            image: DecorationImage(image: FileImage(File(file.path)), fit: BoxFit.cover),
          ),
        ),
        Positioned(
          top: -4,
          right: -4,
          child: GestureDetector(
            onTap: () => setState(() => _capturedImages.removeAt(index)),
            child: Container(
              padding: const EdgeInsets.all(2),
              decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
              child: const Icon(Icons.close, color: Colors.white, size: 12),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildAddMore() {
    return Container(
      width: 60,
      height: 60,
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.2),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(0.5), width: 2),
      ),
      child: const Icon(Icons.add_a_photo_outlined, color: Colors.white),
    );
  }
}
