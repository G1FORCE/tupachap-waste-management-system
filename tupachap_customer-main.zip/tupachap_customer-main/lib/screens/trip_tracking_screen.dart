import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import '../constants.dart';
import '../widgets/logo_header.dart';
import '../main.dart';
import '../services/api_service.dart';
import 'dart:async';
import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'qr_screen.dart';

class TripTrackingScreen extends StatefulWidget {
  final String requestId;
  final String wasteCategory;
  final LatLng pickupLocation;
  final double estimatedAmount;
  final String qr_code_hash;

  const TripTrackingScreen({
    super.key,
    required this.requestId,
    required this.wasteCategory,
    required this.pickupLocation,
    required this.estimatedAmount,
    required this.qr_code_hash,
  });

  @override
  State<TripTrackingScreen> createState() => _TripTrackingScreenState();
}

class _TripTrackingScreenState extends State<TripTrackingScreen> {
  late GoogleMapController mapController;
  late Marker userMarker;
  late Marker truckMarker;
  Set<Polyline> polylines = {};
  
  String tripStatus = 'ACCEPTED';
  String driverName = 'Driver Loading...';
  String truckNumber = 'Vehicle Loading...';
  double estimatedArrivalMinutes = 0;
  bool showDetails = false;
  late LatLng _truckLocation;
  
  // WebSocket tracking
  WebSocketChannel? _wsChannel;
  final _storage = const FlutterSecureStorage();
  bool _isConnected = false;
  String _connectionError = '';

  @override
  void initState() {
    super.initState();
    _initializeLocations();
    _connectWebSocket();
  }

  void _initializeLocations() {
    // User's pickup location (Dar es Salaam center)
    userMarker = Marker(
      markerId: const MarkerId('user_location'),
      position: widget.pickupLocation,
      infoWindow: const InfoWindow(title: 'Your Location', snippet: 'Pickup point'),
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
    );

    // Initial truck location (slightly away)
    _truckLocation = LatLng(
      widget.pickupLocation.latitude - 0.005,
      widget.pickupLocation.longitude + 0.01,
    );
    
    truckMarker = Marker(
      markerId: const MarkerId('truck_location'),
      position: _truckLocation,
      infoWindow: InfoWindow(title: truckNumber, snippet: 'Waste collection truck'),
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
    );
  }

  Future<void> _connectWebSocket() async {
    try {
      final token = await _storage.read(key: 'auth_token');
      if (token == null) {
        setState(() => _connectionError = 'Authentication token not found');
        return;
      }

      final apiService = locator<ApiService>();
      _wsChannel = apiService.trackTrip(widget.requestId, token);

      setState(() => _isConnected = true);
      debugPrint('WebSocket connected to track trip: ${widget.requestId}');

      // Listen for messages
      _wsChannel?.stream.listen(
        (message) {
          _handleWebSocketMessage(message);
        },
        onError: (error) {
          debugPrint('WebSocket error: $error');
          setState(() {
            _isConnected = false;
            _connectionError = 'Connection lost. Retrying...';
          });
          // Retry connection
          Future.delayed(const Duration(seconds: 3), _connectWebSocket);
        },
        onDone: () {
          debugPrint('WebSocket connection closed');
          setState(() => _isConnected = false);
        },
      );
    } catch (e) {
      debugPrint('Error connecting to WebSocket: $e');
      setState(() => _connectionError = e.toString());
    }
  }

  void _handleWebSocketMessage(String message) {
    try {
      final data = jsonDecode(message);
      final type = data['type'] as String?;

      setState(() {
        switch (type) {
          case 'LOCATION_UPDATE':
            _handleLocationUpdate(data);
            break;
          case 'eta_update':
            _handleEtaUpdate(data);
            break;
          case 'STATUS_UPDATE':
            _handleStatusUpdate(data);
            break;
          default:
            debugPrint('Unknown WebSocket message type: $type');
        }
      });
    } catch (e) {
      debugPrint('Error parsing WebSocket message: $e');
    }
  }

  void _handleLocationUpdate(Map<String, dynamic> data) {
    try {
      final location = data as Map<String, dynamic>?;
      if (location != null) {
        final latitude = (data['lat'] as num).toDouble();
        final longitude = (data['lon'] as num).toDouble();
        
        _truckLocation = LatLng(latitude, longitude);
        
        // Update truck marker
        truckMarker = truckMarker.copyWith(
          positionParam: _truckLocation,
        );

        // Update polyline
        polylines = {
          Polyline(
            polylineId: const PolylineId('route'),
            points: [_truckLocation, widget.pickupLocation],
            color: kPrimaryColor,
            width: 4,
            geodesic: true,
          ),
        };
        
        debugPrint('Location update: $latitude, $longitude');
      }
    } catch (e) {
      debugPrint('Error handling location update: $e');
    }
  }

  void _handleEtaUpdate(Map<String, dynamic> data) {
    try {
      final eta = data['estimated_arrival_minutes'] as num?;
      if (eta != null) {
        estimatedArrivalMinutes = eta.toDouble();
        debugPrint('ETA updated: $estimatedArrivalMinutes minutes');
      }
    } catch (e) {
      debugPrint('Error handling ETA update: $e');
    }
  }

  void _handleStatusUpdate(Map<String, dynamic> data) {
    try {
      final status = data['status'] as String?;
      if (status != null) {
        tripStatus = status;
        debugPrint('Trip status updated: $status');
        
        if (status == 'COMPLETED') {
          _showCompletionDialog();
        }
      }
    } catch (e) {
      debugPrint('Error handling status update: $e');
    }
  }

  void _showCompletionDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('Collection Complete'),
        content: const Text('Your waste collection has been completed successfully.'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Done'),
          ),
        ],
      ),
    );
  }

  void _onMapCreated(GoogleMapController controller) {
    mapController = controller;
    _animateCamera();
  }

  Future<void> _animateCamera() async {
    LatLng centerLat = LatLng(
      (widget.pickupLocation.latitude + _truckLocation.latitude) / 2,
      (widget.pickupLocation.longitude + _truckLocation.longitude) / 2,
    );

    await mapController.animateCamera(
      CameraUpdate.newLatLngBounds(
        LatLngBounds(
          southwest: LatLng(
            centerLat.latitude - 0.01,
            centerLat.longitude - 0.01,
          ),
          northeast: LatLng(
            centerLat.latitude + 0.01,
            centerLat.longitude + 0.01,
          ),
        ),
        100,
      ),
    );
  }

  Color _getStatusColor() {
    switch (tripStatus) {
      case 'ACCEPTED':
        return Colors.blue;
      case 'EN_ROUTE':
        return Colors.orange;
      case 'ARRIVING':
        return Colors.green;
      case 'COMPLETED':
        return Colors.grey;
      default:
        return kPrimaryColor;
    }
  }

  String _getStatusText() {
    switch (tripStatus) {
      case 'ACCEPTED':
        return 'Driver Accepted';
      case 'EN_ROUTE':
        return 'Driver En Route';
      case 'ARRIVING':
        return 'Driver Arriving';
      case 'COMPLETED':
        return 'Collection Complete';
      default:
        return 'Tracking';
    }
  }

  @override
  void dispose() {
    _wsChannel?.sink.close();
    mapController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kPrimaryColor,
      body: Column(
        children: [
          const LogoHeader(isDark: true),
          Expanded(
            child: Container(
              margin: const EdgeInsets.only(top: 10),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(32),
                  topRight: Radius.circular(32),
                ),
              ),
              clipBehavior: Clip.antiAlias,
              child: Stack(
                children: [
                  GoogleMap(
                    padding: const EdgeInsets.only(top: 16, bottom: 200),
                    style: _mapStyle,
                    onMapCreated: _onMapCreated,
                    initialCameraPosition: CameraPosition(
                      target: widget.pickupLocation,
                      zoom: 14.5,
                    ),
                    markers: {userMarker, truckMarker},
                    polylines: polylines,
                    myLocationEnabled: true,
                    mapType: MapType.normal,
                    zoomControlsEnabled: false,
                    mapToolbarEnabled: false,
                    compassEnabled: false,
                  ),
                  // Status badge
                  Positioned(
                    top: 16,
                    left: 16,
                    right: 16,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.1),
                            blurRadius: 10,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 12,
                            height: 12,
                            decoration: BoxDecoration(
                              color: _getStatusColor(),
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Text(
                                      _getStatusText(),
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w700,
                                        fontSize: 14,
                                        color: kPrimaryColor,
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Container(
                                      width: 6,
                                      height: 6,
                                      decoration: BoxDecoration(
                                        color: _isConnected ? Colors.green : Colors.red,
                                        shape: BoxShape.circle,
                                      ),
                                    ),
                                  ],
                                ),
                                Text(
                                  _isConnected 
                                    ? 'Request #${widget.requestId.substring(0, 8)}'
                                    : _connectionError.isNotEmpty ? _connectionError : 'Connecting...',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: _isConnected ? Colors.grey.shade600 : Colors.orange,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          if (tripStatus != 'COMPLETED')
                            const Icon(Icons.location_searching_rounded, color: kPrimaryColor),
                        ],
                      ),
                    ),
                  ),
                  // QR Button
                  Positioned(
                    bottom: 230,
                    right: 20,
                    child: FloatingActionButton(
                      heroTag: 'tracking_qr_btn',
                      backgroundColor: Colors.white,
                      elevation: 4,
                      onPressed: () {
                        String qrData = widget.qr_code_hash;
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>  QRScreen(qrData: qrData)),
                        );
                      },
                      child: const Icon(Icons.qr_code_rounded, color: kPrimaryColor),
                    ),
                  ),
                  // Trip details card
                  Positioned(
                    bottom: 16,
                    left: 16,
                    right: 16,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // Estimated arrival
                        if (tripStatus != 'COMPLETED')
                          Container(
                            width: MediaQuery.sizeOf(context).width/2 ,
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: kPrimaryColor.withValues(alpha: 0.05),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: kPrimaryColor.withValues(alpha: 0.2)),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Estimated Arrival',
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: Colors.grey.shade600,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                    Text(
                                      '${estimatedArrivalMinutes.toStringAsFixed(0)} minutes',
                                      style: const TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.w800,
                                        color: kPrimaryColor,
                                      ),
                                    ),
                                  ],
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                                  decoration: BoxDecoration(
                                    color: kPrimaryColor,
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: const Text(
                                    'Track',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        const SizedBox(height: 12),
                        // Driver and trip details
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.08),
                                blurRadius: 12,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Column(
                            children: [
                              // Driver info
                              Row(
                                children: [
                                  CircleAvatar(
                                    radius: 28,
                                    backgroundColor: kPrimaryColor.withValues(alpha: 0.1),
                                    child: const Icon(
                                      Icons.person_rounded,
                                      size: 32,
                                      color: kPrimaryColor,
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          driverName,
                                          style: const TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 15,
                                          ),
                                        ),
                                        Text(
                                          truckNumber,
                                          style: TextStyle(
                                            fontSize: 13,
                                            color: Colors.grey.shade600,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Row(
                                    children: [
                                      IconButton(
                                        icon: const Icon(Icons.call_rounded, color: kPrimaryColor),
                                        onPressed: () {
                                          ScaffoldMessenger.of(context).showSnackBar(
                                            const SnackBar(content: Text('Call driver: +255 xxx xxx xxx')),
                                          );
                                        },
                                      ),
                                      IconButton(
                                        icon: const Icon(Icons.message_rounded, color: kPrimaryColor),
                                        onPressed: () {
                                          ScaffoldMessenger.of(context).showSnackBar(
                                            const SnackBar(content: Text('Chat with driver feature coming soon')),
                                          );
                                        },
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              const SizedBox(height: 16),
                              // Divider
                              Container(height: 1, color: Colors.grey.shade100),
                              const SizedBox(height: 16),
                              // Trip details
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  _buildDetailItem('Category', widget.wasteCategory),
                                  _buildDetailItem(
                                    'Amount',
                                    'TZS ${widget.estimatedAmount.toStringAsFixed(0)}',
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  // Back button
                  Positioned(
                    top: 16,
                    left: 16,
                    child: SafeArea(
                      child: CircleAvatar(
                        backgroundColor: Colors.white,
                        child: IconButton(
                          icon: const Icon(Icons.arrow_back_rounded, color: kPrimaryColor),
                          onPressed: () => Navigator.pop(context),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailItem(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey.shade600,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
      ],
    );
  }

  final String _mapStyle = """
[
  {
    "elementType": "geometry",
    "stylers": [{ "color": "#ffffff" }]
  },
  {
    "featureType": "landscape",
    "elementType": "geometry",
    "stylers": [{ "color": "#f7f9f7" }]
  },
  {
    "featureType": "poi.park",
    "elementType": "geometry",
    "stylers": [{ "color": "#c8e6c9" }]
  },
  {
    "featureType": "road",
    "elementType": "geometry",
    "stylers": [{ "color": "#a9c4aa" }]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry",
    "stylers": [{ "color": "#a5d6a7" }]
  },
  {
    "featureType": "water",
    "elementType": "geometry",
    "stylers": [{ "color": "#e8f5e9" }]
  }
]
""";
}
