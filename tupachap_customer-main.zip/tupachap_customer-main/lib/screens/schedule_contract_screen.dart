import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:intl/intl.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../constants.dart';
import '../services/api_service.dart';
import '../main.dart';
import '../widgets/logo_header.dart';
import 'payment_screen.dart';

class ScheduleContractScreen extends StatefulWidget {
  const ScheduleContractScreen({super.key});

  @override
  State<ScheduleContractScreen> createState() => _ScheduleContractScreenState();
}

class _ScheduleContractScreenState extends State<ScheduleContractScreen> {
  final _storage = const FlutterSecureStorage();
  bool _isLoading = false;

  String _selectedBillingCycle = 'ANNUALLY';
  int _selectedPickupDay = 1; // Monday
  DateTime _startDate = DateTime.now().add(const Duration(days: 1));
  DateTime _endDate = DateTime.now().add(const Duration(days: 31));

  final List<Map<String, dynamic>> _billingCycles = [
    {'value': 'SEMI_ANNUALLY', 'label': 'Semi-Annually'},
    {'value': 'ANNUALLY', 'label': 'Annually'},
  ];

  final List<Map<String, dynamic>> _days = [
    {'value': 1, 'label': 'Monday'},
    {'value': 2, 'label': 'Tuesday'},
    {'value': 3, 'label': 'Wednesday'},
    {'value': 4, 'label': 'Thursday'},
    {'value': 5, 'label': 'Friday'},
    {'value': 6, 'label': 'Saturday'},
    {'value': 7, 'label': 'Sunday'},
  ];

  Future<void> _selectDate(BuildContext context, bool isStart) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: isStart ? _startDate : _endDate,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 730)),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: kPrimaryColor,
              onPrimary: Colors.white,
              onSurface: kSecondaryColor,
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null) {
      setState(() {
        if (isStart) {
          _startDate = picked;
          if (_endDate.isBefore(_startDate)) {
            _endDate = _startDate.add(const Duration(days: 30));
          }
        } else {
          _endDate = picked;
        }
      });
    }
  }

  void _submitContract() async {
    setState(() => _isLoading = true);
    try {
      final token = await _storage.read(key: 'auth_token');
      if (token == null) throw Exception('Not authenticated');

      final result = await locator<ApiService>().subscribe(
        token,
        billingCycle: _selectedBillingCycle,
        startDate: DateFormat('yyyy-MM-dd').format(_startDate),
        endDate: DateFormat('yyyy-MM-dd').format(_endDate),
        pickupDay: _selectedPickupDay,
      );

      // result['data'] is often where the actual object is based on api_service.dart implementation of getCurrentContract
      // subscribe implementation in api_service.dart returns jsonDecode(response.body)
      final data = result['data'] ?? result;
      final double amount = (data['price'] ?? 15000).toDouble();
      final String contractId = data['contract_id'] ?? '';

      if (mounted) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => PaymentScreen(
              amount: amount,
              qr_code_hash: '',
              requestId: contractId,
              wasteCategory: 'Regular Pickup (${_selectedBillingCycle})',
              pickupLocation: const LatLng(-6.7924, 39.2083), // Default or user location
              isSubscription: true, // Correctly set to true for contracts
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to create contract: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kPrimaryColor,
      body: Column(
        children: [
          const LogoHeader(isDark: true),
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(32),
                  topRight: Radius.circular(32),
                ),
              ),
              child: _isLoading 
                ? const Center(child: CircularProgressIndicator(color: kPrimaryColor))
                : SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Schedule Regular Pickup', style: kHeadingStyle),
                        const SizedBox(height: 8),
                        Text(
                          'Set up a recurring waste collection contract with us.',
                          style: TextStyle(color: Colors.grey.shade600, fontSize: 14),
                        ),
                        const SizedBox(height: 32),
                        
                        _buildLabel('Billing Cycle'),
                        DropdownButtonFormField<String>(
                          value: _selectedBillingCycle,
                          decoration: kInputDecoration('Select Cycle'),
                          items: _billingCycles.map((cycle) {
                            return DropdownMenuItem(
                              value: cycle['value'] as String,
                              child: Text(cycle['label'] as String),
                            );
                          }).toList(),
                          onChanged: (val) => setState(() => _selectedBillingCycle = val!),
                        ),
                        
                        const SizedBox(height: 24),
                        _buildLabel('Preferred Pickup Day'),
                        DropdownButtonFormField<int>(
                          value: _selectedPickupDay,
                          decoration: kInputDecoration('Select Day'),
                          items: _days.map((day) {
                            return DropdownMenuItem(
                              value: day['value'] as int,
                              child: Text(day['label'] as String),
                            );
                          }).toList(),
                          onChanged: (val) => setState(() => _selectedPickupDay = val!),
                        ),
                        
                        const SizedBox(height: 24),
                        Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  _buildLabel('Start Date'),
                                  InkWell(
                                    onTap: () => _selectDate(context, true),
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
                                      decoration: BoxDecoration(
                                        color: Colors.grey.shade50,
                                        borderRadius: BorderRadius.circular(16),
                                        border: Border.all(color: Colors.grey.shade200),
                                      ),
                                      child: Row(
                                        children: [
                                          const Icon(Icons.calendar_today, size: 18, color: kPrimaryColor),
                                          const SizedBox(width: 12),
                                          Text(DateFormat('MMM dd, yyyy').format(_startDate)),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  _buildLabel('End Date'),
                                  InkWell(
                                    onTap: () => _selectDate(context, false),
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
                                      decoration: BoxDecoration(
                                        color: Colors.grey.shade50,
                                        borderRadius: BorderRadius.circular(16),
                                        border: Border.all(color: Colors.grey.shade200),
                                      ),
                                      child: Row(
                                        children: [
                                          const Icon(Icons.calendar_today, size: 18, color: kPrimaryColor),
                                          const SizedBox(width: 12),
                                          Text(DateFormat('MMM dd, yyyy').format(_endDate)),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        
                        const SizedBox(height: 48),
                        SizedBox(
                          width: double.infinity,
                          height: 56,
                          child: ElevatedButton(
                            onPressed: _submitContract,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: kPrimaryColor,
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                              elevation: 0,
                            ),
                            child: const Text('Create Contract', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Center(
                          child: TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: Text('Cancel', style: TextStyle(color: Colors.grey.shade600)),
                          ),
                        ),
                      ],
                    ),
                  ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 8),
      child: Text(
        text,
        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: kSecondaryColor),
      ),
    );
  }
}
