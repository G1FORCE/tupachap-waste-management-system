import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:tupachap_customer/screens/payment_screen.dart';
import '../constants.dart';
import '../main.dart';
import '../services/api_service.dart';
import '../widgets/logo_header.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'dart:io';

class RequestPickupScreen extends StatefulWidget {
  final List<String> imageUrls;
  final List<File> imageFiles;
  const RequestPickupScreen({super.key, required this.imageUrls, required this.imageFiles});

  @override
  State<RequestPickupScreen> createState() => _RequestPickupScreenState();
}

class _RequestPickupScreenState extends State<RequestPickupScreen> {
  // Updated to handle multiple selections as a List<String>
  List<String> selectedCategories = ['SOLID_GENERAL'];
  final _storage = const FlutterSecureStorage();
  bool _isLoading = false;
  bool _isEstimating = false;
  double _estimatedFare = 0.0;
  String _estimationError = '';
  late LatLng _userLocation;

  @override
  void initState() {
    super.initState();
    _initializeLocation();
  }

  Future<void> _initializeLocation() async {
    try {
      final permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
        _setFallbackLocation();
        return;
      }

      final isLocationServiceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!isLocationServiceEnabled) {
        _setFallbackLocation();
        return;
      }

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      if (mounted) {
        setState(() {
          _userLocation = LatLng(position.latitude, position.longitude);
        });
        _estimateFare();
      }
    } catch (e) {
      _setFallbackLocation();
    }
  }

  void _setFallbackLocation() {
    if (mounted) {
      setState(() {
        _userLocation = const LatLng(-6.7924, 39.2083);
      });
      _estimateFare();
    }
  }

  Future<void> _estimateFare() async {
    if (_isEstimating || widget.imageFiles.isEmpty) return;
    setState(() => _isEstimating = true);

    try {
      final apiService = locator<ApiService>();
      double totalEstimate = 0;
      
      for (var file in widget.imageFiles) {
        final result = await apiService.estimateWastePrice(file);
        if (result['valuation'] != null && result['valuation']['estimated_total_price'] != null) {
          totalEstimate += (result['valuation']['estimated_total_price'] as num).toDouble();
        }
      }

      if (mounted) {
        setState(() {
          _estimatedFare = totalEstimate > 0 ? totalEstimate : 3500.0;
          _estimationError = '';
          _isEstimating = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _estimationError = e.toString();
          _estimatedFare = 3500.0;
          _isEstimating = false;
        });
      }
    }
  }

  Future<void> _submitRequest() async {
    if (selectedCategories.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select at least one waste category')),
      );
      return;
    }

    setState(() => _isLoading = true);
    try {
      final apiService = locator<ApiService>();
      final token = await _storage.read(key: 'auth_token');

      if (token == null) {
        throw Exception('Session expired. Please log in again.');
      }

      // Updated: Now passing selectedCategories list and multiple imageUrls
      final result = await apiService.requestImmediateTrip(
        token,
        lat: _userLocation.latitude,
        lon: _userLocation.longitude,
        wasteClass: selectedCategories,
        imageEstimatedPrice: _estimatedFare,
        estimationImageUrl: widget.imageUrls.isNotEmpty ? widget.imageUrls : null,
      );

      final requestId = result['id'] ?? '';

      if (requestId.isEmpty) {
        throw Exception('Failed to get request ID from server response');
      }

      if (mounted) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => PaymentScreen(
              qr_code_hash: result['qr_code_hash'],
              amount: _estimatedFare,
              requestId: requestId,
              wasteCategory: selectedCategories.join(', '),
              pickupLocation: _userLocation,
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Submission failed: ${e.toString()}')),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kPrimaryColor,
      body: Column(
        children: [
          const LogoHeader(isDark: true),
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(32),
                  topRight: Radius.circular(32),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Waste Category', style: kHeadingStyle.copyWith(fontSize: 20)),
                  const SizedBox(height: 8),
                  Text(
                    'Select types of waste for collection (tap to multi-select)',
                    style: TextStyle(color: Colors.grey.shade600, fontSize: 14),
                  ),
                  const SizedBox(height: 24),
                  Expanded(
                    child: ListView(
                      padding: EdgeInsets.zero,
                      children: [
                        _buildCategoryItem(
                          title: 'General Solid',
                          subtitle: 'Regular trash and non-recyclables',
                          icon: Icons.delete_outline_rounded,
                          value: 'SOLID_GENERAL',
                        ),
                        _buildCategoryItem(
                          title: 'Recyclable Solid',
                          subtitle: 'Plastic, paper, glass, metal',
                          icon: Icons.eco_rounded,
                          value: 'SOLID_RECYCLABLE',
                        ),
                        _buildCategoryItem(
                          title: 'Organic',
                          subtitle: 'Food waste and biodegradable',
                          icon: Icons.set_meal_rounded,
                          value: 'ORGANIC',
                        ),
                        _buildCategoryItem(
                          title: 'Liquid',
                          subtitle: 'Sludge and liquid waste',
                          icon: Icons.water_drop_outlined,
                          value: 'LIQUID',
                        ),
                        _buildCategoryItem(
                          title: 'Biohazard',
                          subtitle: 'Medical or hazardous waste',
                          icon: Icons.warning_amber_rounded,
                          value: 'BIOHAZARD',
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: kSurfaceColor,
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: Colors.grey.shade100),
                    ),
                    child: _isEstimating
                        ? const Center(child: CircularProgressIndicator(color: kPrimaryColor))
                        : Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Estimated Fare', style: TextStyle(fontWeight: FontWeight.w500)),
                              Text(
                                'TZS ${_estimatedFare.toStringAsFixed(0)}',
                                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: kPrimaryColor),
                              ),
                            ],
                          ),
                  ),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    height: 56,
                    child: ElevatedButton(
                      onPressed: _isLoading ? null : _submitRequest,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: kPrimaryColor,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                      child: Text(
                        _isLoading ? 'Submitting...' : 'Confirm & Proceed To Payment',
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryItem({
    required String title,
    required String subtitle,
    required IconData icon,
    required String value,
  }) {
    bool isSelected = selectedCategories.contains(value);
    
    return GestureDetector(
      onTap: () {
        setState(() {
          if (isSelected) {
            // Keep at least one selected
            if (selectedCategories.length > 1) {
              selectedCategories.remove(value);
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Please select at least one category')),
              );
            }
          } else {
            selectedCategories.add(value);
          }
        });
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: isSelected ? kPrimaryColor.withOpacity(0.05) : Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected ? kPrimaryColor : Colors.grey.shade200,
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Row(
          children: [
            Icon(icon, color: isSelected ? kPrimaryColor : Colors.grey.shade600),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text(subtitle, style: TextStyle(color: Colors.grey.shade500, fontSize: 13)),
                ],
              ),
            ),
            if (isSelected) const Icon(Icons.check_circle_rounded, color: kPrimaryColor),
          ],
        ),
      ),
    );
  }
}
