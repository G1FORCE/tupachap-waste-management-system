import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../constants.dart';
import '../widgets/logo_header.dart';
import '../main.dart';
import '../services/api_service.dart';
import 'signup_screen.dart';
import 'contract_details_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _firstNameController = TextEditingController();
  final _lastNameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _storage = const FlutterSecureStorage();
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    try {
      final token = await _storage.read(key: 'auth_token');

      if (token != null) {
        final profile = await locator<ApiService>().getCustomerProfile(token);

        setState(() {
          _firstNameController.text = profile['data']['first_name'];
          _lastNameController.text = profile['data']['last_name'];
          _phoneController.text = profile['data']['phone_number'];
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _saveProfile() async {
    setState(() => _isLoading = true);
    try {
      final token = await _storage.read(key: 'auth_token');

      if (token != null) {
        final profileData = {
          'first_name': _firstNameController.text,
          'last_name': _lastNameController.text,
          'phone_number': _phoneController.text,
        };

        await locator<ApiService>().updateProfile(token, profileData, lat: 0, lon: 0);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Profile updated successfully')),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Update failed: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) return const Center(child: CircularProgressIndicator());

    return Column(
      children: [
        const LogoHeader(isDark: true),
        Expanded(
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(topLeft: Radius.circular(32), topRight: Radius.circular(32)),
            ),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Profile Details', style: kHeadingStyle),
                  const SizedBox(height: 32),
                  _buildField('First Name', _firstNameController),
                  const SizedBox(height: 16),
                  _buildField('Last Name', _lastNameController),
                  const SizedBox(height: 16),
                  _buildField('Phone Number', _phoneController),
                  const SizedBox(height: 24),
                  
                  // Contract Navigation
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.grey.shade50,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.grey.shade200),
                    ),
                    child: ListTile(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const ContractDetailsScreen()),
                        );
                      },
                      leading: const CircleAvatar(
                        backgroundColor: kPrimaryColor,
                        child: Icon(Icons.description_outlined, color: Colors.white, size: 20),
                      ),
                      title: const Text('My Waste Contract', style: TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: const Text('View billing and pickup schedule'),
                      trailing: const Icon(Icons.chevron_right),
                    ),
                  ),
                  
                  const SizedBox(height: 32),
                  SizedBox(
                    width: double.infinity,
                    height: 56,
                    child: ElevatedButton(
                      onPressed: _saveProfile,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: kPrimaryColor, 
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                      child: const Text('Save Changes', style: TextStyle(fontWeight: FontWeight.bold)),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextButton(
                    onPressed: () async {
                      await _storage.deleteAll();
                      if (mounted) Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const SignupScreen()), (r) => false);
                    },
                    child: const Center(child: Text('Log Out', style: TextStyle(color: Colors.red))),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildField(String label, TextEditingController controller) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Colors.black54)),
        const SizedBox(height: 8),
        TextFormField(controller: controller, decoration: kInputDecoration(label)),
      ],
    );
  }
}
