import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import '../constants.dart';
import '../widgets/logo_header.dart';
import 'login_screen.dart';
import '../main.dart';
import '../services/api_service.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final _phoneController = TextEditingController();
  final _customerTypeController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _isLoading = false;
  bool _obscurePassword = true; // Added for show password feature

  void _handleSignup() async {
    final phone = _phoneController.text.trim();
    final password = _passwordController.text;
    final customerType = _customerTypeController.text;

    if (phone.isEmpty || password.isEmpty || customerType.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill in all required fields')),
      );
      return;
    }

    // Phone number validation for 255XXXXXXXXX format
    final phoneRegex = RegExp(r'^255\d{9}$');
    if (!phoneRegex.hasMatch(phone)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Invalid phone format. Please use 255XXXXXXXXX'),
        ),
      );
      return;
    }

    setState(() => _isLoading = true);
    try {
      // Get location for registration
      double lat = -6.7924;
      double lon = 39.2083;

      try {
        final permission = await Geolocator.checkPermission();
        if (permission == LocationPermission.always || permission == LocationPermission.whileInUse) {
          Position position = await Geolocator.getCurrentPosition();
          lat = position.latitude;
          lon = position.longitude;
        }
      } catch (e) {
        debugPrint('Location acquisition failed, using defaults: $e');
      }

      final apiService = locator<ApiService>();
      final success = await apiService.registerCustomer(
        firstName: '', // You might want to add fields for these later
        lastName: '',
        phoneNumber: phone,
        password: password,
        customerType: customerType,
        latitude: lat,
        longitude: lon,
      );

      if (success && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Registration successful! Please login.')),
        );
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const LoginScreen()),
        );
      } else if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Registration failed. Please try again.')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: ${e.toString()}')),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kPrimaryColor,
      body: Column(
        children: [
          const LogoHeader(isDark: true),
          Expanded(
            child: Container(
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(32),
                  topRight: Radius.circular(32),
                ),
              ),
              clipBehavior: Clip.antiAlias,
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Create Account', style: kHeadingStyle),
                    const SizedBox(height: 8),
                    Text(
                      'Join TupaChap to keep your city clean',
                      style: TextStyle(color: Colors.grey.shade600, fontSize: 16),
                    ),
                    const SizedBox(height: 32),
                    TextFormField(
                      controller: _phoneController,
                      keyboardType: TextInputType.phone,
                      decoration: kInputDecoration('Phone number (e.g. 255...)').copyWith(
                        prefixIcon: const Icon(Icons.phone_android_outlined, size: 20),
                      ),
                    ),
                    const SizedBox(height: 16),
                    DropdownMenuFormField(
                      menuStyle: MenuStyle(
                        backgroundColor: WidgetStateProperty.all(Colors.white),
                        shape: WidgetStateProperty.all(
                          RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        ),
                        elevation: WidgetStateProperty.all(0),
                      ),
                      decorationBuilder: (context, controller) => kInputDecoration('Customer Type').copyWith(
                        prefixIcon: const Icon(Icons.person_outline_rounded, size: 20),
                      ),
                      controller: _customerTypeController,
                      dropdownMenuEntries: customerTypes.map((t) => DropdownMenuEntry(value: t, label: t)).toList(),
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _passwordController,
                      obscureText: _obscurePassword, // Use the state variable
                      decoration: kInputDecoration('Password').copyWith(
                        prefixIcon: const Icon(Icons.lock_outline_rounded, size: 20),
                        suffixIcon: IconButton( // Added toggle button
                          icon: Icon(
                            _obscurePassword ? Icons.visibility_off : Icons.visibility,
                            color: Colors.grey,
                            size: 20,
                          ),
                          onPressed: () {
                            setState(() {
                              _obscurePassword = !_obscurePassword;
                            });
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 48),
                    SizedBox(
                      width: double.infinity,
                      height: 56,
                      child: ElevatedButton(
                        onPressed: _isLoading ? null : _handleSignup,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: kPrimaryColor,
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        ),
                        child: _isLoading
                            ? const CircularProgressIndicator(color: Colors.white)
                            : const Text('Sign Up', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      ),
                    ),
                    const SizedBox(height: 24),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('Already have an account? ', style: TextStyle(color: Colors.grey.shade600)),
                        GestureDetector(
                          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginScreen())),
                          child: const Text('Login', style: TextStyle(color: kPrimaryColor, fontWeight: FontWeight.bold)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

const List<String> customerTypes = ["HOUSEHOLD", "SCHOOLS", "RESTAURANTS", "COMPANY", "HOSPITAL", "INDUSTRY"];