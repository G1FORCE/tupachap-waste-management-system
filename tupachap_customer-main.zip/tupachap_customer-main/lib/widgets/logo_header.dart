import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../constants.dart';

class LogoHeader extends StatelessWidget {
  final bool isDark;
  const LogoHeader({super.key, this.isDark = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.only(top: 60, bottom: 15),
      width: double.infinity,
      color: isDark ? kPrimaryColor : Colors.transparent,
      child: Center(
        child: SvgPicture.asset(
          'assets/images/brand_logo.svg',
          height: 25,
        ),
      ),
    );
  }
}
