import 'package:flutter/material.dart';

const Color kPrimaryColor = Color(0xFF009000); // Updated to actual brand green
const Color kBackgroundColor = Color(0xFFF8F9FA);
const Color kSurfaceColor = Colors.white;
const Color kSecondaryColor = Color(0xFF006400); // Darker shade for contrast
const Color kAccentColor = Color(0xFFB6FF00); // Lime green from SVG

TextStyle kAppNameStyle = const TextStyle(
  fontSize: 32,
  fontWeight: FontWeight.bold,
  color: Colors.white,
  letterSpacing: 1.5,
);

TextStyle kHeadingStyle = const TextStyle(
  fontSize: 26,
  fontWeight: FontWeight.w800,
  color: kSecondaryColor,
  letterSpacing: -0.5,
);

BoxDecoration kCardDecoration = BoxDecoration(
  color: Colors.white,
  borderRadius: BorderRadius.circular(32),
  boxShadow: [
    BoxShadow(
      color: Colors.black.withValues(alpha: 0.06),
      blurRadius: 24,
      offset: const Offset(0, 8),
    ),
  ],
);

InputDecoration kInputDecoration(String hint) => InputDecoration(
  hintText: hint,
  hintStyle: TextStyle(color: Colors.grey.shade400, fontSize: 14),
  filled: true,
  fillColor: Colors.grey.shade50,
  contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
  border: OutlineInputBorder(
    borderRadius: BorderRadius.circular(16),
    borderSide: BorderSide.none,
  ),
  enabledBorder: OutlineInputBorder(
    borderRadius: BorderRadius.circular(16),
    borderSide: BorderSide(color: Colors.grey.shade100),
  ),
  focusedBorder: OutlineInputBorder(
    borderRadius: BorderRadius.circular(16),
    borderSide: const BorderSide(color: kPrimaryColor, width: 1.5),
  ),
);
