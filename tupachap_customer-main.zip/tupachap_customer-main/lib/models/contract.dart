class Contract {
  final String id;
  final String customerId;
  final String billingCycle;
  final String? contractType;
  final int pickupDay;
  final DateTime startDate;
  final DateTime endDate;
  final String contractStatus;

  Contract({
    required this.id,
    required this.customerId,
    required this.billingCycle,
    this.contractType,
    required this.pickupDay,
    required this.startDate,
    required this.endDate,
    required this.contractStatus,
  });

  factory Contract.fromJson(Map<String, dynamic> json) {
    return Contract(
      id: json['contract_id'],
      customerId: json['customer_id'] ?? '',
      billingCycle: json['billing_cycle'],
      pickupDay: json['pickup_day'] is int ? json['pickup_day'] : (json['pickup_day'] as num).toInt(),
      startDate: DateTime.parse(json['start_date']),
      endDate: DateTime.parse(json['end_date']),
      contractStatus: json['status'],
    );
  }
}
