package com.devstacksio.tupachap_customer;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
